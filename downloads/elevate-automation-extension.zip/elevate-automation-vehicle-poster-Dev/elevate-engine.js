// elevate-engine.js
// Elevate Automation Engine V14
// Stable storage contract for Inventory + Marketplace with worker-level duplicate,
// posting-limit, compliance validation, and lifecycle sync support.

const STORAGE_KEYS = {
  VEHICLE: "vehicle",
  VEHICLE_QUEUE: "vehicleQueue",
  DW_FIELD_MAP: "dwFieldMap",
  EXTENSION_SESSION: "ea_extension_session",
  PIPELINE_CURRENT: "elevate_current_vehicle",
  PIPELINE_QUEUE: "elevate_vehicle_queue",
  PIPELINE_PROFILE: "elevate_profile_snapshot",
  PIPELINE_TRIGGER: "elevate_posting_trigger",
  PIPELINE_INVENTORY: "elevate_inventory_snapshot",
  SESSION_SNAPSHOT: "elevate_session_snapshot",
  LAST_EXTENSION_STATE_FETCH: "ea_last_extension_state_fetch",
  POSTED_REGISTRY: "ea_posted_registry",
  POST_STATE: "ea_post_state_registry",
  LAST_POSTED_VEHICLE_KEY: "ea_last_posted_vehicle_key",
  LAST_POST_AT: "ea_last_post_at",
  MARKETPLACE_LISTINGS: "ea_marketplace_listings",
  PENDING_POST_COMMITS: "ea_pending_post_commits"
};

const DEFAULT_STATE = {
  vehicle: null,
  vehicleQueue: [],
  dwFieldMap: {},
  extensionSession: null,
  profileSnapshot: null,
  inventorySnapshot: {},
  marketplaceListings: {}
};

const DEFAULT_POSTING_LIMIT = 5;
const API_BASE_URL = "https://elevate-automation-site.vercel.app";

function getApiBaseUrl() { return API_BASE_URL; }

function log(...args) {
  console.log("[Elevate Engine V14]", ...args);
}

function warn(...args) {
  console.warn("[Elevate Engine V14]", ...args);
}

function clean(v) {
  return String(v || "").replace(/\s+/g, " ").trim();
}

function upper(v) {
  return clean(v).toUpperCase();
}

function digitsOnly(v) {
  return String(v || "").replace(/[^\d]/g, "");
}

function numberOrZero(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function compareVersions(a, b) {
  const pa = String(a || "0.0.0").split(".").map((x) => Number(x) || 0);
  const pb = String(b || "0.0.0").split(".").map((x) => Number(x) || 0);
  const len = Math.max(pa.length, pb.length);

  for (let i = 0; i < len; i += 1) {
    const av = pa[i] || 0;
    const bv = pb[i] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }

  return 0;
}

function getCurrentExtensionVersion() {
  try {
    return chrome.runtime?.getManifest?.()?.version || "0.0.0";
  } catch {
    return "0.0.0";
  }
}

function normalizeStatusValue(value, fallback = "inactive") {
  const raw = clean(value).toLowerCase();
  if (!raw) return fallback;
  if (["active", "trialing", "paid", "checkout_pending"].includes(raw)) return "active";
  if (["canceled", "cancelled", "unpaid", "past_due", "expired", "suspended", "inactive"].includes(raw)) return "inactive";
  return raw;
}

function normalizePlanLabel(value) {
  const raw = clean(value).toLowerCase();
  if (!raw || raw === "no plan") return "Founder Beta";
  if (raw.includes("founder") && raw.includes("pro")) return "Founder Pro";
  if (raw.includes("founder") && raw.includes("starter")) return "Founder Beta";
  if (raw.includes("founder") || raw.includes("beta")) return "Founder Beta";
  if (raw.includes("pro")) return "Pro";
  if (raw.includes("starter")) return "Starter";
  return clean(value) || "Founder Beta";
}

function inferPostingLimitFromPlan(value) {
  const raw = clean(value).toLowerCase();
  if ((raw.includes("founder") && raw.includes("pro")) || raw === "pro" || (!raw.includes("founder") && raw.includes("pro"))) return 25;
  return 5;
}

function resolvePostingLimit(session = null) {
  const direct = numberOrZero(
    session?.subscription?.posting_limit ??
    session?.subscription?.daily_posting_limit ??
    session?.posting_limit ??
    0
  );

  if (direct > 0) return direct;
  return inferPostingLimitFromPlan(
    session?.subscription?.normalized_plan ||
    session?.subscription?.plan ||
    session?.normalized_plan ||
    session?.plan ||
    "Founder Beta"
  ) || DEFAULT_POSTING_LIMIT;
}

function chromeGet(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(keys, (result) => resolve(result || {}));
    } catch {
      resolve({});
    }
  });
}

function chromeSet(payload) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.set(payload, () => resolve(true));
    } catch {
      resolve(false);
    }
  });
}

function buildVehicleKey(vehicle) {
  if (!vehicle) return "";

  const vin = upper(vehicle.vin || "");
  if (vin) return `VIN:${vin}`;

  const stock = upper(vehicle.stock || vehicle.stock_number || vehicle.stockNumber || "");
  if (stock) return `STOCK:${stock}`;

  return [
    upper(vehicle.year || ""),
    upper(vehicle.make || ""),
    upper(vehicle.model || ""),
    digitsOnly(vehicle.price || vehicle.list_price || vehicle.asking_price || ""),
    digitsOnly(vehicle.km || vehicle.kilometers || vehicle.mileage || "")
  ].join("|");
}

function buildCanonicalVehicleKey(input) {
  if (!input) return "";
  if (typeof input === "string") return clean(input);
  return buildVehicleKey(input);
}

function sanitizeVehicle(vehicle) {
  if (!vehicle || typeof vehicle !== "object") return null;

  const photoUrls = Array.isArray(vehicle.photoUrls)
    ? vehicle.photoUrls.filter(Boolean).slice(0, 20)
    : [];

  return {
    ...vehicle,
    title: clean(vehicle.title || ""),
    year: clean(vehicle.year || ""),
    make: clean(vehicle.make || ""),
    model: clean(vehicle.model || ""),
    trim: clean(vehicle.trim || ""),
    vin: clean(vehicle.vin || "").toUpperCase(),
    stock: clean(vehicle.stock || vehicle.stock_number || vehicle.stockNumber || ""),
    price: clean(vehicle.price || ""),
    km: clean(vehicle.km || vehicle.kilometers || vehicle.mileage || ""),
    kilometers: clean(vehicle.kilometers || vehicle.km || vehicle.mileage || ""),
    mileage: clean(vehicle.mileage || vehicle.kilometers || vehicle.km || ""),
    location: clean(vehicle.location || ""),
    listing_location: clean(vehicle.listing_location || ""),
    dealer_name: clean(vehicle.dealer_name || vehicle.dealership || ""),
    dealer_phone: clean(vehicle.dealer_phone || ""),
    dealer_email: clean(vehicle.dealer_email || ""),
    salesperson_name: clean(vehicle.salesperson_name || vehicle.full_name || ""),
    description: String(vehicle.description || ""),
    status: clean(vehicle.status || "posted").toLowerCase(),
    lifecycle_status: clean(vehicle.lifecycle_status || "").toLowerCase(),
    review_bucket: clean(vehicle.review_bucket || ""),
    views_count: numberOrZero(vehicle.views_count ?? vehicle.views ?? 0),
    messages_count: numberOrZero(vehicle.messages_count ?? vehicle.messages ?? 0),
    posted_at: vehicle.posted_at || vehicle.created_at || vehicle.timestamp || new Date().toISOString(),
    photoUrls,
    coverPhotoUrl: clean(vehicle.coverPhotoUrl || vehicle.cover_photo_url || photoUrls[0] || ""),
    source_url: clean(vehicle.source_url || vehicle.sourceUrl || ""),
    sourceUrl: clean(vehicle.sourceUrl || vehicle.source_url || "")
  };
}

function sanitizeQueue(queue) {
  return Array.isArray(queue) ? queue.map(sanitizeVehicle).filter(Boolean) : [];
}

function sanitizeProfile(profile) {
  if (!profile || typeof profile !== "object") return null;

  return {
    ...profile,
    full_name: clean(profile.full_name || profile.salesperson_name || ""),
    salesperson_name: clean(profile.salesperson_name || profile.full_name || ""),
    phone: clean(profile.phone || profile.dealer_phone || ""),
    dealer_phone: clean(profile.dealer_phone || profile.phone || ""),
    dealer_email: clean(profile.dealer_email || profile.email || ""),
    email: clean(profile.email || profile.dealer_email || ""),
    dealer_name: clean(profile.dealer_name || profile.dealership || ""),
    dealership: clean(profile.dealership || profile.dealer_name || ""),
    listing_location: clean(profile.listing_location || profile.location || ""),
    location: clean(profile.location || profile.listing_location || ""),
    province: clean(profile.province || ""),
    scanner_type: clean(profile.scanner_type || ""),
    compliance_signature: clean(profile.compliance_signature || "")
  };
}

function sanitizeSession(session) {
  if (!session || typeof session !== "object") return null;

  const user = session.user && typeof session.user === "object" ? session.user : {};
  const subscription = session.subscription && typeof session.subscription === "object" ? session.subscription : {};
  const plan = normalizePlanLabel(subscription.normalized_plan || subscription.plan || session.plan || "Founder Beta");
  const postingLimit = resolvePostingLimit({ subscription, posting_limit: session.posting_limit });
  const postsToday = numberOrZero(subscription.posts_today || session.posts_today || 0);
  const minimumVersion = clean(subscription.minimum_version || session.minimum_version || "");
  const latestVersion = clean(subscription.latest_version || session.latest_version || minimumVersion || getCurrentExtensionVersion());
  const updateRequired = subscription.update_required === true || (minimumVersion ? compareVersions(getCurrentExtensionVersion(), minimumVersion) < 0 : false);

  return {
    ...session,
    email: clean(session.email || user.email || "").toLowerCase(),
    user: {
      ...user,
      id: clean(user.id || session.user_id || ""),
      email: clean(user.email || session.email || "").toLowerCase()
    },
    subscription: {
      ...subscription,
      plan,
      normalized_plan: plan,
      active: Boolean(subscription.access_granted ?? subscription.active ?? (normalizeStatusValue(subscription.status) === "active")),
      access_granted: Boolean(subscription.access_granted ?? subscription.active ?? (normalizeStatusValue(subscription.status) === "active")),
      status: Boolean(subscription.access_granted ?? subscription.active ?? (normalizeStatusValue(subscription.status) === "active")) ? "active" : normalizeStatusValue(subscription.status || "inactive"),
      normalized_status: Boolean(subscription.access_granted ?? subscription.active ?? (normalizeStatusValue(subscription.status) === "active")) ? "active" : normalizeStatusValue(subscription.status || "inactive"),
      posting_limit: postingLimit,
      posts_today: postsToday,
      posts_remaining: Math.max(postingLimit - postsToday, 0),
      minimum_version: minimumVersion,
      latest_version: latestVersion,
      update_required: updateRequired,
      allowed_dealer_hosts: Array.isArray(subscription.allowed_dealer_hosts)
        ? subscription.allowed_dealer_hosts.map((x) => clean(x).toLowerCase()).filter(Boolean)
        : []
    },
    minimum_version: minimumVersion,
    latest_version: latestVersion,
    update_required: updateRequired,
    plan
  };
}

function getPlanName(session = null) {
  const raw = clean(
    session?.subscription?.plan ||
    session?.plan ||
    "starter"
  ).toLowerCase();

  if (raw.includes("pro")) return "pro";
  return "starter";
}

async function getPostedRegistry() {
  const data = await chromeGet([STORAGE_KEYS.POSTED_REGISTRY]);
  const list = Array.isArray(data[STORAGE_KEYS.POSTED_REGISTRY])
    ? data[STORAGE_KEYS.POSTED_REGISTRY]
    : [];
  return new Set(list.map((x) => clean(x)).filter(Boolean));
}

async function savePostedRegistry(registrySet) {
  await chromeSet({
    [STORAGE_KEYS.POSTED_REGISTRY]: Array.from(registrySet)
  });
}

async function getPostedRegistryArray() {
  const registry = await getPostedRegistry();
  return Array.from(registry).filter(Boolean);
}

function getPostStateKey(vehicleOrKey) {
  if (typeof vehicleOrKey === "string") return clean(vehicleOrKey);
  return buildVehicleKey(vehicleOrKey);
}

function sanitizePostStateRecord(record = {}, key = "") {
  const state = clean(record.state || "queued").toLowerCase() || "queued";
  return {
    key: clean(key || record.key || ""),
    state,
    updated_at: record.updated_at || new Date().toISOString(),
    attempt_count: numberOrZero(record.attempt_count),
    last_error: clean(record.last_error || ""),
    inflight_lock: Boolean(record.inflight_lock),
    vehicle_id: clean(record.vehicle_id || "")
  };
}

async function getPostStateMap() {
  const data = await chromeGet([STORAGE_KEYS.POST_STATE]);
  const raw = data[STORAGE_KEYS.POST_STATE];
  return raw && typeof raw === "object" ? raw : {};
}

async function savePostStateMap(map) {
  await chromeSet({
    [STORAGE_KEYS.POST_STATE]: map && typeof map === "object" ? map : {}
  });
}

async function getPostStateWorker(vehicleOrKey) {
  const key = getPostStateKey(vehicleOrKey);
  if (!key) return { ok: false, reason: "invalid_vehicle_key", record: null };

  const map = await getPostStateMap();
  return { ok: true, key, record: map[key] ? sanitizePostStateRecord(map[key], key) : null };
}

async function setPostStateWorker(vehicleOrKey, next = {}) {
  const key = getPostStateKey(vehicleOrKey);
  if (!key) return { ok: false, reason: "invalid_vehicle_key", record: null };

  const map = await getPostStateMap();
  const prev = map[key] ? sanitizePostStateRecord(map[key], key) : sanitizePostStateRecord({ key }, key);

  map[key] = sanitizePostStateRecord({
    ...prev,
    ...next,
    key,
    updated_at: new Date().toISOString()
  }, key);

  await savePostStateMap(map);
  return { ok: true, key, record: map[key] };
}

async function beginPostAttemptWorker(vehicleOrKey, meta = {}) {
  const key = getPostStateKey(vehicleOrKey);
  if (!key) return { ok: false, reason: "invalid_vehicle_key", record: null };

  const posted = await isVehiclePostedWorker(vehicleOrKey);
  if (posted?.posted) {
    return { ok: false, reason: "already_posted", key, record: null };
  }

  const map = await getPostStateMap();
  const prev = map[key] ? sanitizePostStateRecord(map[key], key) : sanitizePostStateRecord({ key }, key);

  if (prev.state === "posted") {
    return { ok: false, reason: "already_posted", key, record: prev };
  }

  if (prev.inflight_lock) {
    return { ok: false, reason: "inflight_locked", key, record: prev };
  }

  map[key] = sanitizePostStateRecord({
    ...prev,
    state: "posting",
    inflight_lock: true,
    attempt_count: numberOrZero(prev.attempt_count) + 1,
    vehicle_id: clean(meta.vehicle_id || prev.vehicle_id || "")
  }, key);

  await savePostStateMap(map);
  return { ok: true, key, record: map[key] };
}

async function confirmPostSuccessWorker(vehicleOrKey, meta = {}) {
  const key = getPostStateKey(vehicleOrKey);
  if (!key) return { ok: false, reason: "invalid_vehicle_key", record: null };

  const map = await getPostStateMap();
  const prev = map[key] ? sanitizePostStateRecord(map[key], key) : sanitizePostStateRecord({ key }, key);

  map[key] = sanitizePostStateRecord({
    ...prev,
    state: "posted",
    inflight_lock: false,
    last_error: "",
    vehicle_id: clean(meta.vehicle_id || prev.vehicle_id || "")
  }, key);

  await savePostStateMap(map);

  if (meta.vehicle) {
    await markVehiclePostedWorker(meta.vehicle);
  } else {
    const registry = await getPostedRegistry();
    registry.add(key);
    await savePostedRegistry(registry);
    await chromeSet({
      [STORAGE_KEYS.LAST_POSTED_VEHICLE_KEY]: key,
      [STORAGE_KEYS.LAST_POST_AT]: new Date().toISOString()
    });
  }

  let registerPost = { ok: false, skipped: true, reason: "no_vehicle" };
  if (meta.vehicle) {
    registerPost = await registerPostToServer({
      vehicle: meta.vehicle,
      vehicle_key: key,
      vehicle_id: clean(meta.vehicle_id || meta.vehicle?.vin || meta.vehicle?.stock || key),
      marketplace_listing_id: clean(meta.marketplace_listing_id || meta.vehicle?.marketplace_listing_id || ""),
      user_id: clean(meta.user_id || ""),
      email: clean(meta.email || "").toLowerCase(),
      posted_at: new Date().toISOString()
    });

    if (!registerPost.ok) {
      await queuePendingPostCommit({
        vehicle: meta.vehicle,
        vehicle_key: key,
        vehicle_id: clean(meta.vehicle_id || meta.vehicle?.vin || meta.vehicle?.stock || key),
        marketplace_listing_id: clean(meta.marketplace_listing_id || meta.vehicle?.marketplace_listing_id || ""),
        user_id: clean(meta.user_id || ""),
        email: clean(meta.email || "").toLowerCase(),
        posted_at: new Date().toISOString(),
        last_error: clean(registerPost.reason || registerPost.error || "register_failed")
      });
    }
  }

  let sync = { ok: false, skipped: true, reason: "no_vehicle" };

  if (meta.vehicle) {
    try {
      const state = await getState();
      const session = state.extensionSession || null;
      const postedVehicles = await getPostedRegistryArray();
      const listingRow = buildLifecycleListingRow({
        ...sanitizeVehicle(meta.vehicle),
        status: "posted",
        posted_at: new Date().toISOString()
      }, "posted");

      if (listingRow) {
        sync = await syncLifecycleToServer({
          partial_sync: true,
          sync_reason: "post_commit",
          user_id: clean(meta.user_id || session?.user?.id || ""),
          email: clean(meta.email || session?.user?.email || "").toLowerCase(),
          posting_limit: numberOrZero(session?.subscription?.posting_limit || 0),
          posts_today: numberOrZero(session?.subscription?.posts_today || 0),
        posts_remaining: Math.max(
  numberOrZero(session?.subscription?.posting_limit || 0) -
  numberOrZero(session?.subscription?.posts_today || 0),
  0
),
          active_listings: postedVehicles.length,
          lifecycle_updated_at: new Date().toISOString(),
          authoritative_posting_usage: false,
          listings: [listingRow]
        });
      }
    } catch (error) {
      sync = {
        ok: false,
        skipped: false,
        reason: "post_commit_sync_failed",
        detail: error?.message || String(error)
      };
    }
  }
  
  return { ok: true, key, record: map[key], register_post: registerPost, sync };
}

async function markPostFailedWorker(vehicleOrKey, meta = {}) {
  const key = getPostStateKey(vehicleOrKey);
  if (!key) return { ok: false, reason: "invalid_vehicle_key", record: null };

  const map = await getPostStateMap();
  const prev = map[key] ? sanitizePostStateRecord(map[key], key) : sanitizePostStateRecord({ key }, key);

  map[key] = sanitizePostStateRecord({
    ...prev,
    state: "failed",
    inflight_lock: false,
    last_error: clean(meta.error || meta.reason || prev.last_error || ""),
    vehicle_id: clean(meta.vehicle_id || prev.vehicle_id || "")
  }, key);

  await savePostStateMap(map);
  return { ok: true, key, record: map[key] };
}

async function clearStaleLocks(maxAgeMs = 120000) {
  const map = await getPostStateMap();
  const now = Date.now();

  Object.keys(map).forEach((k) => {
    const rec = map[k] || {};
    const ts = new Date(rec.updated_at || 0).getTime();

    if (rec.inflight_lock && ts && now - ts > maxAgeMs) {
      map[k] = sanitizePostStateRecord({
        ...rec,
        inflight_lock: false,
        state: "failed",
        last_error: clean(rec.last_error || "stale_lock_timeout"),
        updated_at: new Date().toISOString()
      }, k);
    }
  });

  await savePostStateMap(map);
}

async function markVehiclePostedWorker(vehicle) {
  const key = buildVehicleKey(vehicle);
  if (!key) {
    return { ok: false, error: "invalid_vehicle_key" };
  }

  const registry = await getPostedRegistry();
  registry.add(key);
  await savePostedRegistry(registry);
  await setPostStateWorker(key, { state: "posted", inflight_lock: false, last_error: "" });
  await chromeSet({
    [STORAGE_KEYS.LAST_POSTED_VEHICLE_KEY]: key,
    [STORAGE_KEYS.LAST_POST_AT]: new Date().toISOString()
  });

  return { ok: true, key };
}

async function isVehiclePostedWorker(vehicleOrKey) {
  const key = buildCanonicalVehicleKey(vehicleOrKey);
  if (!key) {
    return { ok: false, posted: false, error: "invalid_vehicle_key" };
  }

  const registry = await getPostedRegistry();
  return { ok: true, posted: registry.has(key), key };
}

async function setExtensionSession(session) {
  const sanitized = sanitizeSession(session);
  const stamp = new Date().toISOString();

  await chromeSet({
    [STORAGE_KEYS.EXTENSION_SESSION]: sanitized,
    [STORAGE_KEYS.SESSION_SNAPSHOT]: sanitized,
    [STORAGE_KEYS.LAST_EXTENSION_STATE_FETCH]: stamp
  });

  return {
    ok: true,
    success: true,
    session: sanitized,
    data: sanitized,
    fetched_at: stamp
  };
}

async function getExtensionSession() {
  const data = await chromeGet([
    STORAGE_KEYS.EXTENSION_SESSION,
    STORAGE_KEYS.SESSION_SNAPSHOT,
    STORAGE_KEYS.LAST_EXTENSION_STATE_FETCH
  ]);

  const session = sanitizeSession(
    data[STORAGE_KEYS.EXTENSION_SESSION] || data[STORAGE_KEYS.SESSION_SNAPSHOT] || null
  );

  return {
    ok: true,
    success: true,
    session,
    data: session,
    fetched_at: data[STORAGE_KEYS.LAST_EXTENSION_STATE_FETCH] || null
  };
}

async function getState() {
  const data = await chromeGet([
    STORAGE_KEYS.VEHICLE,
    STORAGE_KEYS.VEHICLE_QUEUE,
    STORAGE_KEYS.DW_FIELD_MAP,
    STORAGE_KEYS.EXTENSION_SESSION,
    STORAGE_KEYS.PIPELINE_CURRENT,
    STORAGE_KEYS.PIPELINE_QUEUE,
    STORAGE_KEYS.PIPELINE_PROFILE,
    STORAGE_KEYS.PIPELINE_INVENTORY,
    STORAGE_KEYS.SESSION_SNAPSHOT,
    STORAGE_KEYS.LAST_POSTED_VEHICLE_KEY,
    STORAGE_KEYS.LAST_POST_AT
  ]);

  const postedVehicles = await getPostedRegistryArray();

  return {
    vehicle: sanitizeVehicle(data[STORAGE_KEYS.PIPELINE_CURRENT] || data[STORAGE_KEYS.VEHICLE] || null),
    vehicleQueue: sanitizeQueue(data[STORAGE_KEYS.PIPELINE_QUEUE] || data[STORAGE_KEYS.VEHICLE_QUEUE] || []),
    dwFieldMap: data[STORAGE_KEYS.DW_FIELD_MAP] || {},
    extensionSession: sanitizeSession(data[STORAGE_KEYS.EXTENSION_SESSION] || data[STORAGE_KEYS.SESSION_SNAPSHOT] || null),
    profileSnapshot: sanitizeProfile(data[STORAGE_KEYS.PIPELINE_PROFILE] || null),
    inventorySnapshot: data[STORAGE_KEYS.PIPELINE_INVENTORY] || DEFAULT_STATE.inventorySnapshot,
    lastPostedVehicleKey: clean(data[STORAGE_KEYS.LAST_POSTED_VEHICLE_KEY] || ""),
    lastPostAt: data[STORAGE_KEYS.LAST_POST_AT] || null,
    postedVehicles,
    postedVehicleCount: postedVehicles.length
  };
}

async function saveCurrentVehicle(vehicle, source = "unknown") {
  const sanitized = sanitizeVehicle(vehicle);

  await chromeSet({
    [STORAGE_KEYS.VEHICLE]: sanitized,
    [STORAGE_KEYS.PIPELINE_CURRENT]: sanitized,
    [STORAGE_KEYS.PIPELINE_TRIGGER]: Date.now(),
    ea_last_vehicle_source: source
  });

  if (sanitized) {
    await setPostStateWorker(sanitized, { state: "prepared", inflight_lock: false });
  }

  return { ok: true, vehicle: sanitized };
}

async function saveQueue(queue) {
  const sanitized = sanitizeQueue(queue);

  await chromeSet({
    [STORAGE_KEYS.VEHICLE_QUEUE]: sanitized,
    [STORAGE_KEYS.PIPELINE_QUEUE]: sanitized
  });

  return { ok: true, queue: sanitized, queueLength: sanitized.length };
}

async function saveFieldMap(map) {
  const next = map && typeof map === "object" ? map : {};
  await chromeSet({ [STORAGE_KEYS.DW_FIELD_MAP]: next });
  return { ok: true, map: next };
}

async function saveProfileSnapshot(profile) {
  const sanitized = sanitizeProfile(profile);
  await chromeSet({ [STORAGE_KEYS.PIPELINE_PROFILE]: sanitized });
  return { ok: true, profile: sanitized };
}

async function syncInventory(snapshot) {
  const next = snapshot && typeof snapshot === "object" ? snapshot : {};
  await chromeSet({ [STORAGE_KEYS.PIPELINE_INVENTORY]: next });

  try {
    const rows = Object.values(next)
      .map((vehicle) => buildLifecycleListingRow(vehicle, clean(vehicle?.status || "active") || "active"))
      .filter(Boolean);

    if (rows.length) {
      await syncLifecycleToServer({
        partial_sync: true,
        sync_reason: "inventory_snapshot",
        active_listings: rows.filter((row) => !["sold", "deleted", "inactive"].includes(clean(row.status).toLowerCase())).length,
        lifecycle_updated_at: new Date().toISOString(),
        listings: rows
      });
    }
  } catch (error) {
    warn("syncInventory lifecycle mirror failed:", error?.message || error);
  }

  return { ok: true, snapshot: next };
}

async function loadNextQueueItem() {
  const state = await getState();
  const queue = sanitizeQueue(state.vehicleQueue || []);

  if (!queue.length) {
    return { ok: false, reason: "empty_queue", queue: [] };
  }

let next = null;

while (queue.length) {
  const candidate = queue.shift();
  const key = buildVehicleKey(candidate);
  const posted = await isVehiclePostedWorker(key);
  if (posted?.posted) continue;

  const postState = await getPostStateWorker(key);
  if (postState?.record?.inflight_lock) continue;

  next = candidate;
  break;
}

if (!next) {
  return { ok: false, reason: "no_valid_queue_items", queue: [] };
}

  await chromeSet({
    [STORAGE_KEYS.VEHICLE]: next,
    [STORAGE_KEYS.PIPELINE_CURRENT]: next,
    [STORAGE_KEYS.VEHICLE_QUEUE]: queue,
    [STORAGE_KEYS.PIPELINE_QUEUE]: queue,
    [STORAGE_KEYS.PIPELINE_TRIGGER]: Date.now()
  });

  return {
    ok: true,
    vehicle: next,
    queue,
    queueLength: queue.length,
    postingTrigger: Date.now()
  };
}

async function fetchPhotoAsDataUrl(url) {
  try {
    const response = await fetch(url, { credentials: "include" });
    const blob = await response.blob();

    const dataUrl = await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });

    return { ok: true, dataUrl };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

async function refreshExtensionState(options = {}) {
  const data = await chromeGet([STORAGE_KEYS.EXTENSION_SESSION, STORAGE_KEYS.SESSION_SNAPSHOT]);
  const cached = sanitizeSession(
    data[STORAGE_KEYS.EXTENSION_SESSION] || data[STORAGE_KEYS.SESSION_SNAPSHOT] || null
  );

  const email = clean(options?.email || cached?.user?.email || "").toLowerCase();
  const hostname = clean(options?.hostname || "");
  const pageUrl = clean(options?.pageUrl || "");
  const clientVersion = clean(options?.clientVersion || getCurrentExtensionVersion());

  if (!email) {
    return {
      ok: Boolean(cached),
      success: Boolean(cached),
      data: cached || null,
      session: cached || null,
      fetched_at: new Date().toISOString(),
      source: cached ? "cache" : "none"
    };
  }

  try {
    const url = new URL(`${API_BASE_URL}/api/extension-state`);
    url.searchParams.set("email", email);
    if (hostname) url.searchParams.set("hostname", hostname);
    if (pageUrl) url.searchParams.set("pageUrl", pageUrl);
    if (clientVersion) url.searchParams.set("clientVersion", clientVersion);

    const response = await fetch(url.toString(), { method: "GET", headers: { Accept: "application/json" } });
    const result = await response.json().catch(() => null);

    if (!response.ok || !result?.session) {
      throw new Error(result?.error || `extension_state_${response.status}`);
    }

    return await setExtensionSession(result.session);
  } catch (error) {
    warn("refreshExtensionState failed:", error?.message || error);
    await chromeSet({
      [STORAGE_KEYS.LAST_EXTENSION_STATE_FETCH]: new Date().toISOString(),
      [STORAGE_KEYS.SESSION_SNAPSHOT]: cached || null
    });

    return {
      ok: Boolean(cached),
      success: Boolean(cached),
      data: cached || null,
      session: cached || null,
      fetched_at: new Date().toISOString(),
      source: cached ? "cache" : "none",
      error: error?.message || String(error)
    };
  }
}

async function canUserPost(vehicle, session = null) {
  const key = buildVehicleKey(vehicle);
  if (!key) {
    return { ok: false, reason: "invalid_vehicle_key" };
  }

  const state = await getState();
  const activeSession = sanitizeSession(session || state.extensionSession || null);
  const limit = resolvePostingLimit(activeSession);
  const postsToday = numberOrZero(activeSession?.subscription?.posts_today || activeSession?.posts_today || 0);
  const registry = await getPostedRegistry();
  const alreadyPosted = registry.has(key);

  if (!activeSession?.subscription?.access_granted) {
    return { ok: false, reason: "inactive_access", limit, posts_today: postsToday, key };
  }

  if (activeSession?.subscription?.update_required) {
    return {
      ok: false,
      reason: "update_required",
      limit,
      posts_today: postsToday,
      key,
      minimum_version: activeSession?.subscription?.minimum_version || "",
      latest_version: activeSession?.subscription?.latest_version || ""
    };
  }

  if (alreadyPosted) {
    return { ok: false, reason: "already_posted", limit, posts_today: postsToday, key };
  }

  const postState = await getPostStateWorker(vehicle);
  if (postState?.record?.inflight_lock) {
    return { ok: false, reason: "inflight_locked", limit, posts_today: postsToday, key };
  }
  if (postsToday >= limit) {
    return { ok: false, reason: "limit_reached", limit, posts_today: postsToday, key };
  }

  return {
    ok: true,
    limit,
    posts_today: postsToday,
    posts_remaining: Math.max(limit - postsToday, 0),
    key
  };
}
function validateCompliance(vehicle = {}, profile = {}) {
  if (!profile || typeof profile !== "object") {
    return { ok: false, reason: "missing_profile" };
  }

  // HARD BLOCK — REQUIRED PROFILE DATA
  if (!clean(profile.salesperson_name)) {
    return { ok: false, reason: "missing_salesperson_name" };
  }

  if (!clean(profile.dealer_name)) {
    return { ok: false, reason: "missing_dealer_name" };
  }

  if (!clean(profile.dealer_phone)) {
    return { ok: false, reason: "missing_dealer_phone" };
  }

  const province = clean(profile.province || "").toUpperCase();
  const description = String(vehicle.description || "");

  if (province === "AB") {
    if (!description.includes("AMVIC Licensed Dealer")) {
      return { ok: false, reason: "missing_amvic" };
    }
  }

  if (province === "BC") {
    const lowerDesc = description.toLowerCase();

    const hasBcDisclosure =
      lowerDesc.includes("price does not include taxes or applicable fees") ||
      lowerDesc.includes("vehicle availability and pricing are subject to change") ||
      lowerDesc.includes("licensed motor dealer");

    if (!hasBcDisclosure) {
      return { ok: false, reason: "missing_bc_disclosure" };
    }
  }

  return { ok: true };
}

function buildLifecycleListingRow(vehicle, fallbackStatus = "posted") {
  const v = sanitizeVehicle(vehicle);
  if (!v) return null;

  const id = clean(v.id || buildVehicleKey(v));
  if (!id) return null;

  return {
    id,
    vin: clean(v.vin || ""),
    stock_number: clean(v.stock || ""),
    source_url: clean(v.source_url || v.sourceUrl || ""),
    image_url: clean(v.coverPhotoUrl || v.cover_photo_url || v.photoUrls?.[0] || ""),
    year: numberOrZero(v.year),
    make: clean(v.make || ""),
    model: clean(v.model || ""),
    trim: clean(v.trim || ""),
    vehicle_type: clean(v.vehicleType || v.vehicle_type || ""),
    body_style: clean(v.bodyStyle || v.body_style || ""),
    exterior_color: clean(v.exteriorColor || v.exterior_color || ""),
    fuel_type: clean(v.fuelType || v.fuel_type || ""),
    mileage: numberOrZero(v.mileage || v.kilometers || v.km),
    price: numberOrZero(v.price),
    title: clean(v.title || ""),
    status: clean(v.status || fallbackStatus || "posted").toLowerCase(),
    lifecycle_status: clean(v.lifecycle_status || "").toLowerCase(),
    review_bucket: clean(v.review_bucket || ""),
    posted_at: v.posted_at || v.created_at || v.prepared_at || new Date().toISOString(),
    views_count: numberOrZero(v.views_count ?? v.views ?? 0),
    messages_count: numberOrZero(v.messages_count ?? v.messages ?? 0)
  };
}

function buildLifecycleSummaryFromState(state, payload = {}) {
  const session = sanitizeSession(payload.session || state.extensionSession || null);
  const postingLimit = numberOrZero(payload.posting_limit) || resolvePostingLimit(session);

  const postsToday =
    numberOrZero(payload.posts_today) ||
    numberOrZero(session?.subscription?.posts_today) ||
    0;

  const postsRemaining =
    payload.posts_remaining != null
      ? numberOrZero(payload.posts_remaining)
      : Math.max(postingLimit - postsToday, 0);

  const inventorySnapshot = state.inventorySnapshot && typeof state.inventorySnapshot === "object"
    ? state.inventorySnapshot
    : {};
  const marketplaceListings = state.marketplaceListings && typeof state.marketplaceListings === "object"
    ? state.marketplaceListings
    : {};

  const snapshotRows = Object.values(inventorySnapshot)
    .map((vehicle) => buildLifecycleListingRow(vehicle, "posted"))
    .filter(Boolean);

  const marketplaceRows = Object.values(marketplaceListings)
    .map((row) => buildLifecycleListingRow(row?.vehicle || row, row?.status || row?.vehicle?.status || "active"))
    .filter(Boolean);

  const listingRows = Array.isArray(payload.listings) && payload.listings.length
    ? payload.listings.map((row) => buildLifecycleListingRow(row?.vehicle || row, row?.status || row?.vehicle?.status || "posted")).filter(Boolean)
    : (marketplaceRows.length ? marketplaceRows : snapshotRows);

  const activeListings =
    payload.active_listings != null
      ? numberOrZero(payload.active_listings)
      : listingRows.filter((row) => !["sold", "deleted", "inactive"].includes(clean(row.status).toLowerCase())).length;

  return {
    user_id: clean(payload.user_id || session?.user?.id || ""),
    email: clean(payload.email || session?.user?.email || "").toLowerCase(),
    dealership_id: clean(payload.dealership_id || ""),
    posts_today: postsToday,
    posts_this_month: numberOrZero(payload.posts_this_month),
    posting_limit: postingLimit,
    posts_remaining: postsRemaining,
    queue_count: payload.queue_count != null ? numberOrZero(payload.queue_count) : (state.vehicleQueue || []).length,
    active_listings: activeListings,
    total_views: payload.total_views != null ? numberOrZero(payload.total_views) : listingRows.reduce((sum, row) => sum + numberOrZero(row.views_count), 0),
    total_messages: payload.total_messages != null ? numberOrZero(payload.total_messages) : listingRows.reduce((sum, row) => sum + numberOrZero(row.messages_count), 0),
    stale_listings: numberOrZero(payload.stale_listings),
    review_queue_count: numberOrZero(payload.review_queue_count),
    review_new_count: numberOrZero(payload.review_new_count),
    review_delete_count: numberOrZero(payload.review_delete_count),
    review_price_change_count: numberOrZero(payload.review_price_change_count),
    lifecycle_updated_at: payload.lifecycle_updated_at || new Date().toISOString(),
    listings: listingRows
  };
}

function normalizeLifecyclePayload(payload = {}, state = null, session = null) {
  const activeState = state || {};
  const activeSession = sanitizeSession(session || payload.session || activeState.extensionSession || null);
  const summary = buildLifecycleSummaryFromState({ ...activeState, extensionSession: activeSession }, payload);
  const identity = resolveLifecycleIdentity(payload, activeSession);

  return {
    ...payload,
    ...summary,
    ...identity,
    partial_sync: payload.partial_sync === true,
    sync_reason: clean(payload.sync_reason || "lifecycle"),
    hostname: clean(payload.hostname || ""),
    page_url: clean(payload.page_url || ""),
    client_version: clean(payload.client_version || getCurrentExtensionVersion())
  };
}
function resolveLifecycleIdentity(payload = {}, session = null) {
  const activeSession = sanitizeSession(session || payload.session || null) || {};
  const user = activeSession.user || {};
  const profile = activeSession.profile || {};
  return {
    user_id: clean(payload.user_id || activeSession.user_id || user.id || ""),
    email: clean(payload.email || activeSession.email || user.email || profile.email || profile.dealer_email || "").toLowerCase(),
    dealership_id: clean(payload.dealership_id || activeSession.dealership_id || profile.dealership_id || "")
  };
}

async function getPendingPostCommits() {
  const data = await chromeGet([STORAGE_KEYS.PENDING_POST_COMMITS]);
  return Array.isArray(data[STORAGE_KEYS.PENDING_POST_COMMITS]) ? data[STORAGE_KEYS.PENDING_POST_COMMITS] : [];
}

async function savePendingPostCommits(queue = []) {
  await chromeSet({ [STORAGE_KEYS.PENDING_POST_COMMITS]: Array.isArray(queue) ? queue.slice(0, 100) : [] });
}

async function queuePendingPostCommit(payload = {}) {
  const queue = await getPendingPostCommits();
  const key = clean(payload.vehicle_key || buildVehicleKey(payload) || payload.marketplace_listing_id || payload.vehicle_id || `${Date.now()}`);
  const existingIndex = queue.findIndex((item) => clean(item.vehicle_key || buildVehicleKey(item)) === key);
  const next = {
    ...payload,
    vehicle_key: key,
    queued_at: payload.queued_at || new Date().toISOString(),
    retry_count: Number(payload.retry_count || 0)
  };
  if (existingIndex >= 0) {
    queue[existingIndex] = { ...queue[existingIndex], ...next }
  } else {
    queue.unshift(next)
  }
  await savePendingPostCommits(queue)
  return { ok: true, queued: queue.length, vehicle_key: key }
}

async function registerPostToServer(payload = {}) {
  const state = await getState();
  const session = sanitizeSession(payload.session || state.extensionSession || null);
  const vehicle = sanitizeVehicle(payload.vehicle || payload) || {};
  const userId = clean(payload.user_id || session?.user?.id || session?.user_id || "");
  const email = clean(payload.email || session?.user?.email || session?.email || "").toLowerCase();
  if (!userId && !email) {
    return { ok: false, reason: "missing_identity" };
  }

  const body = {
    user_id: userId,
    email,
    vehicle_id: clean(payload.vehicle_id || vehicle.vin || vehicle.stock || buildVehicleKey(vehicle)),
    marketplace_listing_id: clean(payload.marketplace_listing_id || vehicle.marketplace_listing_id || vehicle.vehicle_id || ""),
    vin: clean(payload.vin || vehicle.vin || ""),
    stock_number: clean(payload.stock_number || vehicle.stock || vehicle.stock_number || ""),
    source_url: clean(payload.source_url || vehicle.source_url || vehicle.sourceUrl || ""),
    image_url: clean(payload.image_url || vehicle.coverPhotoUrl || vehicle.cover_photo_url || vehicle.photoUrls?.[0] || ""),
    title: clean(payload.title || vehicle.title || ""),
    year: numberOrZero(payload.year || vehicle.year || 0),
    make: clean(payload.make || vehicle.make || ""),
    model: clean(payload.model || vehicle.model || ""),
    trim: clean(payload.trim || vehicle.trim || ""),
    price: numberOrZero(payload.price || vehicle.price || 0),
    mileage: numberOrZero(payload.mileage || vehicle.mileage || vehicle.kilometers || vehicle.km || 0),
    location: clean(payload.location || vehicle.location || vehicle.listing_location || ""),
    vehicle_type: clean(payload.vehicle_type || vehicle.vehicleType || vehicle.vehicle_type || ""),
    body_style: clean(payload.body_style || vehicle.bodyStyle || vehicle.body_style || ""),
    exterior_color: clean(payload.exterior_color || vehicle.exteriorColor || vehicle.exterior_color || ""),
    fuel_type: clean(payload.fuel_type || vehicle.fuelType || vehicle.fuel_type || ""),
    status: clean(payload.status || vehicle.status || "active") || "active",
    posted_at: clean(payload.posted_at || vehicle.posted_at || new Date().toISOString())
  };

  const res = await fetch(`${getApiBaseUrl()}/api/register-post`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data) {
    return { ok: false, reason: clean(data?.error || `register_post_${res.status}`), data };
  }

  const current = sanitizeSession((await getExtensionSession()).session || session || null);
  const fallbackLimit = resolvePostingLimit(current);
  const fallbackPostsToday = numberOrZero(data?.posts_used_today || data?.posting_state?.posts_today || current?.subscription?.posts_today || 0);
  const fallbackRemaining = Math.max(
    numberOrZero(data?.posting_state?.posts_remaining || 0) || (fallbackLimit - fallbackPostsToday),
    0
  );

  const next = sanitizeSession({
    ...(current || {}),
    subscription: {
      ...(current?.subscription || {}),
      plan: clean(data?.posting_state?.plan || data?.posting_state?.normalized_plan || current?.subscription?.plan || ""),
      normalized_plan: clean(data?.posting_state?.normalized_plan || data?.posting_state?.plan || current?.subscription?.normalized_plan || ""),
      status: clean(data?.posting_state?.status || data?.posting_state?.normalized_status || current?.subscription?.status || "active"),
      normalized_status: clean(data?.posting_state?.normalized_status || data?.posting_state?.status || current?.subscription?.normalized_status || "active"),
      active: Boolean(data?.posting_state?.active ?? data?.posting_state?.access_granted ?? current?.subscription?.active ?? true),
      access_granted: Boolean(data?.posting_state?.access_granted ?? data?.posting_state?.active ?? current?.subscription?.access_granted ?? true),
      posting_limit: numberOrZero(data?.posting_state?.posting_limit || data?.posting_state?.daily_posting_limit || current?.subscription?.posting_limit || fallbackLimit),
      daily_posting_limit: numberOrZero(data?.posting_state?.daily_posting_limit || data?.posting_state?.posting_limit || current?.subscription?.daily_posting_limit || fallbackLimit),
      posts_today: fallbackPostsToday,
      posts_remaining: fallbackRemaining
    }
  });
  await setExtensionSession(next);
  await chromeSet({
    elevate_posts_today: next?.subscription?.posts_today || 0,
    elevate_posting_limit: next?.subscription?.posting_limit || 0,
    elevate_extension_usage_snapshot: {
      posts_today: next?.subscription?.posts_today || 0,
      posting_limit: next?.subscription?.posting_limit || 0,
      posts_remaining: next?.subscription?.posts_remaining || 0
    },
    ea_last_post_commit: {
      at: clean(data?.posting_usage_updated_at || new Date().toISOString()),
      vehicle_key: clean(body.vehicle_key || payload.vehicle_key || ""),
      posts_today: next?.subscription?.posts_today || 0,
      posts_remaining: next?.subscription?.posts_remaining || 0,
      ok: true
    }
  });

  return { ok: true, data };
}

async function processPendingPostCommits(limit = 5) {
  const queue = await getPendingPostCommits();
  if (!queue.length) return { ok: true, processed: 0, remaining: 0 };
  const keep = [];
  let processed = 0;
  for (const item of queue) {
    if (processed >= limit) {
      keep.push(item);
      continue;
    }
    const attempt = await registerPostToServer(item);
    if (!attempt.ok) {
      keep.push({ ...item, retry_count: numberOrZero(item.retry_count) + 1, last_error: clean(attempt.reason || attempt.error || "commit_failed") });
    } else {
      processed += 1;
    }
  }
  await savePendingPostCommits(keep);
  return { ok: true, processed, remaining: keep.length };
}

async function syncLifecycleToServer(payload = {}) {
  try {
    const url =
      payload.url ||
      `${getApiBaseUrl()}/api/sync-lifecycle`;

    const state = await getState();
    const session = sanitizeSession(state.extensionSession || null);
    const normalized = normalizeLifecyclePayload(payload || {}, state, session);
    if (!clean(normalized.user_id) && !clean(normalized.email)) {
      warn("[lifecycle sync] skipped missing identity", normalized);
      return { ok: false, reason: "missing_identity", payload: normalized };
    }

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(normalized)
    });

    const data = await res.json().catch(() => null);

    if (!res.ok) {
      console.warn("[lifecycle sync] failed:", data || res.status, normalized);
      return { ok: false, payload: normalized };
    }

    return data || { ok: true, payload: normalized };
  } catch (e) {
    console.warn("[lifecycle sync] error:", e?.message || e);
    return { ok: false, error: e?.message || String(e) };
  }
}

 


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
            case "GET_STATE":
        await clearStaleLocks();
        await processPendingPostCommits();
        sendResponse(await getState());
        break;

      case "SAVE_CURRENT_VEHICLE":
        sendResponse(await saveCurrentVehicle(message.vehicle, message.source || "message"));
        break;

  

      case "SAVE_QUEUE":
        sendResponse(await saveQueue(message.queue));
        break;

      case "SAVE_FIELD_MAP":
        sendResponse(await saveFieldMap(message.map));
        break;

      case "SAVE_PROFILE_SNAPSHOT":
        sendResponse(await saveProfileSnapshot(message.profile));
        break;

      case "EA_SYNC_INVENTORY":
        sendResponse(await syncInventory(message.snapshot));
        break;

      case "LOAD_NEXT_QUEUE_ITEM":
        sendResponse(await loadNextQueueItem());
        break;

      case "FETCH_PHOTO_DATA_URL":
        sendResponse(await fetchPhotoAsDataUrl(message.url));
        break;

      case "REFRESH_EXTENSION_STATE":
        await processPendingPostCommits();
        sendResponse(await refreshExtensionState());
        break;

      case "EA_GET_EXTENSION_STATE":
        sendResponse(await getExtensionSession());
        break;

      case "EA_FETCH_EXTENSION_STATE":
        sendResponse(await refreshExtensionState(message || {}));
        break;

      case "SET_EXTENSION_SESSION":
        sendResponse(await setExtensionSession(message.session || message.data || null));
        break;

      case "GET_EXTENSION_SESSION":
        sendResponse(await getExtensionSession());
        break;

      case "MARK_VEHICLE_POSTED":
        sendResponse(await markVehiclePostedWorker(message.vehicle));
        break;

      case "REGISTER_POSTED_VEHICLE":
        sendResponse(await markVehiclePostedWorker(message.vehicle || message.payload || message.data || null));
        break;

      case "IS_VEHICLE_POSTED":
        sendResponse(await isVehiclePostedWorker(message.vehicle || message.key || ""));
        break;

      case "IS_ALREADY_POSTED":
        sendResponse(await isVehiclePostedWorker(message.vehicle || message.key || ""));
        break;

      case "GET_POSTED_VEHICLES": {
        const postedVehicles = await getPostedRegistryArray();
        sendResponse({
          ok: true,
          success: true,
          vehicles: postedVehicles,
          postedVehicles,
          count: postedVehicles.length
        });
        break;
      }

      case "CAN_POST":
        sendResponse(await canUserPost(message.vehicle, message.session));
        break;

      case "VALIDATE_COMPLIANCE":
        sendResponse(validateCompliance(message.vehicle, message.profile));
        break;

      case "UPSERT_MARKETPLACE_INSIGHTS": {
        try {
          const state = await getState();
          const merged = mergeMarketplaceListings(state.marketplaceListings || {}, message.listings || message.payload?.listings || []);
          await chromeSet({ [STORAGE_KEYS.MARKETPLACE_LISTINGS]: merged });
          const syncPayload = {
            ...(message.payload || {}),
            listings: Object.values(merged),
            total_views: Object.values(merged).reduce((sum, row) => sum + numberOrZero(row.views_count), 0),
            total_messages: Object.values(merged).reduce((sum, row) => sum + numberOrZero(row.messages_count), 0),
            active_listings: Object.values(merged).filter((row) => !["sold", "deleted", "inactive"].includes(clean(row.status).toLowerCase())).length,
            sync_reason: clean(message.payload?.sync_reason || message.sync_reason || "marketplace_insights"),
            hostname: clean(message.payload?.hostname || message.hostname || ""),
            page_url: clean(message.payload?.page_url || message.page_url || "")
          };
          sendResponse(await syncLifecycleToServer(syncPayload));
        } catch (error) {
          warn("[marketplace insights] upsert failed:", error?.message || error);
          sendResponse({ ok: false, error: error?.message || String(error) });
        }
        break;
      }

      case "SYNC_LIFECYCLE":
        sendResponse(await syncLifecycleToServer(message.payload || {}));
        break;

      case "GET_POST_STATE":
        sendResponse(await getPostStateWorker(message.vehicle || message.key || ""));
        break;

      case "SET_POST_STATE":
        sendResponse(await setPostStateWorker(message.vehicle || message.key || "", message.record || message.payload || {}));
        break;

      case "BEGIN_POST_ATTEMPT":
        sendResponse(await beginPostAttemptWorker(message.vehicle || message.key || "", {
          vehicle_id: message.vehicle_id || "",
          vehicle: message.vehicle || null
        }));
        break;

      case "CONFIRM_POST_SUCCESS":
        sendResponse(await confirmPostSuccessWorker(message.vehicle || message.key || "", {
          vehicle_id: message.vehicle_id || "",
          vehicle: message.vehicle || null
        }));
        break;

        case "MARK_POST_FAILED":
        sendResponse(await markPostFailedWorker(message.vehicle || message.key || "", {
          vehicle_id: message.vehicle_id || "",
          error: message.error || message.reason || "",
          vehicle: message.vehicle || null
        }));
        break;

      case "RESET_POST_LOCKS": {
        const map = await getPostStateMap();

        Object.keys(map).forEach((k) => {
          map[k].inflight_lock = false;
        });

        await savePostStateMap(map);
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({ ok: false, reason: "unknown_type" });
        break;
    }
  })();

  return true;
});
