// marketplace.js
// Elevate Automation Marketplace Assistant V13
// Locks the proven mapping/autofill flow, improves handoff sync, and filters bad photo assets before upload

(async function () {
  try {
    await chrome.runtime.sendMessage({ type: "RESET_POST_LOCKS" });
  } catch (error) {
    console.warn("RESET_POST_LOCKS failed:", error?.message || error);
  }

  if (!location.href.includes("facebook.com/marketplace")) return;

  const PANEL_ID = "eaMarketplaceAssistantV11";
  const STYLE_ID = "eaMarketplaceAssistantV11Styles";
  const MARKETPLACE_CREATE_VEHICLE_URL = "https://www.facebook.com/marketplace/create/vehicle";
  const PENDING_HANDOFF_KEY = "ea_pending_vehicle_handoff_v1";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  let vehicle = null;
  let fieldMap = {};
  let queue = [];
  let queueLen = 0;
  let extensionState = null;
  let postingGateState = null;

  let isAutofilling = false;
  let isUploadingPhotos = false;
  let isPastingCopy = false;
  let isMapping = false;

  let lastStatus = "Waiting for prepared vehicle payload.";
  let lastAppliedVehicleKey = "";
  let lastPhotoUploadVehicleKey = "";
  let lastDescriptionVehicleKey = "";
  let lastPublishRegisterVehicleKey = "";

  let postedVehicles = new Set(JSON.parse(localStorage.getItem("ea_posted") || "[]"));

  function markVehiclePosted(key) {
    if (!key) return;
    postedVehicles.add(key);
    localStorage.setItem("ea_posted", JSON.stringify([...postedVehicles]));
  }

  function isVehiclePosted(key) {
    if (!key) return false;
    return postedVehicles.has(key);
  }

  function getDailyLimit() {
    const rawPlan = lower(
      extensionState?.normalized_plan ||
      extensionState?.plan ||
      extensionState?.subscription?.normalized_plan ||
      extensionState?.subscription?.plan ||
      extensionState?.session_snapshot?.subscription?.normalized_plan ||
      extensionState?.session_snapshot?.subscription?.plan ||
      ""
    );

    if (!rawPlan) return 5;
    if ((rawPlan.includes("founder") && rawPlan.includes("pro")) || rawPlan === "pro" || (!rawPlan.includes("founder") && rawPlan.includes("pro"))) return 25;
    return 5;
  }

  function getPostsToday() {
    const today = Number(
      extensionState?.posts_today ??
      extensionState?.subscription?.posts_today ??
      extensionState?.session_snapshot?.subscription?.posts_today ??
      0
    );
    return Number.isFinite(today) ? today : 0;
  }

  function setPostsToday(nextValue) {
    const safe = Math.max(0, Number(nextValue || 0));

    if (!extensionState) extensionState = {};

    extensionState.posts_today = safe;

    if (!extensionState.subscription) extensionState.subscription = {};
    extensionState.subscription.posts_today = safe;

    if (!extensionState.posting_limit) {
      extensionState.posting_limit = getDailyLimit();
    }

    if (!extensionState.subscription.posting_limit) {
      extensionState.subscription.posting_limit = extensionState.posting_limit;
    }

    if (!extensionState.session_snapshot) extensionState.session_snapshot = {};
    if (!extensionState.session_snapshot.subscription) {
      extensionState.session_snapshot.subscription = {};
    }

    extensionState.session_snapshot.subscription.posts_today = safe;
    extensionState.session_snapshot.subscription.posting_limit =
      extensionState.session_snapshot.subscription.posting_limit || getDailyLimit();
  }

  async function persistPostingUsage() {
    try {
      const postsToday = getPostsToday();
      const postingLimit = Number(
        extensionState?.posting_limit ||
        extensionState?.subscription?.posting_limit ||
        extensionState?.session_snapshot?.subscription?.posting_limit ||
        getDailyLimit()
      );

      localStorage.setItem("ea_posts_today", String(postsToday));
      localStorage.setItem("ea_posting_limit", String(postingLimit));

      await chrome.storage.local.set({
        elevate_posted_vehicles: [...postedVehicles],
        elevate_posts_today: postsToday,
        elevate_posting_limit: postingLimit,
        elevate_extension_usage_snapshot: {
          posts_today: postsToday,
          posting_limit: postingLimit,
          posts_remaining: Math.max(postingLimit - postsToday, 0)
        }
      });
    } catch (error) {
      warn("persistPostingUsage failed:", error?.message || error);
    }
  }


  function extractMarketplaceListingId() {
    const match = location.pathname.match(/\/marketplace\/item\/(\d+)/i);
    return match ? match[1] : "";
  }

  function extractVisibleViewsCount() {
    const pageText = (document.body?.innerText || '').replace(/ /g, ' ');
    const patterns = [/(\d[\d,]*)\s+views?/i, /views?\s*(\d[\d,]*)/i];
    for (const pattern of patterns) {
      const match = pageText.match(pattern);
      if (match?.[1]) {
        const value = Number(String(match[1]).replace(/,/g, ''));
        if (Number.isFinite(value)) return value;
      }
    }
    return 0;
  }

  let lastListingViewSyncKey = '';
  async function syncListingViewSnapshot(reason = 'observer') {
    try {
      const marketplaceListingId = extractMarketplaceListingId();
      if (!marketplaceListingId) return;
      const views = extractVisibleViewsCount();
      if (!Number.isFinite(views) || views <= 0) return;
      const syncKey = `${marketplaceListingId}:${views}`;
      if (syncKey === lastListingViewSyncKey) return;
      lastListingViewSyncKey = syncKey;
      await chrome.runtime.sendMessage({
        type: 'EA_LOG_USAGE',
        payload: {
          action: 'listing_view_sync',
          metadata: {
            marketplace_listing_id: marketplaceListingId,
            source_url: location.href,
            views_count: views,
            reason
          }
        }
      });
    } catch (error) {
      warn('listing view sync failed:', error?.message || error);
    }
  }

  function startListingViewSyncLoop() {
    if (!location.pathname.match(/\/marketplace\/item\//i)) return;
    syncListingViewSnapshot('boot');
    setInterval(() => syncListingViewSnapshot('interval'), 5000);
    const observer = new MutationObserver(() => {
      syncListingViewSnapshot('mutation');
    });
    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  const FIELD_ORDER = [
    { key: "vehicleType", label: "Vehicle Type" },
    { key: "location", label: "Location" },
    { key: "year", label: "Year" },
    { key: "make", label: "Make" },
    { key: "model", label: "Model" },
    { key: "kilometers", label: "Mileage" },
    { key: "price", label: "Price" },
    { key: "bodyStyle", label: "Body Style" },
    { key: "exteriorColor", label: "Exterior Colour" },
    { key: "fuelType", label: "Fuel Type" },
    { key: "description", label: "Description" }
  ];

  function log(...args) {
    console.log("[Elevate Marketplace V13]", ...args);
  }

  function warn(...args) {
    console.warn("[Elevate Marketplace V13]", ...args);
  }

  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function lower(v) {
    return clean(v).toLowerCase();
  }

  function digitsOnly(v) {
    return String(v || "").replace(/[^\d]/g, "");
  }

  function money(v) {
    const n = Number(digitsOnly(v));
    if (!Number.isFinite(n) || n <= 0) return "—";
    return `$${n.toLocaleString()}`;
  }

  function km(v) {
    const n = Number(digitsOnly(v));
    if (!Number.isFinite(n) || n < 0) return "—";
    return `${n.toLocaleString()} KM`;
  }

  function escapeHtml(str) {
    return String(str || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function getVehicleKey(v) {
    if (!v) return "";
    return [
      clean(v.vin || ""),
      clean(v.stock || ""),
      clean(v.year || ""),
      clean(v.make || ""),
      clean(v.model || ""),
      clean(v.trim || ""),
      digitsOnly(v.price || ""),
      digitsOnly(v.km || v.kilometers || v.mileage || "")
    ].join("|");
  }

  function isCreateVehiclePage() {
    return lower(location.href || "").includes("/marketplace/create/vehicle");
  }

  async function getPendingVehicleHandoff() {
    try {
      const data = await chrome.storage.local.get([PENDING_HANDOFF_KEY]);
      return data?.[PENDING_HANDOFF_KEY] || null;
    } catch {
      return null;
    }
  }

  async function setPendingVehicleHandoff(nextVehicle, meta = {}) {
    const prepared = aliasVehicleFields(nextVehicle || null);
    const key = getVehicleKey(prepared);
    if (!key || !prepared) return null;

    const payload = {
      key,
      vehicle: prepared,
      created_at: new Date().toISOString(),
      attempts: Number(meta.attempts || 0),
      reason: clean(meta.reason || "post_handoff") || "post_handoff"
    };

    await chrome.storage.local.set({ [PENDING_HANDOFF_KEY]: payload });
    return payload;
  }

  async function clearPendingVehicleHandoff(vehicleKey = "") {
    try {
      const active = await getPendingVehicleHandoff();
      if (vehicleKey && active?.key && active.key !== vehicleKey) return false;
      await chrome.storage.local.remove([PENDING_HANDOFF_KEY]);
      return true;
    } catch {
      return false;
    }
  }

  function isVehiclePreparedForPosting(vehicleKey = "") {
    const key = clean(vehicleKey || "");
    if (!key) return false;
    return lastDescriptionVehicleKey === key && lastPhotoUploadVehicleKey === key;
  }

  function normalizeColor(value) {
    const raw = lower(value);
    if (!raw) return "";

    // Only trust explicit exterior markers first
    const extMatch = raw.match(/ext(?:erior)?\s*[:\-]?\s*([a-z ]+)/i);

    if (extMatch && extMatch[1]) {
      const color = extMatch[1].trim();

      if (color.includes("black")) return "Black";
      if (color.includes("white")) return "White";
      if (color.includes("silver")) return "Silver";
      if (color.includes("grey") || color.includes("gray")) return "Grey";
      if (color.includes("blue")) return "Blue";
      if (color.includes("red")) return "Red";
      if (color.includes("green")) return "Green";
      if (color.includes("brown")) return "Brown";
      if (color.includes("orange")) return "Orange";
      if (color.includes("yellow") || color.includes("gold")) return "Yellow";
      if (color.includes("beige") || color.includes("tan")) return "Beige";
      if (color.includes("purple")) return "Purple";

      return clean(color);
    }

    // Hard block interior-only strings from becoming exterior colour
    if (raw.includes("int") || raw.includes("interior")) {
      return "";
    }

    return clean(value);
  }

  function normalizeFuelType(value) {
    const raw = lower(value);

    if ((raw.includes("plug-in") || raw.includes("plugin") || raw.includes("phev")) && raw.includes("hybrid")) {
      return "Plug-in hybrid";
    }
    if (raw.includes("hybrid") || raw.includes("i-force max")) return "Hybrid";
    if (raw.includes("electric") || raw.includes("ev")) return "Electric";
    if (raw.includes("diesel") || raw.includes("tdi") || raw.includes("duramax") || raw.includes("cummins") || raw.includes("powerstroke")) {
      return "Diesel";
    }
    if (raw.includes("gasoline") || raw.includes("gas") || raw.includes("petrol")) return "Gasoline";

    return clean(value) || "Gasoline";
  }

  function normalizeBodyStyle(value, title = "") {
    const hay = `${value || ""} ${title || ""}`.toLowerCase();

    if (hay.includes("truck") || hay.includes("pickup")) return "Truck";
    if (hay.includes("suv") || hay.includes("crossover")) return "SUV";
    if (hay.includes("sedan")) return "Sedan";
    if (hay.includes("coupe")) return "Coupe";
    if (hay.includes("hatchback") || hay.includes("hatch")) return "Hatchback";
    if (hay.includes("wagon")) return "Wagon";
    if (hay.includes("convertible") || hay.includes("roadster") || hay.includes("cabriolet")) return "Convertible";
    if (hay.includes("van") || hay.includes("minivan")) return "Van/Minivan";

    return clean(value);
  }

  function detectMarketplaceVehicleType(v) {
    const hay = [
      v?.title || "",
      v?.vehicle_type || "",
      v?.vehicleType || "",
      v?.body_style || "",
      v?.bodyStyle || "",
      v?.make || "",
      v?.model || "",
      v?.trim || ""
    ].join(" ").toLowerCase();

    if (/motorcycle|harley|ninja|cbr|gsxr|ducati|kawasaki/.test(hay)) return "Motorcycle";
    if (/powersport|atv|utv|side-by-side|side by side|rzr|ski-doo|sea-doo|snowmobile/.test(hay)) return "Powersport";
    if (/rv|camper|motorhome|travel trailer|fifth wheel/.test(hay)) return "RV/Camper";
    if (/\btrailer\b|utility trailer|dump trailer|enclosed trailer/.test(hay)) return "Trailer";
    if (/\bboat\b|pontoon|wake boat|fishing boat/.test(hay)) return "Boat";
    if (/commercial|industrial|forklift|excavator|loader|service truck|work truck/.test(hay)) return "Commercial/Industrial";

    return "Car/Truck";
  }

  function aliasVehicleFields(v) {
    const out = { ...(v || {}) };

    out.title = clean(out.title || [out.year, out.make, out.model, out.trim].filter(Boolean).join(" "));
    out.year = clean(out.year || "");
    out.make = clean(out.make || "");
    out.model = clean(out.model || "");
    out.trim = clean(out.trim || "");
    out.stock = clean(out.stock || out.stock_number || "");
    out.vin = clean(out.vin || "").toUpperCase();
    out.price = digitsOnly(out.price || "");
    out.kilometers = digitsOnly(out.kilometers || out.km || out.mileage || "");
    out.km = out.kilometers;
    out.location = clean(out.location || out.listing_location || "");
    out.listing_location = clean(out.listing_location || out.location || "");
    out.exteriorColor = normalizeColor(out.exteriorColor || out.exterior_color || out.color || "");
    out.bodyStyle = normalizeBodyStyle(out.bodyStyle || out.body_style || out.body || "", out.title);
    out.fuelType = normalizeFuelType(out.fuelType || out.fuel_type || out.fuel || "");
    out.vehicleType = clean(out.vehicleType || out.vehicle_type || "") || detectMarketplaceVehicleType(out);
    out.photoUrls = Array.isArray(out.photoUrls) ? out.photoUrls.filter(Boolean) : [];
    out.coverPhotoUrl = clean(out.coverPhotoUrl || out.cover_photo_url || out.photoUrls?.[0] || "");
    out.dealer_name = clean(out.dealer_name || out.dealership || out.profile?.dealer_name || out.profile?.dealership || "");
    out.dealership = clean(out.dealership || out.dealer_name || out.profile?.dealership || out.profile?.dealer_name || "");
    out.dealer_email = clean(out.dealer_email || out.profile?.dealer_email || "");
    out.dealer_phone = clean(out.dealer_phone || out.phone || out.profile?.dealer_phone || out.profile?.phone || "");
    out.salesperson_name = clean(out.salesperson_name || out.full_name || out.profile?.full_name || "");
    return out;
  }

  function looksLikeBadPhotoUrl(url) {
    const raw = lower(url);
    if (!raw) return true;

    const hardRejectPatterns = [
      'logo', 'brand', 'placeholder', 'no-image', 'no_image', 'stock-photo', 'stockphoto',
      'icon', 'sprite', 'favicon', 'dealeron', 'watermark-only', 'frame-only'
    ];

    if (hardRejectPatterns.some((p) => raw.includes(p))) return true;
    if (raw.includes('/logo/') || raw.includes('/logos/') || raw.includes('/brand/')) return true;
    return false;
  }

  async function inspectPhotoCandidate(url) {
    return await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const width = img.naturalWidth || img.width || 0;
        const height = img.naturalHeight || img.height || 0;
        const ratio = height ? width / height : 0;
        const small = width < 520 || height < 340;
        const tooWide = ratio > 2.65;
        const tooTall = ratio < 0.65;
        const likelyLogo = ratio > 0.82 && ratio < 1.18 && width < 900 && height < 900;
        resolve({ ok: !(small || tooWide || tooTall || likelyLogo), width, height, ratio });
      };
      img.onerror = () => resolve({ ok: false, width: 0, height: 0, ratio: 0 });
      img.src = url;
    });
  }

   async function sanitizePhotoSources(urls) {
    const cleaned = [];
    const seen = new Set();

    for (const original of Array.isArray(urls) ? urls : []) {
      const url = clean(original);

      if (!url) continue;
      const key = url.split("?")[0];
      if (seen.has(key)) continue;
      seen.add(key);

      if (looksLikeBadPhotoUrl(url)) continue;

      const info = await inspectPhotoCandidate(url);
      if (!info.ok) continue;

      cleaned.push(url);
      if (cleaned.length >= 20) break;
    }

    return cleaned;
  }

  const PHOTO_VISUAL_DHASH_MAX_DISTANCE = 14;
  const PHOTO_VISUAL_AHASH_MAX_DISTANCE = 10;
  const PHOTO_HASH_CROP = { top: 0.10, bottom: 0.10, left: 0.02, right: 0.02 };

  function normalizeUrlForDedupe(url) {
    if (!url || typeof url !== "string") return "";
    try {
      const u = new URL(url, location.origin);
      u.search = "";
      return u.toString();
    } catch {
      return url.split("?")[0];
    }
  }

  async function sha256HexFromFile(file) {
    const buf = await file.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", buf);
    const bytes = new Uint8Array(digest);
    let hex = "";
    for (let i = 0; i < bytes.length; i++) {
      hex += bytes[i].toString(16).padStart(2, "0");
    }
    return hex;
  }

  function hammingDistance64(a, b) {
    let x = a ^ b;
    let count = 0;
    while (x) {
      x &= x - 1n;
      count++;
      if (count > 64) break;
    }
    return count;
  }

  function isNearDuplicate64(newHash, hashes, maxDistance) {
    for (const oldHash of hashes) {
      if (hammingDistance64(newHash, oldHash) <= maxDistance) return true;
    }
    return false;
  }

  async function createCroppedBitmapFromFile(file, crop = PHOTO_HASH_CROP) {
    const bitmap = await createImageBitmap(file);

    const sx = Math.floor(bitmap.width * (crop.left ?? 0));
    const sy = Math.floor(bitmap.height * (crop.top ?? 0));
    const sw = Math.max(1, Math.floor(bitmap.width * (1 - (crop.left ?? 0) - (crop.right ?? 0))));
    const sh = Math.max(1, Math.floor(bitmap.height * (1 - (crop.top ?? 0) - (crop.bottom ?? 0))));

    const canvas = document.createElement("canvas");
    canvas.width = sw;
    canvas.height = sh;

    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);

    bitmap.close?.();

    return canvas;
  }

  function computeDHashFromCanvas(canvas) {
    const w = 9;
    const h = 8;

    const tmp = document.createElement("canvas");
    tmp.width = w;
    tmp.height = h;

    const ctx = tmp.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(canvas, 0, 0, w, h);

    const { data } = ctx.getImageData(0, 0, w, h);

    const lum = new Float32Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        lum[y * w + x] = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
      }
    }

    let hash = 0n;
    let bit = 0n;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      for (let x = 0; x < w - 1; x++) {
        if (lum[row + x] > lum[row + x + 1]) hash |= 1n << bit;
        bit++;
      }
    }
    return hash;
  }

  function computeAHashFromCanvas(canvas) {
    const w = 8;
    const h = 8;

    const tmp = document.createElement("canvas");
    tmp.width = w;
    tmp.height = h;

    const ctx = tmp.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(canvas, 0, 0, w, h);

    const { data } = ctx.getImageData(0, 0, w, h);

    const lum = new Float32Array(w * h);
    let sum = 0;
    for (let i = 0; i < w * h; i++) {
      const j = i * 4;
      const v = 0.2126 * data[j] + 0.7152 * data[j + 1] + 0.0722 * data[j + 2];
      lum[i] = v;
      sum += v;
    }
    const avg = sum / lum.length;

    let hash = 0n;
    for (let i = 0; i < lum.length; i++) {
      if (lum[i] >= avg) hash |= 1n << BigInt(i);
    }
    return hash;
  }

  async function computeVisualHashes(file) {
    const croppedCanvas = await createCroppedBitmapFromFile(file, PHOTO_HASH_CROP);
    return {
      dhash: computeDHashFromCanvas(croppedCanvas),
      ahash: computeAHashFromCanvas(croppedCanvas),
    };
  }

  function buildPhotoCandidates(vehicle) {
    const urls = Array.isArray(vehicle?.photoUrls) ? vehicle.photoUrls : [];
    const cover = vehicle?.coverPhotoUrl ? [vehicle.coverPhotoUrl] : [];

    const normalized = new Set(urls.map(normalizeUrlForDedupe));
    const final = [...urls];

    for (const c of cover) {
      const n = normalizeUrlForDedupe(c);
      if (!n || normalized.has(n)) continue;
      final.unshift(c);
      normalized.add(n);
    }

    return final;
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${PANEL_ID}{
        position:fixed;
        top:18px;
        right:18px;
        width:390px;
        max-height:88vh;
        overflow:auto;
        z-index:999999;
        background:linear-gradient(180deg,#101114 0%,#171a21 100%);
        border:1px solid rgba(212,175,55,.22);
        border-radius:18px;
        box-shadow:0 18px 45px rgba(0,0,0,.42);
        color:#fff;
        font-family:Inter,Arial,sans-serif;
      }
      #${PANEL_ID} .ea-head{
        padding:18px 18px 12px;
        border-bottom:1px solid rgba(255,255,255,.05);
        display:flex;
        justify-content:space-between;
        gap:12px;
        align-items:flex-start;
      }
      #${PANEL_ID} .ea-eyebrow{
        font-size:11px;
        letter-spacing:.14em;
        color:#d4af37;
        font-weight:700;
        margin-bottom:6px;
      }
      #${PANEL_ID} .ea-title{
        font-size:16px;
        font-weight:800;
        line-height:1.15;
      }
      #${PANEL_ID} .ea-sub{
        font-size:12px;
        color:rgba(255,255,255,.62);
        margin-top:4px;
      }
      #${PANEL_ID} .ea-badge{
        padding:7px 10px;
        border-radius:999px;
        font-size:11px;
        font-weight:700;
      }
      #${PANEL_ID} .ea-badge--good{
        background:#183a25;
        color:#b8f3c7;
      }
      #${PANEL_ID} .ea-badge--bad{
        background:#4b2f2f;
        color:#ffd5d5;
      }
      #${PANEL_ID} .ea-body{
        padding:16px;
        display:grid;
        gap:14px;
      }
      #${PANEL_ID} .ea-card{
        background:#171920;
        border:1px solid rgba(255,255,255,.05);
        border-radius:14px;
        padding:14px;
      }
      #${PANEL_ID} .ea-card-title{
        font-size:14px;
        font-weight:800;
        color:#d4af37;
        margin-bottom:10px;
      }
      #${PANEL_ID} .ea-grid-2{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:8px;
      }
      #${PANEL_ID} .ea-stat{
        background:#111318;
        border:1px solid rgba(255,255,255,.04);
        border-radius:10px;
        padding:10px;
      }
      #${PANEL_ID} .ea-stat-label{
        font-size:10px;
        color:#d4af37;
        letter-spacing:.10em;
        font-weight:700;
        margin-bottom:6px;
      }
      #${PANEL_ID} .ea-stat-value{
        font-size:13px;
        font-weight:800;
        line-height:1.25;
      }
      #${PANEL_ID} .ea-actions{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:10px;
      }
      #${PANEL_ID} .ea-btn{
        border:none;
        border-radius:12px;
        padding:12px;
        font-weight:800;
        cursor:pointer;
      }
      #${PANEL_ID} .ea-btn--primary{
        background:linear-gradient(135deg,#d4af37,#b78d20);
        color:#101114;
      }
      #${PANEL_ID} .ea-btn--secondary{
        background:#21242d;
        border:1px solid rgba(255,255,255,.08);
        color:#fff;
      }
      #${PANEL_ID} .ea-note{
        margin-top:10px;
        font-size:12px;
        color:#d4af37;
        min-height:16px;
      }
      #${PANEL_ID} .ea-field-list{
        display:grid;
        gap:6px;
        font-size:12px;
        color:rgba(255,255,255,.86);
      }
      #${PANEL_ID} .ea-field-row{
        display:grid;
        grid-template-columns:120px 1fr;
        gap:10px;
      }
      #${PANEL_ID} .ea-field-label{
        color:#d4af37;
        font-weight:700;
      }
      #${PANEL_ID} .ea-field-value{
        color:#fff;
      }
      #${PANEL_ID} .ea-copy-preview{
        white-space:pre-wrap;
        font-size:11px;
        color:rgba(255,255,255,.76);
        max-height:160px;
        overflow:auto;
      }
    `;
    document.head.appendChild(style);
  }

  function ensurePanel() {
    injectStyles();

    let panel = document.getElementById(PANEL_ID);
    if (!panel) {
      panel = document.createElement("div");
      panel.id = PANEL_ID;
      document.body.appendChild(panel);
    }
    return panel;
  }

  function goBackToCreateVehicle() {
    try {
      if (location.href.includes("/marketplace/create/vehicle")) {
        window.location.reload();
        return;
      }

      window.location.replace(MARKETPLACE_CREATE_VEHICLE_URL);

      setTimeout(() => {
        try {
          if (!location.href.includes("/marketplace/create/vehicle")) {
            window.location.href = MARKETPLACE_CREATE_VEHICLE_URL;
          }
        } catch (error) {
          warn("goBackToCreateVehicle fallback failed:", error?.message || error);
        }
      }, 1800);
    } catch (error) {
      warn("goBackToCreateVehicle failed:", error?.message || error);
      try {
        window.location.reload();
      } catch {}
    }
  }

  function toast(message) {
    lastStatus = clean(message || "");
    renderPanel();
  }

  async function getState() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_STATE" }, resolve);
    });
  }

  async function saveFieldMap() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "SAVE_FIELD_MAP", map: fieldMap }, resolve);
    });
  }

  async function loadExtensionState() {
    try {
      if (!window.ElevateExtensionSession?.getExtensionState) {
        extensionState = null;
        return;
      }

      const result = await window.ElevateExtensionSession.getExtensionState();
      extensionState = result?.success ? (result.data || null) : null;

      if (!extensionState) extensionState = {};

      const storedPostsToday = Number(localStorage.getItem("ea_posts_today") || "0");
      const storedPostingLimit = Number(localStorage.getItem("ea_posting_limit") || "0");

      if (!extensionState.posts_today && storedPostsToday) {
        extensionState.posts_today = storedPostsToday;
      }

      if (!extensionState.posting_limit && storedPostingLimit) {
        extensionState.posting_limit = storedPostingLimit;
      }

      if (!extensionState.posting_limit) {
        extensionState.posting_limit = getDailyLimit();
      }

      if (!extensionState.subscription) extensionState.subscription = {};
      if (!extensionState.subscription.posting_limit) {
        extensionState.subscription.posting_limit = extensionState.posting_limit;
      }
      if (extensionState.subscription.posts_today == null) {
        extensionState.subscription.posts_today = Number(extensionState.posts_today || 0);
      }
    } catch (error) {
      warn("loadExtensionState failed:", error?.message || error);
      extensionState = null;
    }
  }

  function getProfile() {
    const profile = extensionState?.profile || {};
    return {
      ...profile,
      dealership: clean(profile?.dealership || profile?.dealer_name || vehicle?.dealership || vehicle?.dealer_name || ""),
      dealer_name: clean(profile?.dealer_name || profile?.dealership || vehicle?.dealer_name || vehicle?.dealership || ""),
      dealer_email: clean(profile?.dealer_email || vehicle?.dealer_email || ""),
      phone: clean(profile?.phone || profile?.dealer_phone || vehicle?.dealer_phone || vehicle?.phone || ""),
      listing_location: clean(profile?.listing_location || vehicle?.location || vehicle?.listing_location || "")
    };
  }

  function resolvePostingLocation() {
    const profile = getProfile();
    return clean(profile?.listing_location || vehicle?.location || vehicle?.listing_location || "Grande Prairie, Alberta");
  }

  function stateBadgeHtml() {
    if (!extensionState) {
      return `<span class="ea-badge ea-badge--bad">No session</span>`;
    }
    if (!extensionState.access) {
      return `<span class="ea-badge ea-badge--bad">Access inactive</span>`;
    }
    return `<span class="ea-badge ea-badge--good">Ready</span>`;
  }

  function buildDescriptionRaw(v) {
    const profile = getProfile();

    if (window.ElevateDescriptionBuilder?.buildDescription) {
      try {
        return window.ElevateDescriptionBuilder.buildDescription(
          {
            ...v,
            location: resolvePostingLocation(),
            bodyStyle: normalizeBodyStyle(v.bodyStyle, v.title),
            exteriorColor: normalizeColor(v.exteriorColor),
            fuelType: normalizeFuelType(v.fuelType)
          },
          profile
        );
      } catch (error) {
        warn("buildDescription failed:", error?.message || error);
      }
    }

    const title = clean([v.year, v.make, v.model, v.trim].filter(Boolean).join(" "));
    return [
      title,
      money(v.price) !== "—" ? `Price: ${money(v.price)}` : "",
      km(v.kilometers) !== "—" ? `Mileage: ${km(v.kilometers)}` : "",
      resolvePostingLocation() ? `Location: ${resolvePostingLocation()}` : "",
      "Message for availability, financing, and trade options.",
      profile?.full_name ? `Contact: ${profile.full_name}` : "",
      profile?.phone ? `Phone: ${profile.phone}` : "",
      profile?.dealer_email ? `Email: ${profile.dealer_email}` : "",
      profile?.dealership ? profile.dealership : ""
    ].filter(Boolean).join("\n");
  }

  function miniStat(label, value) {
    return `
      <div class="ea-stat">
        <div class="ea-stat-label">${escapeHtml(label)}</div>
        <div class="ea-stat-value">${escapeHtml(value)}</div>
      </div>
    `;
  }

  function renderPanel() {
    const panel = ensurePanel();
    const profile = getProfile();
    const hasVehicle = !!vehicle;
    const descriptionPreview = hasVehicle ? buildDescriptionRaw(vehicle) : "";
    const postingLimit = Number(
      extensionState?.posting_limit ||
      extensionState?.subscription?.posting_limit ||
      extensionState?.session_snapshot?.subscription?.posting_limit ||
      getDailyLimit()
    );
    const postsToday = getPostsToday();
    const remaining = Math.max(postingLimit - postsToday, 0);

    panel.innerHTML = `
      <div class="ea-head">
        <div>
          <div class="ea-eyebrow">ELEVATE AUTOMATION</div>
          <div class="ea-title">Marketplace Assistant</div>
          <div class="ea-sub">Prepared posting payload + smart fill controls</div>
        </div>
        ${stateBadgeHtml()}
      </div>

      <div class="ea-body">
        <div class="ea-card">
          <div class="ea-card-title">Posting Status</div>
          <div class="ea-grid-2">
            ${miniStat("Photos", String(vehicle?.photoUrls?.length || (vehicle?.coverPhotoUrl ? 1 : 0) || 0))}
            ${miniStat("Queue", String(queueLen))}
            ${miniStat("Mapped", `${FIELD_ORDER.filter((f) => fieldMap[f.key]).length}/11`)}
            ${miniStat("Remaining", String(remaining))}
          </div>
          <div class="ea-note">${escapeHtml(lastStatus || "Ready.")}</div>
        </div>

        <div class="ea-card">
          <div class="ea-card-title">Vehicle Snapshot</div>
          ${
            hasVehicle
              ? `
                <div class="ea-grid-2">
                  ${miniStat("Vehicle Type", vehicle.vehicleType || "—")}
                  ${miniStat("Location", resolvePostingLocation() || "—")}
                  ${miniStat("Year", vehicle.year || "—")}
                  ${miniStat("Make", vehicle.make || "—")}
                  ${miniStat("Model", vehicle.model || "—")}
                  ${miniStat("Mileage", km(vehicle.kilometers))}
                  ${miniStat("Price", money(vehicle.price))}
                  ${miniStat("Body Style", vehicle.bodyStyle || "—")}
                  ${miniStat("Exterior Colour", vehicle.exteriorColor || "—")}
                  ${miniStat("Fuel Type", vehicle.fuelType || "—")}
                </div>
              `
              : `<div class="ea-note">No prepared vehicle detected.</div>`
          }
        </div>

        <div class="ea-card">
          <div class="ea-card-title">Dealer & Compliance</div>
          <div class="ea-field-list">
            <div class="ea-field-row">
              <div class="ea-field-label">Salesperson</div>
              <div class="ea-field-value">${escapeHtml(profile?.full_name || "Not set")}</div>
            </div>
            <div class="ea-field-row">
              <div class="ea-field-label">Dealership</div>
              <div class="ea-field-value">${escapeHtml(profile?.dealership || profile?.dealer_name || vehicle?.dealership || vehicle?.dealer_name || "Not set")}</div>
            </div>
            <div class="ea-field-row">
              <div class="ea-field-label">Listing Location</div>
              <div class="ea-field-value">${escapeHtml(profile?.listing_location || resolvePostingLocation() || "Not set")}</div>
            </div>
            <div class="ea-field-row">
              <div class="ea-field-label">Phone</div>
              <div class="ea-field-value">${escapeHtml(profile?.phone || profile?.dealer_phone || vehicle?.dealer_phone || "Not set")}</div>
            </div>
            <div class="ea-field-row">
              <div class="ea-field-label">Email</div>
              <div class="ea-field-value">${escapeHtml(profile?.dealer_email || "Not set")}</div>
            </div>
          </div>
        </div>

        <div class="ea-card">
          <div class="ea-card-title">Listing Copy Preview</div>
          ${
            hasVehicle
              ? `<div class="ea-copy-preview">${escapeHtml(descriptionPreview)}</div>`
              : `<div class="ea-note">No prepared description detected yet.</div>`
          }
        </div>

        <div class="ea-card">
          <div class="ea-card-title">Actions</div>
          <div class="ea-actions">
            <button id="eaMapFieldsBtn" class="ea-btn ea-btn--secondary">Map Marketplace Fields</button>
            <button id="eaAutofillBtn" class="ea-btn ea-btn--primary">Run Smart Autofill</button>
            <button id="eaPasteCopyBtn" class="ea-btn ea-btn--primary">Insert Listing Copy</button>
            <button id="eaUploadPhotosBtn" class="ea-btn ea-btn--primary">Upload Listing Photos</button>
            <button id="eaLoadNextBtn" class="ea-btn ea-btn--secondary">Load Next Vehicle</button>
            <button id="eaRefreshBtn" class="ea-btn ea-btn--secondary">Refresh Access</button>
          </div>
        </div>
      </div>
    `;

    bindPanelButtons();
  }

  function bindPanelButtons() {
    const mapBtn = document.getElementById("eaMapFieldsBtn");
    const fillBtn = document.getElementById("eaAutofillBtn");
    const copyBtn = document.getElementById("eaPasteCopyBtn");
    const photoBtn = document.getElementById("eaUploadPhotosBtn");
    const nextBtn = document.getElementById("eaLoadNextBtn");
    const refreshBtn = document.getElementById("eaRefreshBtn");

    if (mapBtn) mapBtn.onclick = beginMapping;
    if (fillBtn) fillBtn.onclick = runSmartAutofill;
    if (copyBtn) copyBtn.onclick = insertListingCopy;
    if (photoBtn) photoBtn.onclick = uploadListingPhotos;
    if (nextBtn) nextBtn.onclick = loadNextVehicleFromQueue;
    if (refreshBtn) refreshBtn.onclick = refreshExtensionAccess;
  }

  function getPathForElement(el) {
    if (!el) return "";
    const parts = [];
    let node = el;

    while (node && node.nodeType === 1 && node !== document.body) {
      let segment = node.tagName.toLowerCase();

      if (node.id) {
        segment += "#" + CSS.escape(node.id);
        parts.unshift(segment);
        break;
      }

      const parent = node.parentElement;
      if (parent) {
        const siblings = [...parent.children].filter((c) => c.tagName === node.tagName);
        if (siblings.length > 1) {
          segment += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
      }

      parts.unshift(segment);
      node = parent;
    }

    return parts.join(" > ");
  }

  function findMappedElement(path) {
    if (!path) return null;
    try {
      const el = document.querySelector(path);
      if (isHelperElement(el)) return null;
      return el;
    } catch {
      return null;
    }
  }

  function isHelperElement(el) {
    if (!el) return false;
    return !!el.closest?.(`#${PANEL_ID}`);
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  function clickEl(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center", inline: "center" }); } catch {}
    try { el.focus(); } catch {}

    try {
      el.click();
      return true;
    } catch {}

    try {
      dispatchRealClick(el);
      return true;
    } catch {}

    return false;
  }

  function dispatchRealClick(el) {
    if (!el) return false;

    const rect = el.getBoundingClientRect();
    const clientX = Math.floor(rect.left + rect.width / 2);
    const clientY = Math.floor(rect.top + rect.height / 2);

    const events = [
      new PointerEvent("pointerdown", { bubbles: true, cancelable: true, pointerId: 1, clientX, clientY, button: 0 }),
      new MouseEvent("mousedown", { bubbles: true, cancelable: true, clientX, clientY, button: 0 }),
      new PointerEvent("pointerup", { bubbles: true, cancelable: true, pointerId: 1, clientX, clientY, button: 0 }),
      new MouseEvent("mouseup", { bubbles: true, cancelable: true, clientX, clientY, button: 0 }),
      new MouseEvent("click", { bubbles: true, cancelable: true, clientX, clientY, button: 0 })
    ];

    for (const ev of events) {
      el.dispatchEvent(ev);
    }

    return true;
  }

  function findBestActionButton(kind = "next") {
    const candidates = [...document.querySelectorAll("button, [role='button'], div[role='button'], span[role='button']")]
      .filter((el) => isVisible(el) && !isHelperElement(el))
      .map((el) => {
        const text = lower(textOf(el));
        const rect = el.getBoundingClientRect();

        const exactNext = text === "next";
        const containsNext = text.includes("next");
        const exactPublish = text === "publish" || text === "post";
        const containsPublish = text.includes("publish") || text.includes("post");

        let match = false;
        let score = 0;

        if (kind === "next") {
          match = exactNext || containsNext;
          if (exactNext) score += 100;
          if (containsNext) score += 60;
        }

        if (kind === "publish") {
          match = exactPublish || containsPublish;
          if (exactPublish) score += 100;
          if (containsPublish) score += 60;
        }

        score += Math.max(0, rect.bottom);
        score += Math.max(0, rect.right);

        if (rect.width < 40 || rect.height < 20) score -= 100;

        return { el, text, rect, match, score };
      })
      .filter((x) => x.match)
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.el || null;
  }

  function textOf(el) {
    return String(el?.innerText || el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function setNativeInputValue(el, value) {
    if (!el) return false;
    const nextValue = String(value ?? "");

    try {
      const tag = (el.tagName || "").toLowerCase();
      const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      const lastValue = el.value;

      if (setter) setter.call(el, nextValue);
      else el.value = nextValue;

      const tracker = el._valueTracker;
      if (tracker) tracker.setValue(lastValue);

      try {
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: nextValue }));
      } catch {
        el.dispatchEvent(new Event("input", { bubbles: true }));
      }

      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch {
      return false;
    }
  }

  function setContentEditable(el, val) {
    if (!el) return false;
    try {
      el.focus();
      el.innerHTML = "";
      String(val || "").split("\n").forEach((line) => {
        const div = document.createElement("div");
        div.textContent = line || "";
        el.appendChild(div);
      });
      try {
        el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      } catch {
        el.dispatchEvent(new Event("input", { bubbles: true }));
      }
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch {
      return false;
    }
  }

  async function waitForMarketplaceFormReady() {
    for (let i = 0; i < 40; i++) {
      const pageText = lower(document.body.innerText || "");
      if (
        pageText.includes("vehicle type") ||
        pageText.includes("year") ||
        pageText.includes("make") ||
        pageText.includes("price") ||
        pageText.includes("description")
      ) return true;
      await sleep(350);
    }
    return false;
  }

  async function mapSingleField(field) {
    toast(`Click the ${field.label} field`);

    return new Promise((resolve) => {
      const onClick = async (e) => {
        const helper = document.getElementById(PANEL_ID);
        if (helper && helper.contains(e.target)) return;

        e.preventDefault();
        e.stopPropagation();

        fieldMap[field.key] = getPathForElement(e.target);
        await saveFieldMap();

        document.removeEventListener("click", onClick, true);
        toast(`${field.label} mapped`);
        resolve(true);
      };

      document.addEventListener("click", onClick, true);
    });
  }

  async function beginMapping() {
    if (isMapping) return;
    isMapping = true;

    try {
      for (const field of FIELD_ORDER) {
        await mapSingleField(field);
        await sleep(180);
      }
      toast("Marketplace field mapping complete");
    } catch (error) {
      warn("beginMapping failed:", error?.message || error);
      toast("Marketplace field mapping failed");
    } finally {
      isMapping = false;
      renderPanel();
    }
  }
async function ensurePostingAllowed() {
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'CAN_POST',
      vehicle
    });

    if (!res?.ok) {
      toast(res?.reason || "Posting blocked");
      return false;
    }

    return true;
  } catch (error) {
    warn("ensurePostingAllowed failed:", error?.message || error);
    return false;
  }
} 

  function findBestTextInput(path, hints = []) {
    const mapped = findMappedElement(path);
    const candidates = [
      mapped,
      mapped?.querySelector?.("input"),
      mapped?.querySelector?.("textarea"),
      mapped?.closest?.("label"),
      mapped?.parentElement,
      mapped?.parentElement?.parentElement
    ].filter(Boolean);

    for (const el of candidates) {
      if (!el) continue;
      if (el.matches?.("input, textarea") && isVisible(el)) return el;
      const inner = el.querySelector?.("input, textarea");
      if (inner && isVisible(inner)) return inner;
    }

    const visible = [...document.querySelectorAll("input, textarea")].filter(isVisible);
    return visible.find((el) => {
      const hay = [
        el.getAttribute("aria-label") || "",
        el.getAttribute("placeholder") || "",
        el.name || "",
        el.id || "",
        el.parentElement?.innerText || ""
      ].join(" ").toLowerCase();

      return hints.some((hint) => hay.includes(String(hint).toLowerCase()));
    }) || null;
  }

  function findBestDropdown(path, hints = [], excludeText = []) {
    const mapped = findMappedElement(path);
    const candidates = [
      mapped,
      mapped?.closest?.('[role="combobox"]'),
      mapped?.closest?.('[role="button"]'),
      mapped?.querySelector?.('[role="combobox"]'),
      mapped?.querySelector?.('[role="button"]'),
      mapped?.parentElement,
      mapped?.parentElement?.parentElement
    ].filter(Boolean);

    for (const el of candidates) {
      if (!el) continue;
      if (el.matches?.('[role="combobox"], [role="button"], button') && isVisible(el)) return el;
      const inner = el.querySelector?.('[role="combobox"], [role="button"], button');
      if (inner && isVisible(inner)) return inner;
    }

    const all = [...document.querySelectorAll('[role="combobox"], [role="button"], button')].filter(isVisible);
    return all.find((el) => {
      const hay = [
        textOf(el),
        el.getAttribute("aria-label") || "",
        el.getAttribute("title") || "",
        el.parentElement?.innerText || ""
      ].join(" ").toLowerCase();

      const matchesHint = hints.some((hint) => hay.includes(String(hint).toLowerCase()));
      const blocked = excludeText.some((bad) => hay.includes(String(bad).toLowerCase()));
      return matchesHint && !blocked;
    }) || null;
  }

  async function pickOption(desired, containsList = []) {
    await sleep(220);

    const nodes = [
      ...document.querySelectorAll('[role="option"]'),
      ...document.querySelectorAll("li"),
      ...document.querySelectorAll("button"),
      ...document.querySelectorAll("div"),
      ...document.querySelectorAll("span")
    ].filter((el) => isVisible(el) && !isHelperElement(el));

    const exact = nodes.find((el) => lower(textOf(el)) === lower(desired));
    if (exact) {
      clickEl(exact);
      return true;
    }

    for (const item of containsList) {
      const found = nodes.find((el) => lower(textOf(el)).includes(lower(item)));
      if (found) {
        clickEl(found);
        return true;
      }
    }

    return false;
  }

  async function fillDropdown(path, value, hints = [], synonyms = []) {
    const target = findBestDropdown(path, hints, ["next", "post", "publish", "save"]);
    if (!target) return false;

    clickEl(target);
    await sleep(300);

    const ok = await pickOption(value, [value, ...synonyms]);
    await sleep(500);
    return ok;
  }

  async function fillText(path, value, hints = []) {
    const target = findBestTextInput(path, hints);
    if (!target) return false;

    clickEl(target);
    await sleep(140);
    return setNativeInputValue(target, value);
  }

  function locationInvalidVisible() {
    const nodes = [...document.querySelectorAll("div, span")].filter(isVisible);
    return nodes.some((el) => lower(textOf(el)).includes("please enter a valid location"));
  }

  async function selectLocationSuggestion(target, value) {
    const desired = clean(value || "");
    const city = desired.split(",")[0].trim();
    const queries = [desired, city].filter(Boolean);

    for (const query of queries) {
      clickEl(target);
      await sleep(120);
      setNativeInputValue(target, query);
      await sleep(700);

      const optionNodes = [
        ...document.querySelectorAll('[role="option"]'),
        ...document.querySelectorAll('li'),
        ...document.querySelectorAll('div'),
        ...document.querySelectorAll('span')
      ].filter((el) => isVisible(el) && !isHelperElement(el));

      const desiredLower = lower(desired);
      const cityLower = lower(city);
      const best = optionNodes.find((el) => lower(textOf(el)) === desiredLower)
        || optionNodes.find((el) => lower(textOf(el)).includes(desiredLower))
        || optionNodes.find((el) => lower(textOf(el)).includes(cityLower));

      if (best) {
        clickEl(best);
        await sleep(700);
        if (!locationInvalidVisible()) return true;
      }

      target.focus();
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', bubbles: true }));
      target.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', code: 'ArrowDown', bubbles: true }));
      await sleep(150);
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
      target.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
      await sleep(700);
      if (!locationInvalidVisible()) return true;
    }

    return !locationInvalidVisible();
  }

  async function fillLocation(path, value) {
    const target = findBestTextInput(path, ['location']);
    if (!target) return false;
    return await selectLocationSuggestion(target, value);
  }

  function bestVisibleDescriptionEditor() {
    const textareas = [...document.querySelectorAll("textarea")].filter(isVisible);
    if (textareas[0]) return textareas[0];

    const editables = [...document.querySelectorAll('[contenteditable="true"]')].filter(isVisible);
    if (editables[0]) return editables[0];

    return null;
  }

  async function insertListingCopy() {
    if (!vehicle) {
      toast("No prepared vehicle detected.");
      return false;
    }

    if (isPastingCopy) return false;
    isPastingCopy = true;

    try {
      const wanted = buildDescriptionRaw(vehicle);
      const editor = bestVisibleDescriptionEditor();

      if (!editor) {
        toast("Listing copy field unavailable");
        return false;
      }

      let ok = false;
      if ((editor.tagName || "").toLowerCase() === "textarea") {
        ok = setNativeInputValue(editor, wanted);
      } else {
        ok = setContentEditable(editor, wanted);
      }

      if (ok) {
        lastDescriptionVehicleKey = getVehicleKey(vehicle);
        toast("Listing copy inserted");
      } else {
        toast("Listing copy insert failed");
      }

      return ok;
    } catch (error) {
      warn("insertListingCopy failed:", error?.message || error);
      toast("Listing copy insert failed");
      return false;
    } finally {
      isPastingCopy = false;
      renderPanel();
    }
  }

  async function fetchPhotoDataUrl(url) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "FETCH_PHOTO_DATA_URL", url }, resolve);
    });
  }

  function dataUrlToImage(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Image decode failed"));
      img.src = dataUrl;
    });
  }

  function canvasToBlob(canvas, mime, quality) {
    return new Promise((resolve) => canvas.toBlob(resolve, mime, quality));
  }

  async function compressPhotoToUploadFile(dataUrl, index = 0) {
    const img = await dataUrlToImage(dataUrl);

    const maxWidth = 1600;
    const maxHeight = 1600;
    let width = img.naturalWidth || img.width || 1600;
    let height = img.naturalHeight || img.height || 900;
    const ratio = Math.min(maxWidth / width, maxHeight / height, 1);

    width = Math.max(1, Math.round(width * ratio));
    height = Math.max(1, Math.round(height * ratio));

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d", { alpha: false });
    ctx.drawImage(img, 0, 0, width, height);

    let out = await canvasToBlob(canvas, "image/jpeg", 0.82);
    if (!out) throw new Error("Compression failed");
    if (out.size > 3 * 1024 * 1024) out = await canvasToBlob(canvas, "image/jpeg", 0.72);
    if (!out) throw new Error("Compression failed");
    if (out.size > 9.5 * 1024 * 1024) out = await canvasToBlob(canvas, "image/jpeg", 0.58);
    if (!out) throw new Error("Compression failed");

    return new File([out], `listing-photo-${index + 1}.jpg`, {
      type: "image/jpeg",
      lastModified: Date.now()
    });
  }

  function findPhotoInput() {
    const all = [...document.querySelectorAll('input[type="file"]')];
    const imageOnly = all.find((el) => lower(el.getAttribute("accept") || "").includes("image"));
    return imageOnly || all[0] || null;
  }

  function findAddPhotosButton() {
    const nodes = [...document.querySelectorAll("button, div, span, label")].filter(isVisible);
    return nodes.find((el) => {
      const t = lower(textOf(el));
      return t.includes("add photos") || t.includes("add photo") || t === "photos" || t.includes("photo");
    }) || null;
  }

  async function ensurePhotoInput() {
    for (let i = 0; i < 10; i++) {
      const input = findPhotoInput();
      if (input) return input;

      const button = findAddPhotosButton();
      if (button) clickEl(button);

      await sleep(350);
    }
    return null;
  }

  async function setFilesOnInput(input, files) {
    if (!input || !files?.length) return false;

    try {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      input.files = dt.files;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (error) {
      warn("setFilesOnInput failed:", error?.message || error);
      return false;
    }
  }
   async function uploadListingPhotos() {
    if (!vehicle) {
      toast("No prepared vehicle detected.");
      return false;
    }

    if (isUploadingPhotos) return false;
    isUploadingPhotos = true;

    try {
      const currentKey = getVehicleKey(vehicle);

      const rawSources = buildPhotoCandidates(vehicle).slice(0, 40);
      const photoSources = await sanitizePhotoSources(rawSources);

      if (!photoSources.length) {
        toast("Listing photos unavailable");
        return false;
      }

      const input = await ensurePhotoInput();
      if (!input) {
        toast("Listing photo field unavailable");
        return false;
      }

      const files = [];
      const seenSha = new Set();
      const seenDHash = [];
      const seenAHash = [];

      let skippedExact = 0;
      let skippedVisual = 0;

      for (let i = 0; i < photoSources.length; i++) {
        const result = await fetchPhotoDataUrl(photoSources[i]);
        if (!result?.ok || !result?.dataUrl) continue;

        const file = await compressPhotoToUploadFile(result.dataUrl, i);

        const sha = await sha256HexFromFile(file);
        if (seenSha.has(sha)) {
          skippedExact++;
          continue;
        }

        const { dhash, ahash } = await computeVisualHashes(file);

        const nearD = isNearDuplicate64(dhash, seenDHash, PHOTO_VISUAL_DHASH_MAX_DISTANCE);
        const nearA = isNearDuplicate64(ahash, seenAHash, PHOTO_VISUAL_AHASH_MAX_DISTANCE);

        if (nearD || nearA) {
          skippedVisual++;
          continue;
        }

        seenSha.add(sha);
        seenDHash.push(dhash);
        seenAHash.push(ahash);

        files.push(file);
        if (files.length >= 20) break;
      }

      if (!files.length) {
        toast("Listing photos unavailable");
        return false;
      }

      const ok = await setFilesOnInput(input, files);
      if (ok) {
        lastPhotoUploadVehicleKey = currentKey;
        toast(`Uploaded ${files.length} listing photos (skipped exact ${skippedExact}, visual ${skippedVisual})`);
      } else {
        toast("Listing photo upload failed");
      }

      return ok;
    } catch (error) {
      warn("uploadListingPhotos failed:", error?.message || error);
      toast("Listing photo upload failed");
      return false;
    } finally {
      isUploadingPhotos = false;
      renderPanel();
    }
  }
  
  async function resumePendingVehicleHandoff(reason = "resume") {
    const pending = await getPendingVehicleHandoff();
    if (!pending?.vehicle || !pending?.key) return false;

    if (!isCreateVehiclePage()) return false;

    vehicle = aliasVehicleFields(pending.vehicle);
    renderPanel();

    for (let attempt = 0; attempt < 6; attempt++) {
      const photoReady = await ensurePhotoInput();
      const copyReady = Boolean(bestVisibleDescriptionEditor());

      if (photoReady && copyReady) {
        await autoPrepareListingAssets(`${reason}-${attempt + 1}`);

        if (isVehiclePreparedForPosting(pending.key)) {
          await clearPendingVehicleHandoff(pending.key);
          return true;
        }
      }

      await sleep(900);
    }

    await setPendingVehicleHandoff(vehicle, {
      reason,
      attempts: Number(pending.attempts || 0) + 1
    });

    return false;
  }

  async function confirmPostSuccess(opts = {}) {
    const timeoutMs = Math.max(4000, Number(opts.timeoutMs || 18000));
    const pollMs = Math.max(250, Number(opts.pollMs || 500));
    const startedAt = Date.now();

    const successMarkers = [
      "your listing is live",
      "listing is live",
      "listing published",
      "your item is now listed",
      "your vehicle is now listed",
      "view listing",
      "boost listing",
      "mark as sold",
      "edit listing"
    ];

    const urlMarkers = [
      "/marketplace/item/",
      "/marketplace/you/selling",
      "/marketplace/profile/"
    ];

    while (Date.now() - startedAt < timeoutMs) {
      const body = lower(document.body?.innerText || "");
      const href = lower(location.href || "");

      if (successMarkers.some((marker) => body.includes(marker))) {
        return { ok: true, reason: "body_success_marker" };
      }

      if (urlMarkers.some((marker) => href.includes(marker))) {
        return { ok: true, reason: "url_success_marker" };
      }

      const publishBtn = findBestActionButton("publish") || findBestActionButton("post");
      const bodyHasFailure =
        body.includes("couldn't publish") ||
        body.includes("could not publish") ||
        body.includes("something went wrong") ||
        body.includes("try again");

      if (bodyHasFailure) {
        return { ok: false, reason: "publish_failure_marker" };
      }

      if (!publishBtn && body.includes("marketplace")) {
        const hasPostPublishUi =
          body.includes("more from marketplace") ||
          body.includes("seller dashboard") ||
          body.includes("promote listing") ||
          body.includes("listing details");

        if (hasPostPublishUi) {
          return { ok: true, reason: "post_publish_ui" };
        }
      }

      await sleep(pollMs);
    }

    return { ok: false, reason: "publish_confirmation_timeout" };
  }

async function purgePostedVehicleFromQueue(postedVehicle) {
  try {
    const postedKey = getVehicleKey(postedVehicle);
    const postedVin = String(postedVehicle?.vin || "").trim().toUpperCase();
    const postedStock = String(postedVehicle?.stock || "").trim().toUpperCase();

    queue = Array.isArray(queue) ? queue : [];

    const filtered = queue.filter((item) => {
      const itemKey = getVehicleKey(item);
      const itemVin = String(item?.vin || "").trim().toUpperCase();
      const itemStock = String(item?.stock || "").trim().toUpperCase();

      if (postedKey && itemKey === postedKey) return false;
      if (postedVin && itemVin && postedVin === itemVin) return false;
      if (postedStock && itemStock && postedStock === itemStock) return false;

      return true;
    });

    queue = filtered;
    queueLen = filtered.length;

    vehicle = null;
    lastAppliedVehicleKey = "";
    lastPhotoUploadVehicleKey = "";
    lastDescriptionVehicleKey = "";

    try {
      await chrome.storage.local.set({
        elevate_queue: filtered,
        elevate_current_vehicle: null,
        vehicleQueue: filtered,
        vehicle: null,
        elevate_last_posted_vehicle_key: postedKey || ""
      });
    } catch (error) {
      warn("purgePostedVehicleFromQueue storage save failed:", error?.message || error);
    }

    try {
      chrome.runtime.sendMessage({
        type: "SET_QUEUE",
        queue: filtered
      });
    } catch (error) {
      warn("purgePostedVehicleFromQueue SET_QUEUE failed:", error?.message || error);
    }

    try {
      chrome.runtime.sendMessage({
        type: "CLEAR_CURRENT_VEHICLE"
      });
    } catch (error) {
      warn("purgePostedVehicleFromQueue CLEAR_CURRENT_VEHICLE failed:", error?.message || error);
    }

  try {
  if (filtered.length) {
    const nextResult = await chrome.runtime.sendMessage({ type: "LOAD_NEXT_QUEUE_ITEM" });

    if (nextResult?.ok && nextResult?.vehicle) {
      vehicle = nextResult.vehicle;
    }
  }
} catch (error) {
  warn("purgePostedVehicleFromQueue LOAD_NEXT_QUEUE_ITEM failed:", error?.message || error);
}
    return true;
  } catch (error) {
    warn("purgePostedVehicleFromQueue failed:", error?.message || error);
    return false;
  }
}
  

  async function finalizeSuccessfulPost() {
    if (!vehicle) {
      return { ok: false, reason: "missing_vehicle" };
    }

    const currentKey = getVehicleKey(vehicle);
    if (!currentKey) {
      return { ok: false, reason: "missing_vehicle_key" };
    }

    if (lastPublishRegisterVehicleKey === currentKey) {
      return { ok: true, duplicate: true, reason: "already_registered" };
    }

    let result = null;

    try {
      result = await window.ElevatePostingGate?.registerMarketplacePost?.(vehicle);
    } catch (error) {
      warn("registerMarketplacePost threw:", error?.message || error);
    }

    if (!result?.success && !result?.ok) {
      return {
        ok: false,
        reason: result?.error || result?.reason || "register_post_failed",
        result
      };
    }
lastPublishRegisterVehicleKey = currentKey;
markVehiclePosted(currentKey);

try {
  await purgePostedVehicleFromQueue(vehicle);
} catch (error) {
  warn("purgePostedVehicleFromQueue after post failed:", error?.message || error);
}

try {
  await syncFromChromeStorage();
} catch (error) {
  warn("syncFromChromeStorage after post failed:", error?.message || error);
}

try {
  if (vehicle) {
    await setPendingVehicleHandoff(vehicle, { reason: "post_success" });
  }
} catch (error) {
  warn("setPendingVehicleHandoff after post failed:", error?.message || error);
}

    try {
      await loadExtensionState();
    } catch (error) {
      warn("loadExtensionState after post failed:", error?.message || error);
    }

    try {
      await persistPostingUsage();
    } catch (error) {
      warn("persistPostingUsage after post failed:", error?.message || error);
    }

    renderPanel();

    return {
      ok: true,
      result
    };
  }

  async function clickNextThenPost() {
    await sleep(1200);

    const beforeUrl = location.href;
    const beforeBody = lower(document.body.innerText || "");

    let nextBtn = null;

    for (let i = 0; i < 15; i++) {
      nextBtn = findBestActionButton("next");
      if (nextBtn) break;
      await sleep(250);
    }

    if (!nextBtn) {
      toast("Next button not found");
      return false;
    }

    clickEl(nextBtn);
    log("Clicked NEXT");

    let postBtn = null;

    for (let i = 0; i < 20; i++) {
      await sleep(300);
      postBtn = findBestActionButton("publish");
      if (postBtn) break;

      const currentUrl = location.href;
      const currentBody = lower(document.body.innerText || "");

      if (currentUrl !== beforeUrl || currentBody !== beforeBody) {
        // UI likely transitioned; continue waiting naturally
      }
    }

    if (!postBtn) {
      toast("Post button not found after Next");
      return false;
    }

    clickEl(postBtn);
    log("Clicked POST");

    toast("Posting...");
    return true;
  }
  


  async function runSmartAutofill() {
    if (!vehicle) {
      toast("No prepared vehicle detected.");
      return false;
    }

    const currentKey = getVehicleKey(vehicle);

    if (isVehiclePosted(currentKey)) {
      toast("Vehicle already posted");
      return false;
    }

    if (isAutofilling) return false;

    const allowed = await ensurePostingAllowed();
    if (!allowed) {
      toast("Posting not allowed under current gate.");
      return false;
    }

    const postingLimit = Number(
      extensionState?.posting_limit ||
      extensionState?.subscription?.posting_limit ||
      extensionState?.session_snapshot?.subscription?.posting_limit ||
      getDailyLimit()
    );

    const postsToday = getPostsToday();

    if (postsToday >= postingLimit) {
      toast(`Daily posting limit reached (${postingLimit})`);
      return false;
    }

    isAutofilling = true;

    try {
      const ready = await waitForMarketplaceFormReady();
      if (!ready) {
        toast("Marketplace form not ready");
        return false;
      }

      const values = {
        vehicleType: vehicle.vehicleType || "Car/Truck",
        location: resolvePostingLocation(),
        year: vehicle.year || "",
        make: vehicle.make || "",
        model: vehicle.model || "",
        kilometers: vehicle.kilometers || "",
        price: vehicle.price || "",
        bodyStyle: vehicle.bodyStyle || "",
        exteriorColor: vehicle.exteriorColor || "",
        fuelType: vehicle.fuelType || ""
      };

      const steps = [
        async () => fillDropdown(fieldMap.vehicleType, values.vehicleType, ["vehicle type"], ["car/truck"]),
        async () => fillLocation(fieldMap.location, values.location),
        async () => fillDropdown(fieldMap.year, values.year, ["year"], [values.year]),
        async () => fillDropdown(fieldMap.make, values.make, ["make"], [values.make]),
        async () => fillText(fieldMap.model, values.model, ["model"]),
        async () => fillText(fieldMap.kilometers, values.kilometers, ["mileage", "odometer", "kilomet"]),
        async () => fillText(fieldMap.price, values.price, ["price"]),
        async () => fillDropdown(fieldMap.bodyStyle, values.bodyStyle, ["body style", "body"], [values.bodyStyle]),
        async () => fillDropdown(fieldMap.exteriorColor, values.exteriorColor, ["exterior colour", "exterior color", "colour", "color"], [values.exteriorColor]),
        async () => fillDropdown(fieldMap.fuelType, values.fuelType, ["fuel type", "fuel"], [values.fuelType])
      ];

      for (const step of steps) {
        try {
          await step();
          await sleep(320);
        } catch (error) {
          warn("autofill step failed:", error?.message || error);
        }
      }
     try {
  await chrome.runtime.sendMessage({
    type: 'BEGIN_POST',
    vehicle
  });
} catch (error) {
  warn("BEGIN_POST failed:", error?.message || error);
}


      await autoPrepareListingAssets("autofill");
      lastAppliedVehicleKey = currentKey;
      toast("Smart autofill complete");

      await clickNextThenPost();

      return true;
    } catch (error) {
      warn("runSmartAutofill failed:", error?.message || error);
      toast("Smart autofill failed");
      return false;
    } finally {
      isAutofilling = false;
      renderPanel();
    }
  }

  async function autoPrepareListingAssets(reason = "auto") {
    if (!vehicle) return;

    const currentKey = getVehicleKey(vehicle);
    if (!currentKey) return;

    try {
      if (lastDescriptionVehicleKey !== currentKey) {
        await insertListingCopy();
      }
    } catch (error) {
      warn("auto insertListingCopy failed:", error?.message || error);
    }

    try {
if (lastPhotoUploadVehicleKey !== currentKey) {
  await uploadListingPhotos();
}
    } catch (error) {
      warn("auto uploadListingPhotos failed:", error?.message || error);
    }

    log("autoPrepareListingAssets complete:", reason, currentKey);
  }

  async function loadNextVehicleFromQueue() {
    try {
      const result = await new Promise((resolve) =>
        chrome.runtime.sendMessage({ type: "LOAD_NEXT_QUEUE_ITEM" }, resolve)
      );
if (result?.vehicle) {
  vehicle = aliasVehicleFields(result.vehicle);
  queue = Array.isArray(result.queue) ? result.queue : queue;
  queueLen = queue.length;

  const key = getVehicleKey(vehicle);
  if (isVehiclePosted(key)) {
    toast("Skipping already posted vehicle");
    return loadNextVehicleFromQueue();
  }

  toast("Loaded next queued vehicle.");
  renderPanel();
  await setPendingVehicleHandoff(vehicle, { reason: "load_next" });
  await resumePendingVehicleHandoff("load-next");
  return true;
}

      toast("Queue empty.");
      return false;
    } catch (error) {
      warn("loadNextVehicleFromQueue failed:", error?.message || error);
      toast("Load next vehicle failed");
      return false;

    }
  }

  async function refreshExtensionAccess() {
    await loadExtensionState();
    await syncFromChromeStorage();
    toast(extensionState?.access ? "Access refreshed" : "Session refreshed");
    renderPanel();
  }
 

  async function syncFromChromeStorage() {
    try {
      const data = await chrome.storage.local.get([
        "vehicle",
        "vehicleQueue",
        "dwFieldMap",
        "elevate_current_vehicle",
        "elevate_vehicle_queue",
        "elevate_posting_trigger",
        "elevate_session_snapshot",
        "ea_extension_session",
        "elevate_profile_snapshot",
        "elevate_posted_vehicles",
        "elevate_posts_today",
        "elevate_posting_limit",
        "elevate_extension_usage_snapshot"
      ]);

      const nextVehicle = Object.prototype.hasOwnProperty.call(data, "elevate_current_vehicle")
        ? data.elevate_current_vehicle
        : (data.vehicle || null);
      const nextQueue = data.elevate_vehicle_queue || data.vehicleQueue || [];
      vehicle = aliasVehicleFields(nextVehicle);
      queue = Array.isArray(nextQueue) ? nextQueue : [];
      queueLen = queue.length;
      fieldMap = data.dwFieldMap || fieldMap || {};

      if (Array.isArray(data.elevate_posted_vehicles)) {
        postedVehicles = new Set(data.elevate_posted_vehicles);
        localStorage.setItem("ea_posted", JSON.stringify([...postedVehicles]));
      }

      if (data.elevate_session_snapshot || data.ea_extension_session) {
        extensionState = {
          ...(extensionState || {}),
          session_snapshot: data.elevate_session_snapshot || data.ea_extension_session || null,
          access: extensionState?.access ?? true,
          profile: {
            ...(data.elevate_profile_snapshot || {}),
            ...(extensionState?.profile || {}),
            ...(data.elevate_session_snapshot?.profile || {}),
            ...(data.ea_extension_session?.profile || {}),
            ...(extensionState?.session_snapshot?.profile || {})
          }
        };
      }

      const storedPostsToday = Number(
        data.elevate_posts_today ??
        data.elevate_extension_usage_snapshot?.posts_today ??
        0
      );

      const storedPostingLimit = Number(
        data.elevate_posting_limit ??
        data.elevate_extension_usage_snapshot?.posting_limit ??
        0
      );

      if (!extensionState) extensionState = {};

      if (storedPostsToday) {
        extensionState.posts_today = storedPostsToday;
      }

      if (storedPostingLimit) {
        extensionState.posting_limit = storedPostingLimit;
      }

      if (!extensionState.posting_limit) {
        extensionState.posting_limit = getDailyLimit();
      }

      if (!extensionState.subscription) extensionState.subscription = {};
      extensionState.subscription.posts_today =
        Number(extensionState.posts_today || 0);
      extensionState.subscription.posting_limit =
        Number(extensionState.posting_limit || getDailyLimit());

      localStorage.setItem("ea_posts_today", String(extensionState.subscription.posts_today || 0));
      localStorage.setItem("ea_posting_limit", String(extensionState.subscription.posting_limit || getDailyLimit()));
    } catch (error) {
      warn("syncFromChromeStorage failed:", error?.message || error);
    }
  }

  function attachStorageWatcher() {
    if (!chrome?.storage?.onChanged) return;

    chrome.storage.onChanged.addListener(async (changes, areaName) => {
      if (areaName !== "local") return;

      let updatedVehicle = false;

      if (changes.elevate_current_vehicle || changes.vehicle) {
        const nextVehicle = changes.elevate_current_vehicle
          ? changes.elevate_current_vehicle.newValue
          : (changes.vehicle?.newValue || null);
        vehicle = aliasVehicleFields(nextVehicle || null);
        updatedVehicle = true;
      }

      if (changes.elevate_vehicle_queue || changes.vehicleQueue) {
        const nextQueue = changes.elevate_vehicle_queue?.newValue || changes.vehicleQueue?.newValue || [];
        queue = Array.isArray(nextQueue) ? nextQueue : [];
        queueLen = queue.length;
      }

      if (changes.dwFieldMap) {
        fieldMap = changes.dwFieldMap.newValue || {};
      }

      if (changes.elevate_posted_vehicles?.newValue) {
        postedVehicles = new Set(changes.elevate_posted_vehicles.newValue);
        localStorage.setItem("ea_posted", JSON.stringify([...postedVehicles]));
      }

      if (changes.elevate_posts_today) {
        localStorage.setItem("ea_posts_today", String(changes.elevate_posts_today.newValue || 0));
      }

      if (changes.elevate_posting_limit) {
        localStorage.setItem("ea_posting_limit", String(changes.elevate_posting_limit.newValue || getDailyLimit()));
      }

      renderPanel();
if (updatedVehicle && vehicle) {
  const currentKey = getVehicleKey(vehicle);

  if (currentKey && currentKey !== lastAppliedVehicleKey) {
    lastAppliedVehicleKey = currentKey;
    toast("Prepared vehicle loaded.");
    await setPendingVehicleHandoff(vehicle, { reason: "storage_change" });
    await resumePendingVehicleHandoff("storage-change");
  }
}
    });
  }

async function attachPublishWatcher() {
  document.addEventListener("click", async (e) => {
    const target = e.target?.closest?.("button, [role='button'], div, span");
    if (!target) return;

    const label = lower(textOf(target));

    const isRealPublishAction =
      label === "publish" ||
      label === "post" ||
      label.includes("publish listing");

    if (!isRealPublishAction) return;
    if (!vehicle || !window.ElevatePostingGate?.registerMarketplacePost) return;

    const currentKey = getVehicleKey(vehicle);
    if (!currentKey) return;
    if (lastPublishRegisterVehicleKey === currentKey) return;

    try {
      const allowed = await ensurePostingAllowed();
      if (!allowed) return;

      toast("Posting...");

      setTimeout(async () => {
        const success = await confirmPostSuccess({ timeoutMs: 22000, pollMs: 500 });

        if (!success?.ok) {
          warn("confirmPostSuccess failed:", success?.reason || success);
          toast("Post may be live. Refresh if needed.");
          return;
        }

        const finalized = await finalizeSuccessfulPost();

        if (!finalized?.ok) {
          warn("finalizeSuccessfulPost failed:", finalized?.reason || finalized);
          toast("Post live, but sync failed");
          return;
        }

        toast("Post registered. Returning to create vehicle...");

        setTimeout(() => {
          goBackToCreateVehicle();
        }, 900);
      }, 1200);
    } catch (error) {
      warn("attachPublishWatcher error:", error?.message || error);
      toast("Post watcher failed");
    }
  }, true);
}

  async function initFromState() {
        try {
      await chrome.runtime.sendMessage({ type: "RESET_POST_LOCKS" });
    } catch (error) {
      warn("RESET_POST_LOCKS failed:", error?.message || error);
    }
    const state = await getState();
queue = [];
queueLen = 0;
    vehicle = aliasVehicleFields(state?.vehicle || null);
    fieldMap = state?.dwFieldMap || {};
    queue = Array.isArray(state?.vehicleQueue) ? state.vehicleQueue : [];
    queueLen = queue.length;

    await loadExtensionState();
    await syncFromChromeStorage();
    renderPanel();
      
let attempts = 0;

while ((!vehicle || !vehicle.year) && attempts < 10) {
  await sleep(400);
  await syncFromChromeStorage();

  if (vehicle && vehicle.year) break;

  attempts++;
}

if (vehicle && vehicle.year) {
  log("Recovered vehicle from storage after load");
  await setPendingVehicleHandoff(vehicle, { reason: "initial_load" });
  await resumePendingVehicleHandoff("initial-load");
} else {
  await resumePendingVehicleHandoff("initial-load-pending");
}
    
  }

  window.ElevateMarketplaceMapFields = beginMapping;
  window.ElevateMarketplaceSmartAutofill = runSmartAutofill;
  window.ElevateMarketplaceInsertCopy = insertListingCopy;
  window.ElevateMarketplaceUploadPhotos = uploadListingPhotos;
  window.ElevateMarketplaceLoadNextVehicle = loadNextVehicleFromQueue;

  try {
    await initFromState();
    attachStorageWatcher();
    attachPublishWatcher();
    startListingViewSyncLoop();
  } catch (error) {
    warn("Marketplace V11 boot failed:", error?.message || error);
    ensurePanel();
    lastStatus = "Marketplace Assistant boot failed.";
    renderPanel();
  }
})();
