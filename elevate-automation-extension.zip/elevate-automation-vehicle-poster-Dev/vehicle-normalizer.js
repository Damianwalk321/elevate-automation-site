// vehicle-normalizer.js
// Elevate Automation Vehicle Normalizer V11

(function () {
  function clean(v) { return String(v || "").replace(/\s+/g, " ").trim(); }
  function lower(v) { return clean(v).toLowerCase(); }
  function digits(v) { return String(v || "").replace(/[^\d]/g, ""); }
  function stripJunk(v) {
    return clean(String(v || "")
      .replace(/[\u{1F300}-\u{1FAFF}]/gu, " ")
      .replace(/[\u2600-\u27BF]/gu, " ")
      .replace(/[•◆■►▶✅❌✔️➡️📍🚗💰🛡️📞]/gu, " ")
      .replace(/[^\x20-\x7E\u00C0-\u024F]/g, " "));
  }
  function sanitize(v) { return clean(stripJunk(v)); }
  function clamp01(n) { return Math.max(0, Math.min(1, Number(n || 0))); }
  function escapeRegex(v) { return String(v || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
  function src(vehicle) {
    return clean([
      vehicle?.title,
      vehicle?.rawText,
      vehicle?.raw_text,
      vehicle?.description,
      vehicle?.subtitle
    ].filter(Boolean).join(" "));
  }

  const MAKE_MAP = [
    ["toyota", "Toyota"], ["honda", "Honda"], ["ford", "Ford"], ["chevrolet", "Chevrolet"], ["chevy", "Chevrolet"],
    ["gmc", "GMC"], ["ram", "Ram"], ["dodge", "Dodge"], ["jeep", "Jeep"], ["mazda", "Mazda"],
    ["nissan", "Nissan"], ["hyundai", "Hyundai"], ["kia", "Kia"], ["subaru", "Subaru"], ["volkswagen", "Volkswagen"],
    ["vw", "Volkswagen"], ["audi", "Audi"], ["bmw", "BMW"], ["mercedes", "Mercedes-Benz"], ["mercedes-benz", "Mercedes-Benz"],
    ["porsche", "Porsche"], ["lexus", "Lexus"], ["acura", "Acura"], ["infiniti", "Infiniti"], ["genesis", "Genesis"],
    ["mitsubishi", "Mitsubishi"], ["buick", "Buick"], ["cadillac", "Cadillac"], ["lincoln", "Lincoln"], ["volvo", "Volvo"],
    ["mini", "MINI"]
  ];

  const BODY_RULES = [
    { value: "Truck", confidence: 0.96, patterns: [/\b(f-?150|f-?250|f-?350|super duty|silverado|sierra|tundra|tacoma|colorado|canyon|ram\s?1500|ram\s?2500|ram\s?3500|maverick|ranger|ridgeline|gladiator|pickup)\b/i] },
    { value: "SUV", confidence: 0.94, patterns: [/\b(bronco( sport)?|explorer|expedition|escape|edge|rav4|highlander|4runner|venza|pilot|passport|cr-?v|hr-?v|rogue|murano|pathfinder|tucson|santa fe|palisade|sportage|sorento|telluride|cx-?5|cx-?50|cx-?30|cx-?9|outlander|eclipse cross|blazer|traverse|tahoe|suburban|enclave|envision|terrain|acadia|atlas|tiguan|taos|crosstrek|forester|x1|x3|x5|q3|q5|q7|glc|gle|cayenne|macan|xc60|xc90|gv70|gv80|suv|crossover)\b/i] },
    { value: "Van", confidence: 0.95, patterns: [/\b(sienna|odyssey|pacifica|caravan|grand caravan|minivan|van)\b/i] },
    { value: "Wagon", confidence: 0.9, patterns: [/\b(outback|wagon)\b/i] },
    { value: "Hatchback", confidence: 0.88, patterns: [/\b(golf|hatchback|sportback)\b/i] },
    { value: "Coupe", confidence: 0.86, patterns: [/\b(coupe)\b/i] },
    { value: "Sedan", confidence: 0.84, patterns: [/\b(corolla|camry|civic|accord|jetta|passat|mazda3|mazda 3|elantra|sonata|sentra|altima|maxima|forte|impreza|wrx|malibu|cruze|sedan)\b/i] }
  ];

  const COLOR_RULES = [
    { value: "Black", confidence: 0.95, patterns: [/\b(black|midnight black|jet black|onyx|obsidian|ebony|phantom black)\b/i] },
    { value: "White", confidence: 0.95, patterns: [/\b(white|ivory|pearl white|snow white|crystal white|oxford white)\b/i] },
    { value: "Silver", confidence: 0.92, patterns: [/\b(silver|metallic silver|billet silver|ice silver)\b/i] },
    { value: "Grey", confidence: 0.92, patterns: [/\b(grey|gray|graphite|charcoal|magnetic|gunmetal|granite|steel|machine grey|sonic gray)\b/i] },
    { value: "Blue", confidence: 0.92, patterns: [/\b(blue|navy|deep sea blue|velocity blue|hydro blue|storm blue)\b/i] },
    { value: "Red", confidence: 0.92, patterns: [/\b(red|ruby red|radiant red|crimson|burgundy|maroon|scarlet)\b/i] },
    { value: "Green", confidence: 0.9, patterns: [/\b(green|army green|olive|sage)\b/i] },
    { value: "Brown", confidence: 0.88, patterns: [/\b(brown|bronze|copper|mocha|espresso)\b/i] },
    { value: "Orange", confidence: 0.88, patterns: [/\b(orange)\b/i] },
    { value: "Yellow", confidence: 0.86, patterns: [/\b(yellow)\b/i] },
    { value: "Gold", confidence: 0.86, patterns: [/\b(gold)\b/i] },
    { value: "Beige", confidence: 0.84, patterns: [/\b(beige|tan|champagne|sand)\b/i] },
    { value: "Purple", confidence: 0.82, patterns: [/\b(purple|violet|plum)\b/i] }
  ];

  function extractYear(text) { return clean(text).match(/\b(19|20)\d{2}\b/)?.[0] || ""; }
  function extractMake(text) {
    const raw = lower(text);
    for (const [needle, value] of MAKE_MAP) {
      if (new RegExp(`\\b${escapeRegex(needle)}\\b`, "i").test(raw)) return value;
    }
    return "";
  }

  function splitModelTrim(vehicle) {
    const year = sanitize(vehicle?.year || "");
    const make = sanitize(vehicle?.make || "");
    let work = sanitize(vehicle?.title || src(vehicle));
    if (year) work = work.replace(new RegExp(`\\b${escapeRegex(year)}\\b`, "i"), " ");
    if (make) work = work.replace(new RegExp(`\\b${escapeRegex(make)}\\b`, "i"), " ");
    work = sanitize(
      work
        .replace(/\bin\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+\d+\b/g, " ")
        .replace(/\bgrande prairie\b/gi, " ")
        .replace(/\bedmonton\b/gi, " ")
        .replace(/\balberta\b/gi, " ")
    );
    const tokens = work.split(/\s+/).filter(Boolean).filter((t) => !/^(in|at|stock|vin|price|km|kms|automatic|manual)$/i.test(t));
    if (!tokens.length) return { model: "", trim: "" };

    const joined = tokens.join(" ");
    const patterns = [
      [/^bronco sport\b/i, "Bronco Sport"],
      [/^cx[- ]5\b/i, "CX-5"],
      [/^cx[- ]50\b/i, "CX-50"],
      [/^cx[- ]30\b/i, "CX-30"],
      [/^mazda\s?3\b/i, "Mazda3"],
      [/^1500 classic\b/i, "1500 Classic"],
      [/^grand cherokee\b/i, "Grand Cherokee"],
      [/^eclipse cross\b/i, "Eclipse Cross"],
      [/^trd off[- ]road\b/i, "TRD Off-Road"],
      [/^trd sport\b/i, "TRD Sport"]
    ];

    for (const [pattern, value] of patterns) {
      if (pattern.test(joined)) {
        const used = value.split(/\s+/).length;
        return { model: value, trim: tokens.slice(used).join(" ") };
      }
    }

    return { model: tokens[0] || "", trim: tokens.slice(1).join(" ") };
  }

  function textBlock(vehicle = {}) {
    return lower([
      vehicle?.title,
      vehicle?.model,
      vehicle?.trim,
      vehicle?.body_style,
      vehicle?.body,
      vehicle?.rawText,
      vehicle?.raw_text,
      vehicle?.specs?.body
    ].filter(Boolean).join(" "));
  }

  function pickBodyFromRules(text) {
    for (const rule of BODY_RULES) {
      if (rule.patterns.some((p) => p.test(text))) {
        return { value: rule.value, confidence: rule.confidence, source: "rule" };
      }
    }
    return { value: "", confidence: 0, source: "none" };
  }

  function normalizeBody(vehicle = {}) {
    const explicit = sanitize(vehicle?.body_style || vehicle?.body || vehicle?.specs?.body || "");
    const explicitLower = lower(explicit);
    if (explicit && /(truck|suv|sedan|coupe|wagon|van|hatchback|convertible)/i.test(explicitLower)) {
      const fromRules = pickBodyFromRules(explicitLower);
      return { value: fromRules.value || explicit, confidence: fromRules.value ? 0.98 : 0.9, source: "explicit" };
    }
    const inferred = pickBodyFromRules(textBlock(vehicle));
    return inferred;
  }

  function normalizeFuel(vehicle = {}) {
    const explicit = sanitize(vehicle?.fuel_type || vehicle?.fuel || vehicle?.specs?.fuel || "");
    const raw = lower([explicit, vehicle?.title, vehicle?.trim, vehicle?.rawText].filter(Boolean).join(" "));
    if (/\b(hybrid|phev|plug[- ]?in|prime)\b/.test(raw)) return { value: "Hybrid", confidence: explicit ? 0.98 : 0.9, source: explicit ? "explicit" : "rule" };
    if (/\b(electric|ev)\b/.test(raw)) return { value: "Electric", confidence: explicit ? 0.98 : 0.9, source: explicit ? "explicit" : "rule" };
    if (/\b(diesel|tdi|duramax|cummins|ecodiesel)\b/.test(raw)) return { value: "Diesel", confidence: explicit ? 0.98 : 0.9, source: explicit ? "explicit" : "rule" };
    if (/\b(gas|gasoline)\b/.test(raw)) return { value: "Gasoline", confidence: explicit ? 0.98 : 0.84, source: explicit ? "explicit" : "rule" };
    return { value: explicit, confidence: explicit ? 0.85 : 0, source: explicit ? "explicit" : "none" };
  }

  function extractExteriorOnlyText(input = "") {
    let text = lower(input);
    if (!text) return "";
    const explicitExt = text.match(/(?:\bext(?:erior)?\b|\boutside\b)\s*[:\-]?\s*([^|,;]+?)(?=(?:\bint(?:erior)?\b\s*[:\-]?)|$)/i);
    if (explicitExt?.[1]) return clean(explicitExt[1]);
    text = text.replace(/\binterior\b\s*[:\-]?[^|,;]+/gi, " ");
    text = text.replace(/\bint\b\s*[:\-]?[^|,;]+/gi, " ");
    return clean(text);
  }

  function normalizeColor(vehicle = {}) {
    const explicit = sanitize(vehicle?.exterior_color || vehicle?.color || vehicle?.specs?.exterior_color || "");
    const title = sanitize(vehicle?.title || "");
    const rawText = sanitize(vehicle?.rawText || vehicle?.raw_text || "");

    const explicitLower = lower(explicit);
    if (/^(int|interior)\b/.test(explicitLower)) {
      return { value: "", confidence: 0, source: "interior_rejected" };
    }

    const colorText = extractExteriorOnlyText([explicit, title, rawText].filter(Boolean).join(" | "));
    for (const rule of COLOR_RULES) {
      if (rule.patterns.some((p) => p.test(colorText))) {
        return { value: rule.value, confidence: explicit ? Math.max(rule.confidence, 0.97) : rule.confidence, source: explicit ? "explicit" : "rule" };
      }
    }

    const fallback = sanitize(explicit);
    if (fallback && !/^(int|interior)\b/i.test(fallback)) {
      return { value: fallback, confidence: 0.72, source: "fallback" };
    }

    return { value: "", confidence: 0, source: "none" };
  }

  function normalizeLocation(v) {
    for (const item of [v?.listing_location, v?.location, v?.profile?.listing_location]) {
      const s = sanitize(item);
      if (s) return s;
    }
    return "";
  }

  function mergeConfidence(vehicle, next = {}) {
    const current = vehicle?.confidence || {};
    return {
      ...current,
      body: clamp01(Math.max(Number(current.body || 0), Number(next.body || 0))),
      fuel: clamp01(Math.max(Number(current.fuel || 0), Number(next.fuel || 0))),
      color: clamp01(Math.max(Number(current.color || 0), Number(next.color || 0)))
    };
  }

  function normalizeVehicle(vehicle = {}) {
    const out = { ...(vehicle || {}) };
    const source = src(out);
    out.vin = sanitize(out.vin || "").toUpperCase();
    out.stock = sanitize(out.stock || out.stock_number || out.stockNumber || "");
    out.year = sanitize(out.year || extractYear(source));
    out.make = sanitize(out.make || extractMake(source));
    const split = splitModelTrim({ ...out, title: out.title || source });
    out.model = sanitize(out.model || split.model);
    out.trim = sanitize(out.trim || split.trim);
    out.price = Number(out.price || out.list_price || out.asking_price || digits(out.price || "")) || "";
    out.km = Number(out.km || out.kilometers || out.mileage || digits(out.km || "")) || "";

    const bodyResult = normalizeBody(out);
    const fuelResult = normalizeFuel(out);
    const colorResult = normalizeColor(out);

    out.body_style = sanitize(out.body_style || bodyResult.value || "");
    out.fuel_type = sanitize(out.fuel_type || fuelResult.value || "");
    out.exterior_color = sanitize(out.exterior_color || colorResult.value || "");
    out.listing_location = normalizeLocation(out);
    out.location = out.listing_location;
    out.vehicle_type = sanitize(out.vehicle_type || out.specs?.vehicle_type || "") || "Car/Truck";
    out.title = sanitize([out.year, out.make, out.model, out.trim].filter(Boolean).join(" "));
    out.rawText = sanitize(out.rawText || out.raw_text || source);
    out.source_url = clean(out.source_url || out.sourceUrl || "");

    out.confidence = mergeConfidence(out, {
      body: bodyResult.confidence,
      fuel: fuelResult.confidence,
      color: colorResult.confidence
    });

    out.enrichment_meta = {
      ...(out.enrichment_meta || {}),
      body_source: bodyResult.source,
      fuel_source: fuelResult.source,
      color_source: colorResult.source
    };

    out.specs = {
      ...(out.specs || {}),
      body: out.body_style,
      fuel: out.fuel_type,
      exterior_color: out.exterior_color,
      vehicle_type: out.vehicle_type
    };
    return out;
  }

  window.ElevateVehicleNormalizer = {
    normalizeVehicle,
    normalizeBody,
    normalizeFuel,
    normalizeColor
  };
})();
