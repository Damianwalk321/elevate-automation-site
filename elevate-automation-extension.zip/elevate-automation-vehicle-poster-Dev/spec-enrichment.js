// spec-enrichment.js
// Elevate Automation Spec Enrichment V7

(function () {
  function enrichVehicle(vehicle = {}) {
    let next = { ...(vehicle || {}) };

    try {
      if (window.ElevateVINDecoder?.decodeVIN) {
        next = window.ElevateVINDecoder.decodeVIN(next) || next;
      }
    } catch (error) {
      console.warn("[Elevate Spec Enrichment] VIN decode failed", error);
    }

    try {
      if (window.ElevateSpecIntelligence?.enrichSpecs) {
        next = window.ElevateSpecIntelligence.enrichSpecs(next) || next;
      } else {
        if (!next.body_style && window.ElevateSpecIntelligence?.detectBodyStyle) {
          next.body_style = window.ElevateSpecIntelligence.detectBodyStyle(next) || next.body_style;
        }
        if (!next.fuel_type) {
          if (window.ElevateSpecIntelligence?.detectFuelType) {
            next.fuel_type = window.ElevateSpecIntelligence.detectFuelType(next) || next.fuel_type;
          } else if (window.ElevateSpecIntelligence?.detectFuel) {
            next.fuel_type = window.ElevateSpecIntelligence.detectFuel(next) || next.fuel_type;
          }
        }
      }
    } catch (error) {
      console.warn("[Elevate Spec Enrichment] intelligence failed", error);
    }

    next.specs = {
      ...(next.specs || {}),
      body: next.specs?.body || next.body_style || "",
      fuel: next.specs?.fuel || next.fuel_type || "",
      exterior_color: next.specs?.exterior_color || next.exterior_color || "",
      vehicle_type: next.specs?.vehicle_type || next.vehicle_type || ""
    };

    return next;
  }

  window.ElevateSpecEnrichment = {
    enrichVehicle,
    enrichVehicleSpecs: enrichVehicle
  };
})();
