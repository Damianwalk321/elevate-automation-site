// adapter-router.js
// Optional global router for adapter-based scanning

(function () {
  const MIN_CONFIDENCE = 0.7;
  const MIN_COUNT = 2;

  function record(type, payload) {
    try { window.ElevateAdapterTelemetry?.record?.(type, payload || {}); } catch {}
    try { window.ElevateAdapterIntelligence?.record?.({ type, ...(payload || {}) }); } catch {}
  }

  function isStrongResult(result) {
    const vehicleCount = Array.isArray(result?.vehicles) ? result.vehicles.length : 0;
    const confidence = Number(result?.confidence || 0);
    return vehicleCount >= MIN_COUNT && confidence >= MIN_CONFIDENCE;
  }

  async function runAdapterScan(ctx = {}) {
    const registry = window.ElevateAdapterRegistry;
    const ranked = registry?.resolve ? registry.resolve(ctx) : [];
    const domain = String(ctx?.domain || ctx?.host || location.hostname || '').toLowerCase();

    if (!ranked.length) {
      console.warn("[ROUTER] No adapter candidates found");
      record('scan_failure', { domain, adapter: 'none', reason: 'no_adapter' });
      return fallbackResult("no_adapter");
    }

    const topConfidence = Number(ranked?.[0]?.confidence || 0);
    let bestWeak = null;

    for (const item of ranked) {
      const adapter = item.adapter;
      const startedAt = Date.now();
      const attemptMeta = {
        domain,
        adapter: adapter?.id || 'unknown',
        confidence: Number(item.confidence || 0),
        meta: {
          priority: Number(item.priority || 0),
          intelligenceBoost: Number(item.intelligenceBoost || 0),
          locked: topConfidence - Number(item.confidence || 0) >= 0.12
        }
      };
      record('scan_attempt', attemptMeta);
      try {
        const result = await adapter.scanInventory(ctx);
        const durationMs = Date.now() - startedAt;
        const vehicleCount = Array.isArray(result?.vehicles) ? result.vehicles.length : 0;
        const confidence = Number(result?.confidence || 0);

        if (isStrongResult(result)) {
          console.log(`[ROUTER] Adapter success: ${adapter.id} (${confidence.toFixed(2)})`);
          record('scan_success', { domain, adapter: adapter.id, confidence, count: vehicleCount, durationMs });
          return {
            ...result,
            diagnostics: {
              ...(result?.diagnostics || {}),
              adapter: adapter.id,
              locked: true,
              rankedConfidence: Number(item.confidence || 0)
            }
          };
        }

        const weak = { result, vehicleCount, confidence, adapterId: adapter?.id || 'unknown', durationMs };
        if (!bestWeak || weak.confidence > bestWeak.confidence || (weak.confidence === bestWeak.confidence && weak.vehicleCount > bestWeak.vehicleCount)) {
          bestWeak = weak;
        }
        console.warn(`[ROUTER] Weak result from ${adapter?.id || "unknown"}`, result?.confidence);
        record('scan_weak', { domain, adapter: adapter?.id || 'unknown', confidence, count: vehicleCount, durationMs, reason: 'below_threshold_or_empty' });
      } catch (error) {
        console.error(`[ROUTER] Adapter failed: ${adapter?.id || "unknown"}`, error);
        record('scan_failure', { domain, adapter: adapter?.id || 'unknown', reason: error?.message || 'scan_error', durationMs: Date.now() - startedAt });
      }
    }

    if (bestWeak?.vehicleCount) {
      return {
        ...bestWeak.result,
        diagnostics: {
          ...(bestWeak.result?.diagnostics || {}),
          adapter: bestWeak.adapterId,
          reason: 'best_weak_result',
          locked: false
        }
      };
    }

    console.warn("[ROUTER] Falling back to empty result");
    record('scan_failure', { domain, adapter: 'fallback', reason: 'fallback_triggered' });
    return fallbackResult("fallback_triggered");
  }

  function fallbackResult(reason) {
    return {
      vehicles: [],
      confidence: 0,
      diagnostics: {
        adapter: "fallback",
        reason
      }
    };
  }

  window.ElevateAdapterRouter = { runAdapterScan };
})();
