// queue-manager.js
// Central client-side queue control for Elevate Automation
// Strict patch: aligned to the live hardened worker contract

(function () {
  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function digitsOnly(value) {
    return String(value || "").replace(/[^\d]/g, "");
  }

  function buildVehicleKey(vehicle) {
    if (!vehicle) return "";

    const vin = clean(vehicle.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(vehicle.stock || vehicle.stock_number || "").toUpperCase();
    if (stock) return `STOCK:${stock}`;

    return [
      clean(vehicle.year || "").toUpperCase(),
      clean(vehicle.make || "").toUpperCase(),
      clean(vehicle.model || "").toUpperCase(),
      digitsOnly(vehicle.price || ""),
      digitsOnly(vehicle.kilometers || vehicle.km || vehicle.mileage || "")
    ].join("|");
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          resolve(response || null);
        });
      } catch (error) {
        resolve({
          ok: false,
          error: error?.message || "Runtime message failed"
        });
      }
    });
  }

  async function getState() {
    const result = await sendRuntimeMessage({ type: "GET_STATE" });
    return {
      ok: true,
      vehicle: result?.vehicle || null,
      vehicleQueue: Array.isArray(result?.vehicleQueue) ? result.vehicleQueue : [],
      dwFieldMap: result?.dwFieldMap || {},
      extensionSession: result?.extensionSession || null,
      lastPostedVehicleKey: result?.lastPostedVehicleKey || "",
      lastPostAt: result?.lastPostAt || ""
    };
  }

  function sanitizeQueue(queue) {
    const list = Array.isArray(queue) ? queue : [];
    const seen = new Set();
    const sanitized = [];

    for (const vehicle of list) {
      const key = buildVehicleKey(vehicle);
      if (!key) continue;
      if (seen.has(key)) continue;
      seen.add(key);
      sanitized.push(vehicle);
    }

    return sanitized;
  }

  async function getQueue() {
    const state = await getState();
    const queue = sanitizeQueue(state.vehicleQueue || []);
    return {
      ok: true,
      queue,
      queueLength: queue.length
    };
  }

  async function getCurrentVehicle() {
    const state = await getState();
    return {
      ok: true,
      vehicle: state.vehicle || null,
      key: buildVehicleKey(state.vehicle || null)
    };
  }

  async function setCurrentVehicle(vehicle) {
    const result = await sendRuntimeMessage({
      type: "SAVE_CURRENT_VEHICLE",
      vehicle: vehicle || null
    });

    return {
      ok: !!result?.ok,
      vehicle: result?.vehicle || null,
      key: buildVehicleKey(result?.vehicle || null),
      error: result?.error || ""
    };
  }

  async function saveQueue(queue) {
    const sanitizedQueue = sanitizeQueue(queue);
    const result = await sendRuntimeMessage({
      type: "SAVE_QUEUE",
      queue: sanitizedQueue
    });

    return {
      ok: !!result?.ok,
      queue: sanitizeQueue(Array.isArray(result?.queue) ? result.queue : sanitizedQueue),
      queueLength: Number(result?.queueLength || sanitizeQueue(Array.isArray(result?.queue) ? result.queue : sanitizedQueue).length),
      error: result?.error || ""
    };
  }

  async function addToQueue(vehicle) {
    const state = await getState();
    const queue = sanitizeQueue(Array.isArray(state.vehicleQueue) ? [...state.vehicleQueue] : []);
    const nextVehicle = vehicle || null;
    const nextKey = buildVehicleKey(nextVehicle);

    if (!nextVehicle || !nextKey) {
      return {
        ok: false,
        added: false,
        skipped: "invalid_vehicle",
        queue,
        queueLength: queue.length,
        error: "Invalid vehicle"
      };
    }

    const alreadyInQueue = queue.some((item) => buildVehicleKey(item) === nextKey);
    if (alreadyInQueue) {
      return {
        ok: true,
        added: false,
        skipped: "duplicate_queue",
        queue,
        queueLength: queue.length,
        error: ""
      };
    }

    const postedCheck = await sendRuntimeMessage({
      type: "IS_VEHICLE_POSTED",
      vehicle: nextVehicle
    });

    if (postedCheck?.posted) {
      return {
        ok: true,
        added: false,
        skipped: "already_posted",
        queue,
        queueLength: queue.length,
        error: ""
      };
    }

    queue.push(nextVehicle);
    const saved = await saveQueue(queue);

    return {
      ok: !!saved?.ok,
      added: !!saved?.ok,
      skipped: "",
      queue: Array.isArray(saved?.queue) ? saved.queue : queue,
      queueLength: Number(saved?.queueLength || queue.length),
      error: saved?.error || ""
    };
  }

  async function removeFromQueueIndex(index) {
    const state = await getState();
    const queue = sanitizeQueue(Array.isArray(state.vehicleQueue) ? [...state.vehicleQueue] : []);
    const idx = Number(index);

    if (!Number.isInteger(idx) || idx < 0 || idx >= queue.length) {
      return {
        ok: false,
        removed: null,
        queue,
        queueLength: queue.length,
        error: "Invalid queue index"
      };
    }

    const removed = queue.splice(idx, 1)[0] || null;
    const saved = await saveQueue(queue);

    return {
      ok: !!saved?.ok,
      removed,
      queue: Array.isArray(saved?.queue) ? saved.queue : queue,
      queueLength: Number(saved?.queueLength || queue.length),
      error: saved?.error || ""
    };
  }

  async function loadNextQueueItem() {
    const result = await sendRuntimeMessage({
      type: "LOAD_NEXT_QUEUE_ITEM"
    });

    return {
      ok: !!result?.ok,
      vehicle: result?.vehicle || null,
      queue: sanitizeQueue(Array.isArray(result?.queue) ? result.queue : sanitizedQueue),
      queueLength: Number(result?.queueLength || sanitizeQueue(Array.isArray(result?.queue) ? result.queue : sanitizedQueue).length),
      error: result?.error || result?.reason || ""
    };
  }

  async function markCurrentVehiclePosted() {
    const current = await getCurrentVehicle();
    if (!current?.vehicle) {
      return {
        ok: false,
        error: "No current vehicle loaded"
      };
    }

    const result = await sendRuntimeMessage({
      type: "MARK_VEHICLE_POSTED",
      vehicle: current.vehicle
    });

    return {
      ok: !!result?.ok,
      key: result?.key || "",
      error: result?.error || ""
    };
  }

  async function isCurrentVehiclePosted() {
    const current = await getCurrentVehicle();
    if (!current?.vehicle) {
      return {
        ok: false,
        posted: false,
        error: "No current vehicle loaded"
      };
    }

    const result = await sendRuntimeMessage({
      type: "IS_VEHICLE_POSTED",
      vehicle: current.vehicle
    });

    return {
      ok: !!result?.ok,
      posted: !!result?.posted,
      key: result?.key || current.key || "",
      error: result?.error || ""
    };
  }

  async function replaceCurrentVehicleFromQueue() {
    const next = await loadNextQueueItem();

    if (!next.ok || !next.vehicle) {
      return {
        ok: false,
        error: next?.error || "Queue empty",
        vehicle: null,
        queueLength: Number(next?.queueLength || 0)
      };
    }

    return {
      ok: true,
      vehicle: next.vehicle,
      queueLength: Number(next?.queueLength || 0)
    };
  }

  async function requeueCurrentVehicle() {
    const current = await getCurrentVehicle();
    if (!current?.vehicle) {
      return {
        ok: false,
        error: "No current vehicle loaded"
      };
    }

    return addToQueue(current.vehicle);
  }

  async function dedupeQueue() {
    const state = await getState();
    const queue = sanitizeQueue(state.vehicleQueue);
    return saveQueue(queue);
  }

  async function clearCurrentVehicle() {
    return setCurrentVehicle(null);
  }

  async function clearQueue() {
    return saveQueue([]);
  }

  window.ElevateQueueManager = {
    buildVehicleKey,
    getState,
    getQueue,
    getCurrentVehicle,
    setCurrentVehicle,
    saveQueue,
    addToQueue,
    removeFromQueueIndex,
    loadNextQueueItem,
    markCurrentVehiclePosted,
    isCurrentVehiclePosted,
    replaceCurrentVehicleFromQueue,
    requeueCurrentVehicle,
    dedupeQueue,
    clearCurrentVehicle,
    clearQueue
  };
})();
