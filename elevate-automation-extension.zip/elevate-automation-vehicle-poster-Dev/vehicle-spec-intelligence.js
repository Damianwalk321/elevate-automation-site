// vehicle-spec-intelligence.js
// Elevate Automation Spec Intelligence V11
// Higher-confidence body/fuel inference with cleaner source ranking

(function () {
  const LOG_PREFIX = "[Elevate Spec Intelligence V11]";

  function log(...args) { console.log(LOG_PREFIX, ...args); }
  function clean(value) { return String(value || "").replace(/\s+/g, " ").trim(); }
  function lower(value) { return clean(value).toLowerCase(); }
  function clamp01(n) { return Math.max(0, Math.min(1, Number(n || 0))); }

  const MODEL_BODY_MAP = {
    corolla: "Sedan", camry: "Sedan", rav4: "SUV", highlander: "SUV", "4runner": "SUV", venza: "SUV", tundra: "Truck", tacoma: "Truck", sienna: "Van", rx: "SUV", nx: "SUV", gx: "SUV",
    civic: "Sedan", accord: "Sedan", crv: "SUV", "cr-v": "SUV", hrv: "SUV", "hr-v": "SUV", pilot: "SUV", passport: "SUV", odyssey: "Van", ridgeline: "Truck", rdx: "SUV", mdx: "SUV",
    "f150": "Truck", "f-150": "Truck", ranger: "Truck", maverick: "Truck", bronco: "SUV", "bronco sport": "SUV", explorer: "SUV", expedition: "SUV", escape: "SUV", edge: "SUV", aviator: "SUV", navigator: "SUV",
    silverado: "Truck", colorado: "Truck", blazer: "SUV", traverse: "SUV", tahoe: "SUV", suburban: "SUV", equinox: "SUV", terrain: "SUV", acadia: "SUV", sierra: "Truck", canyon: "Truck", envision: "SUV", enclave: "SUV",
    "1500": "Truck", "1500 classic": "Truck", "2500": "Truck", "3500": "Truck", durango: "SUV", journey: "SUV", "grand cherokee": "SUV", grandcherokee: "SUV", wrangler: "SUV", gladiator: "Truck",
    mazda3: "Sedan", "mazda 3": "Sedan", cx5: "SUV", "cx-5": "SUV", cx30: "SUV", "cx-30": "SUV", cx50: "SUV", "cx-50": "SUV", cx9: "SUV", "cx-9": "SUV",
    sentra: "Sedan", altima: "Sedan", maxima: "Sedan", rogue: "SUV", murano: "SUV", pathfinder: "SUV", frontier: "Truck", qx50: "SUV", qx60: "SUV",
    elantra: "Sedan", sonata: "Sedan", tucson: "SUV", santafe: "SUV", "santa fe": "SUV", palisade: "SUV", kona: "SUV", seltos: "SUV", sportage: "SUV", sorento: "SUV", telluride: "SUV", forte: "Sedan", g70: "Sedan", gv70: "SUV", gv80: "SUV",
    wrx: "Sedan", outback: "Wagon", forester: "SUV", crosstrek: "SUV", impreza: "Sedan",
    atlas: "SUV", tiguan: "SUV", taos: "SUV", jetta: "Sedan", golf: "Hatchback", q3: "SUV", q5: "SUV", q7: "SUV", x1: "SUV", x3: "SUV", x5: "SUV", glc: "SUV", gle: "SUV", cayenne: "SUV", macan: "SUV", xc60: "SUV", xc90: "SUV",
    outlander: "SUV", eclipsecross: "SUV", "eclipse cross": "SUV"
  };

  const BODY_KEYWORDS = [
    [/\btruck|pickup\b/i, "Truck", 0.92],
    [/\bsuv|crossover\b/i, "SUV", 0.9],
    [/\bsedan\b/i, "Sedan", 0.86],
    [/\bcoupe\b/i, "Coupe", 0.84],
    [/\bhatch|sportback\b/i, "Hatchback", 0.84],
    [/\bwagon\b/i, "Wagon", 0.84],
    [/\bminivan|van\b/i, "Van", 0.9]
  ];

  function getTextInputs(vehicle = {}) {
    return [
      lower(vehicle.model),
      lower(vehicle.title),
      lower([vehicle.make, vehicle.model].filter(Boolean).join(" ")),
      lower([vehicle.model, vehicle.trim].filter(Boolean).join(" ")),
      lower(vehicle.rawText),
      lower(vehicle.body_style),
      lower(vehicle.specs?.body)
    ].filter(Boolean);
  }

  function detectBodyStyleResult(vehicle = {}) {
    const explicit = clean(vehicle.body_style || vehicle.body || vehicle.specs?.body || "");
    if (explicit && /(truck|suv|sedan|coupe|hatch|wagon|van|minivan)/i.test(explicit)) {
      const normalized = explicit.toLowerCase().includes("hatch") ? "Hatchback"
        : explicit.toLowerCase().includes("wagon") ? "Wagon"
        : explicit.toLowerCase().includes("coupe") ? "Coupe"
        : explicit.toLowerCase().includes("van") ? "Van"
        : explicit.toLowerCase().includes("truck") || explicit.toLowerCase().includes("pickup") ? "Truck"
        : explicit.toLowerCase().includes("suv") || explicit.toLowerCase().includes("crossover") ? "SUV"
        : "Sedan";
      return { value: normalized, confidence: 0.99, source: "explicit" };
    }

    const keys = getTextInputs(vehicle);
    for (const key of keys) {
      for (const [model, body] of Object.entries(MODEL_BODY_MAP)) {
        if (key.includes(model)) return { value: body, confidence: 0.9, source: `model:${model}` };
      }
    }

    const text = keys.join(" ");
    for (const [pattern, value, confidence] of BODY_KEYWORDS) {
      if (pattern.test(text)) return { value, confidence, source: "keyword" };
    }

    return { value: "", confidence: 0, source: "none" };
  }

  function detectFuelTypeResult(vehicle = {}) {
    const explicit = clean(vehicle.fuel_type || vehicle.fuel || vehicle.specs?.fuel || "");
    const text = lower([
      explicit,
      vehicle.title,
      vehicle.model,
      vehicle.trim,
      vehicle.rawText
    ].filter(Boolean).join(" "));

    if (/\b(hybrid|phev|plug[- ]?in|prime)\b/.test(text)) return { value: "Hybrid", confidence: explicit ? 0.99 : 0.9, source: explicit ? "explicit" : "keyword" };
    if (/\b(electric|ev)\b/.test(text)) return { value: "Electric", confidence: explicit ? 0.99 : 0.9, source: explicit ? "explicit" : "keyword" };
    if (/\b(diesel|tdi|duramax|ecodiesel|cummins)\b/.test(text)) return { value: "Diesel", confidence: explicit ? 0.99 : 0.9, source: explicit ? "explicit" : "keyword" };
    if (/\b(gas|gasoline)\b/.test(text)) return { value: "Gasoline", confidence: explicit ? 0.99 : 0.84, source: explicit ? "explicit" : "keyword" };
    return { value: explicit, confidence: explicit ? 0.8 : 0, source: explicit ? "explicit" : "none" };
  }

  function detectBodyStyle(vehicle) { return detectBodyStyleResult(vehicle).value; }
  function detectFuelType(vehicle) { return detectFuelTypeResult(vehicle).value; }
  function detectFuel(vehicle) { return detectFuelType(vehicle); }

  function enrichSpecs(input) {
    const vehicle = { ...(input || {}) };
    const currentConfidence = vehicle.confidence || {};
    const bodyResult = detectBodyStyleResult(vehicle);
    const fuelResult = detectFuelTypeResult(vehicle);

    if (!clean(vehicle.body_style) && bodyResult.value) vehicle.body_style = bodyResult.value;
    if (!clean(vehicle.fuel_type) && fuelResult.value) vehicle.fuel_type = fuelResult.value;
    if (!vehicle.vehicle_type && vehicle.body_style) vehicle.vehicle_type = "Cars & Trucks";

    vehicle.confidence = {
      ...currentConfidence,
      body: clamp01(Math.max(Number(currentConfidence.body || 0), Number(bodyResult.confidence || 0))),
      fuel: clamp01(Math.max(Number(currentConfidence.fuel || 0), Number(fuelResult.confidence || 0))),
      color: clamp01(Number(currentConfidence.color || 0))
    };

    vehicle.enrichment_meta = {
      ...(vehicle.enrichment_meta || {}),
      body_source: vehicle.enrichment_meta?.body_source || bodyResult.source,
      fuel_source: vehicle.enrichment_meta?.fuel_source || fuelResult.source
    };

    vehicle.specs = {
      ...(vehicle.specs || {}),
      body: clean(vehicle.specs?.body || vehicle.body_style),
      fuel: clean(vehicle.specs?.fuel || vehicle.fuel_type),
      exterior_color: clean(vehicle.specs?.exterior_color || vehicle.exterior_color),
      vehicle_type: clean(vehicle.specs?.vehicle_type || vehicle.vehicle_type)
    };

    return vehicle;
  }

  window.ElevateSpecIntelligence = {
    enrichSpecs,
    detectBodyStyle,
    detectBodyStyleResult,
    detectFuelType,
    detectFuelTypeResult,
    detectFuel
  };

  log("Loaded");
})();
