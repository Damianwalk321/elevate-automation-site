

// posting-gate.js
// Elevate Automation Posting Gate V3 (Hardened)
// Access control + prepared payload bridge + inflight protection

(function () {
  const API_BASE_URL = "https://elevate-automation-site.vercel.app";
  const PREPARED_POST_KEY = "eaPreparedMarketplacePost";
  const PREPARED_POST_TS_KEY = "eaPreparedMarketplacePostTs";
  const PREPARED_POST_TTL_MS = 1000 * 60 * 30;

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function digitsOnly(v) {
    return String(v || "").replace(/[^\d]/g, "");
  }

  // 🔑 VEHICLE KEY (CRITICAL)
  function getVehicleKey(v) {
    if (!v) return "";

    const vin = clean(v.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(v.stock || v.stock_number || "");
    if (stock) return `STOCK:${stock}`;

    return [
      clean(v.year || ""),
      clean(v.make || ""),
      clean(v.model || ""),
      digitsOnly(v.price || ""),
      digitsOnly(v.km || v.kilometers || v.mileage || "")
    ].join("|");
  }

  function normalizeVehicleForMarketplace(vehicle) {
    const v = { ...(vehicle || {}) };

    const kilometers = Number(v.km || v.kilometers || v.mileage || 0) || "";
    const price = Number(v.price || v.list_price || v.asking_price || 0) || "";

    const bodyStyle = clean(v.body_style || v.bodyStyle || v.body || v.specs?.body || "");
    const exteriorColor = clean(v.exterior_color || v.exteriorColor || v.color || v.specs?.exterior_color || "");
    const fuelType = clean(v.fuel_type || v.fuelType || v.fuel || v.specs?.fuel || "");
    const vehicleType = clean(v.vehicle_type || v.vehicleType || v.marketplaceVehicleType || v.specs?.vehicle_type || "") || "Car/Truck";

    return {
      ...v,
      vehicleType,
      marketplaceVehicleType: vehicleType,
      location: clean(v.location || v.listing_location || v.listingLocation || ""),
      year: clean(v.year || ""),
      make: clean(v.make || ""),
      model: clean(v.model || ""),
      trim: clean(v.trim || ""),
      kilometers,
      mileage: kilometers,
      price,
      bodyStyle,
      exteriorColor,
      fuelType,
      vin: clean(v.vin || "").toUpperCase(),
      stock: clean(v.stock || v.stock_number || v.stockNumber || ""),
      sourceUrl: clean(v.source_url || v.sourceUrl || v.url || ""),
      coverPhotoUrl: clean(v.coverPhotoUrl || v.cover_photo_url || ""),
      photoUrls: Array.isArray(v.photoUrls) ? v.photoUrls.filter(Boolean) : [],
      description: clean(v.description || v.listing?.description || ""),
      confidence: {
        fuelType: v.confidence?.fuelType || v.confidence?.fuel || "",
        bodyStyle: v.confidence?.bodyStyle || v.confidence?.body || "",
        exteriorColor: v.confidence?.exteriorColor || v.confidence?.color || "",
        marketplaceVehicleType: v.confidence?.marketplaceVehicleType || ""
      }
    };
  }

  async function checkIfPostingAllowed(vehicle) {
    const vehicleKey = getVehicleKey(vehicle);

    let result = await window.ElevateExtensionSession.canUserPostNow(vehicleKey);

    if (!result.allowed && ["inactive_access", "inactive_subscription", "update_required"].includes(clean(result.reason || "").toLowerCase())) {
      try {
        await window.ElevateExtensionSession.refreshExtensionState?.();
        result = await window.ElevateExtensionSession.canUserPostNow(vehicleKey);
      } catch (error) {
        console.warn("refreshExtensionState before post failed:", error?.message || error);
      }
    }

    if (!result.allowed) {
      const reason = result.reason || "Posting unavailable";

      if (reason.includes("limit")) {
        const state = result.state || {};
        alert(`Daily posting limit reached. Used ${state.posts_today}/${state.posting_limit}`);
        return { allowed: false, reason };
      }

      if (reason.includes("inflight")) {
        alert("A post is already in progress. Please wait.");
        return { allowed: false, reason };
      }

      if (reason.includes("update")) {
        alert("Extension update required. Refresh access in dashboard and install the latest build.");
        return { allowed: false, reason };
      }

      if (reason.includes("inactive")) {
        alert("Access is inactive. Refresh access in the dashboard and confirm billing/setup is complete.");
        return { allowed: false, reason };
      }

      alert(`Posting blocked: ${reason}`);
      return { allowed: false, reason };
    }

    return result;
  }

  async function registerMarketplacePost(vehicle) {
  const normalized = normalizeVehicleForMarketplace(vehicle);
  const vehicleKey = getVehicleKey(normalized);
  const vehicleId = normalized?.vin || normalized?.stock || vehicleKey;

  if (!vehicleKey) {
    return {
      success: false,
      error: "Missing vehicle key"
    };
  }

  let workerResult = null;

  try {
    workerResult = await chrome.runtime.sendMessage({
      type: "CONFIRM_POST_SUCCESS",
      vehicle: normalized,
      key: vehicleKey,
      vehicle_id: vehicleId
    });

    if (workerResult?.ok) {
      // keep going — we still want to force backend register-post
    }
  } catch (error) {
    console.warn("CONFIRM_POST_SUCCESS fallback path:", error?.message || error);
  }

  // 🔥 BACKEND REGISTER-POST FALLBACK FOR DASHBOARD
  if (!workerResult?.ok) {
    try {
      const sessionResult = await window.ElevateExtensionSession?.getExtensionState?.();
      const extState = sessionResult?.success ? (sessionResult.data || {}) : {};

      const userId =
        extState?.user?.id ||
        extState?.user_id ||
        extState?.id ||
        extState?.profile?.id ||
        extState?.session_snapshot?.user?.id ||
        extState?.session_snapshot?.user_id ||
        "";

      const email =
        extState?.user?.email ||
        extState?.email ||
        extState?.user_email ||
        extState?.profile?.dealer_email ||
        extState?.profile?.email ||
        extState?.session_snapshot?.user?.email ||
        extState?.session_snapshot?.email ||
        "";

      const backendResponse = await fetch(`${API_BASE_URL}/api/register-post`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          user_id: userId,
          email,
          vehicle_id: vehicleId,
          marketplace_listing_id: normalized?.marketplace_listing_id || normalized?.vehicle_id || "",
          vin: normalized?.vin || "",
          stock_number: normalized?.stock || normalized?.stock_number || "",
          source_url: normalized?.sourceUrl || normalized?.source_url || "",
          title:
            normalized?.title ||
            [normalized?.year, normalized?.make, normalized?.model, normalized?.trim]
              .filter(Boolean)
              .join(" "),
          year: normalized?.year || "",
          make: normalized?.make || "",
          model: normalized?.model || "",
          trim: normalized?.trim || "",
          price: Number(normalized?.price || 0),
          mileage: Number(normalized?.mileage || normalized?.kilometers || normalized?.km || 0),
          location:
            normalized?.location ||
            normalized?.listing_location ||
            "",
          status: "active"
        })
      });

      const backendJson = await backendResponse.json().catch(() => null);

      if (!backendResponse.ok) {
        console.warn("[register-post fallback] failed:", backendJson || backendResponse.status);
      } else if (backendJson?.posting_state && window.ElevateExtensionSession?.applyServerPostingState) {
        await window.ElevateExtensionSession.applyServerPostingState(backendJson.posting_state);
      }
    } catch (error) {
      console.warn("[register-post fallback] outer error:", error?.message || error);
    }
  }

  if (workerResult?.ok) {
    return {
      success: true,
      source: "worker",
      data: workerResult
    };
  }

  const result = await window.ElevateExtensionSession.registerSuccessfulPost(vehicleKey);

  if (!result.success) {
    console.error("registerMarketplacePost failed:", result);
    return {
      success: false,
      error: result.error || "Failed to register post"
    };
  }

  return {
    ...result,
    source: "session_fallback"
  };
}

  async function preparePostingPayload(vehicle) {
    const normalized = normalizeVehicleForMarketplace(vehicle);

    const payload = {
      vehicle: normalized,
      createdAt: Date.now(),
      source: "dealer_inventory"
    };

    await chrome.storage.local.set({
      vehicle: normalized,
      [PREPARED_POST_KEY]: payload,
      [PREPARED_POST_TS_KEY]: payload.createdAt
    });

    return payload;
  }

  async function getPreparedPostingPayload() {
    const state = await chrome.storage.local.get([PREPARED_POST_KEY, PREPARED_POST_TS_KEY]);

    const payload = state?.[PREPARED_POST_KEY] || null;
    const createdAt = Number(state?.[PREPARED_POST_TS_KEY] || 0);

    if (!payload || !createdAt) return null;

    if (Date.now() - createdAt > PREPARED_POST_TTL_MS) {
      await clearPreparedPostingPayload();
      return null;
    }

    return payload;
  }

  async function clearPreparedPostingPayload() {
    await chrome.storage.local.remove([PREPARED_POST_KEY, PREPARED_POST_TS_KEY]);
    return { success: true };
  }

  async function startPostingFlow(vehicle, opts = {}) {
    const allowed = await checkIfPostingAllowed(vehicle);
    if (!allowed?.allowed) {
      return { success: false, reason: allowed?.reason || "blocked" };
    }

    const vehicleKey = getVehicleKey(vehicle);

    // 🔒 SET INFLIGHT LOCK BEFORE NAVIGATION
    const inflight = await window.ElevateExtensionSession.setInflightPost(vehicleKey);
    if (!inflight.success) {
      alert("Unable to start post. Another vehicle may already be posting.");
      return { success: false, reason: "inflight_blocked" };
    }

    const payload = await preparePostingPayload(vehicle);
    const targetUrl = opts.marketplaceUrl || "https://www.facebook.com/marketplace/create/vehicle";

    try {
      if (chrome?.tabs?.create) {
        chrome.tabs.create({ url: targetUrl, active: true });
      } else {
        window.open(targetUrl, "_blank");
      }
    } catch {
      window.open(targetUrl, "_blank");
    }

    return { success: true, payload };
  }

  window.ElevatePostingGate = {
    checkIfPostingAllowed,
    registerMarketplacePost,
    preparePostingPayload,
    getPreparedPostingPayload,
    clearPreparedPostingPayload,
    startPostingFlow,
    normalizeVehicleForMarketplace
  };
})();
