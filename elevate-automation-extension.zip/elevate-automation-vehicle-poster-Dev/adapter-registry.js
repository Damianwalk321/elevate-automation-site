// adapter-registry.js
// Global adapter registry for MV3 content scripts

(function () {
  const ADAPTERS = [];

  function normalizeId(value) { return String(value || "").trim().toLowerCase(); }
  function toInstance(input) {
    if (!input) return null;
    if (typeof input === "function") {
      try { return new input(); } catch (error) { console.warn("[Elevate Adapter Registry] failed to instantiate adapter", error); return null; }
    }
    return input;
  }

  function register(input) {
    const adapter = toInstance(input);
    const id = normalizeId(adapter?.id || adapter?.constructor?.id || adapter?.constructor?.key);
    if (!adapter || !id) {
      console.warn("[Elevate Adapter Registry] adapter missing id", input);
      return null;
    }
    const existingIndex = ADAPTERS.findIndex((item) => normalizeId(item.id) === id);
    adapter.id = id;
    adapter.priority = Number(adapter.priority ?? adapter.constructor?.priority ?? 0);
    if (existingIndex >= 0) ADAPTERS.splice(existingIndex, 1, adapter);
    else ADAPTERS.push(adapter);
    return adapter;
  }

  function list() {
    return ADAPTERS.slice().sort((a, b) => Number(b.priority || 0) - Number(a.priority || 0)).map((adapter) => ({ id: adapter.id, priority: Number(adapter.priority || 0), adapter }));
  }

  function getById(id) {
    const needle = normalizeId(id);
    if (!needle) return null;
    return ADAPTERS.find((adapter) => normalizeId(adapter.id) === needle) || null;
  }

  function resolve(ctx = {}) {
    const intelligence = window.ElevateAdapterIntelligence;
    const domain = normalizeId(ctx?.domain || ctx?.host || location.hostname || '');
    const preferred = intelligence?.getPreferredAdapter ? normalizeId(intelligence.getPreferredAdapter(domain)) : '';

    return ADAPTERS
      .map((adapter) => {
        try {
          const result = typeof adapter.canHandle === "function" ? (adapter.canHandle(ctx) || { ok: false, confidence: 0 }) : { ok: false, confidence: 0 };
          const baseConfidence = Number(result.confidence || 0);
          const intelligenceBoost = intelligence?.getBoost ? Number(intelligence.getBoost(domain, adapter.id) || 0) : 0;
          const preferredBoost = preferred && preferred === normalizeId(adapter.id) ? 0.04 : 0;
          return {
            adapter,
            id: adapter.id,
            priority: Number(adapter.priority || 0),
            ok: result.ok === true,
            confidence: Math.min(0.99, baseConfidence + intelligenceBoost + preferredBoost),
            baseConfidence,
            intelligenceBoost,
            preferredBoost
          };
        } catch (error) {
          console.warn("[Elevate Adapter Registry] canHandle failed", adapter?.id, error);
          return { adapter, id: adapter?.id || "unknown", priority: Number(adapter?.priority || 0), ok: false, confidence: 0, baseConfidence: 0, intelligenceBoost: 0, preferredBoost: 0 };
        }
      })
      .filter((item) => item.ok)
      .sort((a, b) => {
        if (b.confidence !== a.confidence) return b.confidence - a.confidence;
        return b.priority - a.priority;
      });
  }

  window.ElevateAdapterRegistry = { register, list, getById, resolve };
})();
