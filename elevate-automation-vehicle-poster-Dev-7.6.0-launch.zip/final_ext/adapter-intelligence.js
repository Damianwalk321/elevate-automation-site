// adapter-intelligence.js
// Elevate Adapter Intelligence Layer V2

(function () {
  const STORAGE_KEY = "ea_adapter_intelligence_v2";
  const MAX_DOMAINS = 200;
  let stateCache = {};

  function clean(v) { return String(v || "").trim(); }
  function lower(v) { return clean(v).toLowerCase(); }
  function save(state) {
    const keys = Object.keys(state || {});
    const trimmed = {};
    keys.slice(-MAX_DOMAINS).forEach((k) => { trimmed[k] = state[k]; });
    stateCache = trimmed;
    try { chrome.storage.local.set({ [STORAGE_KEY]: trimmed }); } catch {}
  }
  function load() { return stateCache || {}; }
  try { chrome.storage.local.get(STORAGE_KEY, (data) => { stateCache = (data?.[STORAGE_KEY] && typeof data[STORAGE_KEY] === "object") ? data[STORAGE_KEY] : {}; }); } catch {}
  function ensureDomain(state, domain) {
    const key = lower(domain || location.hostname || 'unknown');
    state[key] = state[key] || { adapters: {}, updatedAt: Date.now() };
    state[key].adapters = state[key].adapters || {};
    state[key].updatedAt = Date.now();
    return state[key];
  }
  function ensureAdapter(bucket, adapter) {
    const key = lower(adapter || 'generic');
    bucket.adapters[key] = bucket.adapters[key] || { attempts: 0, successes: 0, failures: 0, weak: 0, candidateEvents: 0, candidateTotal: 0, avgConfidence: 0, lastSuccessAt: 0, lastFailureAt: 0, lastCandidateAt: 0 };
    return bucket.adapters[key];
  }
  function updateAvg(current, next, count) {
    if (!count) return Number(next || 0);
    return ((Number(current || 0) * (count - 1)) + Number(next || 0)) / count;
  }
  function record(event = {}) {
    const state = load();
    const bucket = ensureDomain(state, event.domain);
    const adapter = ensureAdapter(bucket, event.adapter);
    const type = lower(event.type);
    if (type === 'scan_attempt') { adapter.attempts += 1; adapter.avgConfidence = updateAvg(adapter.avgConfidence, Number(event.confidence || 0), adapter.attempts); }
    if (type === 'scan_success') { adapter.successes += 1; adapter.lastSuccessAt = Date.now(); adapter.avgConfidence = updateAvg(adapter.avgConfidence, Number(event.confidence || 0), Math.max(adapter.attempts, 1)); }
    if (type === 'scan_failure') { adapter.failures += 1; adapter.lastFailureAt = Date.now(); }
    if (type === 'scan_weak') { adapter.weak += 1; }
    if (type === 'candidate_resolution') { adapter.candidateEvents += 1; adapter.candidateTotal += Number(event.count || 0); adapter.lastCandidateAt = Date.now(); }
    save(state);
    return state;
  }
  function getDomainProfile(domain) {
    const state = load();
    return state[lower(domain || location.hostname || 'unknown')] || { adapters: {}, updatedAt: 0 };
  }
  function getDomainHealth(domain) {
    const bucket = getDomainProfile(domain);
    return Object.entries(bucket.adapters || {}).map(([adapter, stats]) => {
      const attempts = Number(stats.attempts || 0);
      const successes = Number(stats.successes || 0);
      const failures = Number(stats.failures || 0);
      const weak = Number(stats.weak || 0);
      const successRate = attempts ? successes / attempts : 0;
      const avgCandidates = stats.candidateEvents ? stats.candidateTotal / stats.candidateEvents : 0;
      return { adapter, attempts, successes, failures, weak, successRate, avgConfidence: Number(stats.avgConfidence || 0), avgCandidates, lastSuccessAt: Number(stats.lastSuccessAt || 0), lastFailureAt: Number(stats.lastFailureAt || 0) };
    }).sort((a, b) => (b.successRate - a.successRate) || (b.avgConfidence - a.avgConfidence) || (b.successes - a.successes));
  }
  function getPreferredAdapter(domain) { return getDomainHealth(domain)[0]?.adapter || ''; }
  function getBoost(domain, adapter) { const row = getDomainHealth(domain).find((item) => item.adapter === lower(adapter)); if (!row) return 0; return Math.min(0.08, (row.successRate * 0.05) + (row.avgConfidence * 0.03)); }
  function getHealthReport() { const out = {}; Object.keys(load()).forEach((domain) => { out[domain] = getDomainHealth(domain); }); return out; }
  function clear() { stateCache = {}; try { chrome.storage.local.remove(STORAGE_KEY); } catch {} }
  window.ElevateAdapterIntelligence = { record, getDomainProfile, getDomainHealth, getPreferredAdapter, getBoost, getHealthReport, clear };
})();
