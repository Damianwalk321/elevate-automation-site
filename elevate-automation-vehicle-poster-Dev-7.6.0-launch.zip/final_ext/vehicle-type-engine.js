// vehicle-type-engine.js
// Elevate Automation Vehicle Type Engine V1

function detectVehicleType(vehicle){

const body = (vehicle.body_style || "").toLowerCase()

if(body.includes("truck")) return "Cars & Trucks"
if(body.includes("suv")) return "Cars & Trucks"
if(body.includes("wagon")) return "Cars & Trucks"
if(body.includes("sedan")) return "Cars & Trucks"
if(body.includes("coupe")) return "Cars & Trucks"
if(body.includes("hatch")) return "Cars & Trucks"
if(body.includes("van")) return "Cars & Trucks"

if(body.includes("motorcycle")) return "Motorcycles"
if(body.includes("atv")) return "Powersports"
if(body.includes("utv")) return "Powersports"

if(body.includes("rv")) return "RVs & Campers"
if(body.includes("camper")) return "RVs & Campers"

if(body.includes("boat")) return "Boats"

if(body.includes("trailer")) return "Trailers"

return "Cars & Trucks"

}

window.ElevateVehicleType = {
detectVehicleType
}