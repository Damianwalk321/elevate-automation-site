// adapter-telemetry.js
// Elevate Adapter Telemetry V2

(function () {
  const STORAGE_KEY = "ea_adapter_telemetry_v2";
  const MAX_EVENTS = 400;
  let cache = [];
  let loaded = false;

  function now() { return Date.now(); }
  function clean(v) { return String(v || "").trim(); }
  function readStorage(cb) {
    try {
      chrome.storage.local.get(STORAGE_KEY, (data) => cb(Array.isArray(data?.[STORAGE_KEY]) ? data[STORAGE_KEY] : []));
    } catch { cb([]); }
  }
  function writeStorage(events) {
    cache = Array.isArray(events) ? events.slice(-MAX_EVENTS) : [];
    try { chrome.storage.local.set({ [STORAGE_KEY]: cache }); } catch {}
  }
  readStorage((events) => { cache = events; loaded = true; });

  function record(type, payload) {
    const event = {
      type: clean(type),
      ts: now(),
      domain: clean(payload?.domain || location.hostname || ""),
      adapter: clean(payload?.adapter || payload?.adapterId || ""),
      routeId: clean(payload?.routeId || ""),
      success: payload?.success === true,
      confidence: Number(payload?.confidence || 0),
      count: Number(payload?.count || payload?.vehicleCount || payload?.candidateCount || 0),
      durationMs: Number(payload?.durationMs || 0),
      reason: clean(payload?.reason || ""),
      meta: payload?.meta || {}
    };
    const events = Array.isArray(cache) ? cache.slice() : [];
    events.push(event);
    writeStorage(events);
    try { console.log("[ELEVATE ADAPTER TELEMETRY]", event); } catch {}
    return event;
  }

  function getLogs() { return Array.isArray(cache) ? cache.slice() : []; }
  function list() { return getLogs(); }
  function clear() { cache = []; try { chrome.storage.local.remove(STORAGE_KEY); } catch {} }

  window.ElevateAdapterTelemetry = { record, list, getLogs, clear, isLoaded: () => loaded };
})();
