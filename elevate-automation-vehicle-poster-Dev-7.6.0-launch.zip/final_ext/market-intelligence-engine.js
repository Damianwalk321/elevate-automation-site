// market-intelligence-engine.js
// Elevate Automation Market Intelligence Engine V1

function log(...a){
console.log("[Elevate Market Intelligence]",...a)
}

/* -------------------------------------
COLLECT STORED LISTING DATA
------------------------------------- */

function getAllListingData(){

const records = []

Object.keys(localStorage).forEach(key=>{

if(key.startsWith("elevate_listing_")){

try{

records.push(
JSON.parse(localStorage.getItem(key))
)

}catch(e){}

}

})

return records

}

/* -------------------------------------
GROUP VEHICLES BY MODEL CLUSTER
------------------------------------- */

function groupByCluster(records){

const map = {}

records.forEach(r=>{

if(!r.cluster) return

if(!map[r.cluster]){

map[r.cluster] = []

}

map[r.cluster].push(r)

})

return map

}

/* -------------------------------------
CALCULATE AVERAGE PRICE
------------------------------------- */

function calculateAveragePrice(list){

if(!list.length) return null

let total = 0
let count = 0

list.forEach(v=>{

if(v.price){

total += v.price
count++

}

})

if(!count) return null

return Math.round(total / count)

}

/* -------------------------------------
DEMAND SCORE
------------------------------------- */

function calculateDemandScore(list){

/*
simple initial logic

more listings posted
= higher demand
*/

return Math.min(list.length * 10,100)

}

/* -------------------------------------
BEST POSTING TIME
------------------------------------- */

function bestPostingHour(list){

const hours = {}

list.forEach(v=>{

const hour =
new Date(v.timestamp).getHours()

if(!hours[hour]) hours[hour] = 0

hours[hour]++

})

let bestHour = null
let bestCount = 0

Object.keys(hours).forEach(h=>{

if(hours[h] > bestCount){

bestHour = h
bestCount = hours[h]

}

})

return bestHour

}

/* -------------------------------------
GENERATE MARKET REPORT
------------------------------------- */

function generateMarketInsights(){

const data = getAllListingData()

const grouped = groupByCluster(data)

const report = {}

Object.keys(grouped).forEach(cluster=>{

const vehicles = grouped[cluster]

report[cluster] = {

average_price:
calculateAveragePrice(vehicles),

demand_score:
calculateDemandScore(vehicles),

best_post_hour:
bestPostingHour(vehicles),

total_listings:
vehicles.length

}

})

return report

}

window.ElevateMarketIntelligence = {

generateMarketInsights

}