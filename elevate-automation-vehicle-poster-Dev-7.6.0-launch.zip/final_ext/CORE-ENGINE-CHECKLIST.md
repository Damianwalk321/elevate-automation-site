# Core Engine Checklist

## Current Baseline
v4.1.3-smart-photo-compressor

## Must Pass Before Beta
- [ ] Dealer assistant panel loads
- [ ] Row buttons appear on inventory cards
- [ ] Inventory scanner detects vehicles correctly
- [ ] Queue builds correctly
- [ ] Start Posting opens Marketplace with selected vehicle
- [ ] Marketplace assistant loads reliably
- [ ] Sequential autofill completes in correct order
- [ ] Mileage fills automatically
- [ ] Price fills correctly
- [ ] Body style fills correctly
- [ ] Exterior colour fills correctly
- [ ] Fuel type fills correctly
- [ ] Description fills correctly
- [ ] Cover photo uploads reliably
- [ ] Next queued vehicle loads correctly
- [ ] No false error messages
- [ ] Dealer/client profile section exists
- [ ] Province compliance dropdown exists
- [ ] UI is clean and easy to follow
