// spec-enrichment.js
// Elevate Automation Spec Enrichment V6

(function(){

function enrichVehicle(vehicle){

/* VIN decode */

if(window.ElevateVINDecoder){

vehicle=window.ElevateVINDecoder.decodeVIN(vehicle)

}

/* body detection */

if(!vehicle.body_style){

vehicle.body_style=
window.ElevateSpecIntelligence.detectBodyStyle(vehicle)

}

/* fuel detection */

if(!vehicle.fuel_type){

vehicle.fuel_type=
window.ElevateSpecIntelligence.detectFuel(vehicle)

}

return vehicle

}

window.ElevateSpecEnrichment={
enrichVehicle
}

})()