// dashboard-profile-sync.js
// Elevate Automation Dashboard Profile Sync
// Pulls profile/compliance data from dashboard and exposes it to content scripts

(function () {
  const PROFILE_KEY = "ea_dashboard_profile_v1";

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function normalizeProvince(value) {
    const raw = clean(value).toUpperCase();
    if (raw === "ALBERTA" || raw === "AB") return "AB";
    if (raw === "BRITISH COLUMBIA" || raw === "BC") return "BC";
    return raw;
  }

  function buildComplianceSignature(profile) {
    const province = normalizeProvince(profile?.province || profile?.compliance_zone || profile?.compliance_mode || "");

    if (province === "AB") {
      return "AMVIC Licensed Dealer";
    }

    if (province === "BC") {
      return "Licensed Motor Dealer";
    }

    return "";
  }

  function normalizeProfile(raw = {}) {
    const province = normalizeProvince(
      raw.province ||
      raw.compliance_zone ||
      raw.compliance_mode ||
      raw.profile?.province ||
      raw.profile?.compliance_zone ||
      raw.profile?.compliance_mode
    );

    const city = clean(raw.city || raw.profile?.city || "");
    const listingLocation = clean(
      raw.listing_location ||
      raw.location ||
      raw.profile?.listing_location ||
      raw.profile?.location ||
      (city && province ? `${city}, ${province}` : city)
    );

    const profile = {
      salesperson_name: clean(raw.salesperson_name || raw.full_name || raw.name || raw.profile?.full_name || raw.profile?.name || ""),
      full_name: clean(raw.full_name || raw.name || raw.profile?.full_name || raw.profile?.name || ""),
      phone: clean(raw.phone || raw.profile?.phone || raw.dealer_phone || raw.profile?.dealer_phone || ""),
      email: clean(raw.email || raw.profile?.email || raw.dealer_email || raw.profile?.dealer_email || ""),
      dealer_name: clean(raw.dealership || raw.dealer_name || raw.profile?.dealership || raw.profile?.dealer_name || ""),
      dealer_phone: clean(raw.dealer_phone || raw.profile?.dealer_phone || ""),
      dealer_email: clean(raw.dealer_email || raw.profile?.dealer_email || ""),
      province,
      city,
      location: listingLocation,
      listing_location: listingLocation,
      compliance_zone: province,
      compliance_mode: province,
      license_number: clean(raw.license_number || raw.profile?.license_number || ""),
      dealer_site: clean(raw.dealer_site || raw.profile?.dealer_website || ""),
      inventory_url: clean(raw.inventory_url || raw.profile?.inventory_url || ""),
      compliance_signature: ""
    };

    profile.compliance_signature = buildComplianceSignature(profile);

    return profile;
  }

  async function storageGet(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => resolve(result?.[key] || null));
    });
  }

  async function storageSet(payload) {
    return new Promise((resolve) => {
      chrome.storage.local.set(payload, () => resolve(true));
    });
  }

  async function saveProfile(rawProfile) {
    const normalized = normalizeProfile(rawProfile || {});
    await storageSet({ [PROFILE_KEY]: normalized });
    window.__EA_PROFILE = normalized;
    return normalized;
  }

  async function loadProfile() {
    const stored = await storageGet(PROFILE_KEY);
    if (stored) {
      window.__EA_PROFILE = stored;
      return stored;
    }

    window.__EA_PROFILE = {};
    return {};
  }

  function emitProfileSync(profile) {
    window.postMessage(
      {
        type: "ELEVATE_PROFILE_SYNC",
        payload: {
          profile
        }
      },
      "*"
    );
  }

  window.ElevateDashboardProfileSync = {
    loadProfile,
    saveProfile,
    normalizeProfile,
    emitProfileSync
  };

  loadProfile();
})();