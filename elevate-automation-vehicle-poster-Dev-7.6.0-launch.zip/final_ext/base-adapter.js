// base-adapter.js
// Elevate Adapter Base Class (global content-script safe)

(function () {
  class BaseDealerAdapter {
    static id = "base";
    static priority = 0;

    constructor(ctx = {}) {
      this.ctx = ctx;
      this.id = this.constructor.id || this.constructor.key || "base";
      this.priority = Number(this.constructor.priority || 0);
    }

    static canHandle() {
      return { ok: false, confidence: 0 };
    }

    canHandle(ctx = {}) {
      return this.constructor.canHandle(ctx);
    }

    async scanInventory() {
      return {
        vehicles: [],
        confidence: 0,
        diagnostics: {
          adapter: this.id,
          reason: "not_implemented"
        }
      };
    }

    async enrichVehicle(vehicle = {}) {
      return vehicle;
    }

    async collectImages() {
      return [];
    }

    resolveCandidates() {
      return [];
    }

    normalize(vehicle = {}) {
      return vehicle;
    }

    log(...args) {
      console.log(`[ADAPTER:${this.id}]`, ...args);
    }
  }

  window.ElevateAdapterBase = window.ElevateAdapterBase || {};
  window.ElevateAdapterBase.BaseDealerAdapter = BaseDealerAdapter;
})();
