// ai-sales-caption-engine.js
// Elevate Automation AI Sales Caption Engine V2
// Uses synced profile + compliance-aware copy generation

(function () {
  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function digits(value) {
    return String(value || "").replace(/[^\d]/g, "");
  }

  function money(value) {
    const n = Number(digits(value));
    if (!n) return "";
    return `$${n.toLocaleString()}`;
  }

  function km(value) {
    const n = Number(digits(value));
    if (!n) return "";
    return `${n.toLocaleString()} KM`;
  }

  function pick(...values) {
    for (const value of values) {
      const v = clean(value);
      if (v) return v;
    }
    return "";
  }

  function normalizeProvince(value) {
    const raw = clean(value).toUpperCase();
    if (raw === "ALBERTA" || raw === "AB") return "AB";
    if (raw === "BRITISH COLUMBIA" || raw === "BC") return "BC";
    return raw;
  }

  function normalizeProfile(profile = {}) {
    return {
      full_name: pick(profile.full_name, profile.salesperson_name),
      salesperson_name: pick(profile.salesperson_name, profile.full_name),
      dealer_name: pick(profile.dealer_name, profile.dealership),
      dealership: pick(profile.dealership, profile.dealer_name),
      phone: pick(profile.phone, profile.dealer_phone),
      dealer_phone: pick(profile.dealer_phone, profile.phone),
      dealer_email: pick(profile.dealer_email, profile.email),
      email: pick(profile.email, profile.dealer_email),
      listing_location: pick(profile.listing_location, profile.location, profile.city),
      location: pick(profile.location, profile.listing_location, profile.city),
      province: normalizeProvince(profile.province),
      compliance_signature: pick(profile.compliance_signature)
    };
  }

  function vehicleName(vehicle) {
    return clean([
      vehicle?.year,
      vehicle?.make,
      vehicle?.model,
      vehicle?.specs?.trim || vehicle?.trim
    ].filter(Boolean).join(" "));
  }

  function buildTitle(vehicle) {
    const name = vehicleName(vehicle);
    const drivetrain = pick(vehicle?.specs?.drivetrain, vehicle?.drivetrain);
    return clean([name, drivetrain].filter(Boolean).join(" | "));
  }

  function buildHook(vehicle) {
    const priceText = money(vehicle?.price);
    const body = pick(vehicle?.specs?.body, vehicle?.body_style, vehicle?.bodyStyle);
    const drivetrain = pick(vehicle?.specs?.drivetrain, vehicle?.drivetrain);
    const kmText = km(vehicle?.km || vehicle?.kilometers || vehicle?.mileage);

    const options = [
      clean(`${vehicleName(vehicle)} available now.`),
      clean(`${priceText} ${body} ready to go.`),
      clean(`${kmText} ${drivetrain} ${body}`),
      vehicleName(vehicle)
    ].filter(Boolean);

    return options[0] || "";
  }

  function buildShortCaption(vehicle, profile = {}) {
    const p = normalizeProfile(profile);
    const location = pick(p.listing_location, p.location);
    const salesperson = pick(p.salesperson_name, p.full_name, "our team");
    const priceText = money(vehicle?.price);
    const kmText = km(vehicle?.km || vehicle?.kilometers || vehicle?.mileage);

    return [
      buildTitle(vehicle),
      [priceText, kmText].filter(Boolean).join(" • "),
      location ? `Located in ${location}` : "",
      `Message ${salesperson} for availability.`
    ].filter(Boolean).join("\n");
  }

  function buildDescription(vehicle, profile = {}) {
    const p = normalizeProfile(profile);

    if (window.ElevateComplianceEngine?.buildListing) {
      try {
        const listing = window.ElevateComplianceEngine.buildListing(vehicle, p);
        if (listing?.description) return listing.description;
      } catch (error) {
        console.warn("[Elevate Caption Engine] Compliance build failed:", error);
      }
    }

    if (window.ElevateDescriptionBuilder?.buildDescription) {
      try {
        return window.ElevateDescriptionBuilder.buildDescription(vehicle, p);
      } catch (error) {
        console.warn("[Elevate Caption Engine] Description builder fallback failed:", error);
      }
    }

    return `${vehicleName(vehicle)}\n${money(vehicle?.price)}\n${km(vehicle?.km || vehicle?.kilometers)}`.trim();
  }

  function buildCompliantCaption(vehicle, profile = {}) {
    const p = normalizeProfile(profile);

    if (window.ElevateComplianceEngine?.buildListing) {
      try {
        const listing = window.ElevateComplianceEngine.buildListing(vehicle, p);
        if (listing?.caption) return listing.caption;
      } catch (error) {
        console.warn("[Elevate Caption Engine] Compliance caption build failed:", error);
      }
    }

    return buildShortCaption(vehicle, p);
  }

  function buildCaptionPackage(vehicle, profile = {}) {
    const p = normalizeProfile(profile);

    return {
      title: buildTitle(vehicle),
      hook: buildHook(vehicle),
      short_caption: buildShortCaption(vehicle, p),
      sales_caption: buildCompliantCaption(vehicle, p),
      description: buildDescription(vehicle, p)
    };
  }

  window.ElevateCaptionEngine = {
    buildCaptionPackage,
    buildTitle,
    buildHook,
    buildShortCaption,
    buildDescription,
    buildCompliantCaption
  };
})();
