// marketplace-insights.js
// Elevate Marketplace Insights Collector V1
// Scrapes Facebook Marketplace selling/profile pages for listing views/messages
// and syncs lifecycle metrics back to the dashboard backend.

(function () {
  const STORAGE_KEY = "ea_marketplace_listings";
  const SYNC_DEBOUNCE_MS = 3000;
  const RESCAN_MS = 12000;
  let lastHash = "";
  let syncTimer = null;

  function log(...args) {
    console.log("[Elevate Marketplace Insights]", ...args);
  }

  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function parseCount(input) {
    const raw = clean(input).toLowerCase().replace(/,/g, "");
    if (!raw) return 0;
    const match = raw.match(/(\d+(?:\.\d+)?)([km]?)/i);
    if (!match) return 0;
    const value = Number(match[1] || 0);
    const suffix = (match[2] || "").toLowerCase();
    if (suffix === "k") return Math.round(value * 1000);
    if (suffix === "m") return Math.round(value * 1000000);
    return Math.round(value);
  }

  function getSessionIdentity() {
    const session = window.__EA_EXTENSION_SESSION || {};
    const user = session.user || {};
    const profile = session.profile || {};
    return {
      user_id: clean(session.user_id || user.id || ""),
      email: clean(session.email || user.email || "").toLowerCase(),
      dealership_id: clean(session.dealership_id || profile.dealership_id || "")
    };
  }

  function normalizeItemUrl(href) {
    try {
      const url = new URL(href, location.origin);
      return `${url.origin}${url.pathname}`;
    } catch {
      return clean(href || "");
    }
  }

  function extractListingCards() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/marketplace/item/"]'));
    const byId = new Map();

    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") || "";
      const itemId = (href.match(/\/marketplace\/item\/(\d+)/i) || [])[1] || "";
      if (!itemId) continue;

      const card = anchor.closest('[role="article"]') || anchor.closest('div[role="button"]') || anchor.parentElement || anchor;
      const text = clean(card?.innerText || anchor.innerText || "");
      if (!text) continue;

      const title = clean(text.split("\n")[0] || "");
      const viewsMatch = text.match(/(\d+(?:[\.,]\d+)?\s*[kKmM]?)\s*(?:views?|viewers?)/i);
      const messagesMatch = text.match(/(\d+(?:[\.,]\d+)?\s*[kKmM]?)\s*(?:messages?|message|inquiries?|chats?)/i);
      const statusMatch = text.match(/\b(pending|sold|active|paused|draft)\b/i);

      const listing = {
        id: itemId,
        source_url: normalizeItemUrl(href),
        title,
        status: clean(statusMatch?.[1] || "active").toLowerCase(),
        views_count: parseCount(viewsMatch?.[1] || 0),
        messages_count: parseCount(messagesMatch?.[1] || 0),
        vehicle: {
          vehicle_id: itemId,
          source_url: normalizeItemUrl(href),
          title,
          status: clean(statusMatch?.[1] || "active").toLowerCase(),
          views_count: parseCount(viewsMatch?.[1] || 0),
          messages_count: parseCount(messagesMatch?.[1] || 0)
        }
      };

      const prev = byId.get(itemId);
      if (!prev || listing.views_count > prev.views_count || listing.messages_count > prev.messages_count) {
        byId.set(itemId, listing);
      }
    }

    return Array.from(byId.values());
  }

  async function getStoredListings() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(STORAGE_KEY, (data) => resolve(data?.[STORAGE_KEY] || {}));
      } catch {
        resolve({});
      }
    });
  }

  async function setStoredListings(payload) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set({ [STORAGE_KEY]: payload || {} }, () => resolve(true));
      } catch {
        resolve(false);
      }
    });
  }

  async function syncListings(listings) {
    const identity = getSessionIdentity();
    const payload = {
      ...identity,
      hostname: location.hostname,
      page_url: location.href,
      sync_reason: "marketplace_insights",
      listings,
      total_views: listings.reduce((sum, row) => sum + Number(row.views_count || 0), 0),
      total_messages: listings.reduce((sum, row) => sum + Number(row.messages_count || 0), 0),
      active_listings: listings.filter((row) => !["sold", "deleted", "inactive"].includes(clean(row.status).toLowerCase())).length,
      lifecycle_updated_at: new Date().toISOString()
    };

    try {
      const response = await chrome.runtime.sendMessage({
        type: "UPSERT_MARKETPLACE_INSIGHTS",
        listings,
        payload
      });
      log("sync result", response);
    } catch (error) {
      console.warn("[Elevate Marketplace Insights] sync failed:", error?.message || error);
    }
  }

  async function collectAndSync() {
    const href = clean(location.href).toLowerCase();
    if (!href.includes("/marketplace/")) return;
    if (!(href.includes("/marketplace/you/selling") || href.includes("/marketplace/profile/") || href.includes("/marketplace/item/"))) {
      return;
    }

    const listings = extractListingCards();
    if (!listings.length) return;

    const snapshotHash = JSON.stringify(listings.map((row) => [row.id, row.views_count, row.messages_count, row.status]).sort());
    if (snapshotHash === lastHash) return;
    lastHash = snapshotHash;

    const existing = await getStoredListings();
    const merged = { ...(existing || {}) };
    for (const row of listings) {
      const prev = merged[row.id] || {};
      merged[row.id] = {
        ...prev,
        ...row,
        vehicle: { ...(prev.vehicle || {}), ...(row.vehicle || {}) },
        views_count: Math.max(Number(prev.views_count || 0), Number(row.views_count || 0)),
        messages_count: Math.max(Number(prev.messages_count || 0), Number(row.messages_count || 0)),
        updated_at: new Date().toISOString()
      };
    }

    await setStoredListings(merged);

    if (syncTimer) clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      syncListings(Object.values(merged));
    }, SYNC_DEBOUNCE_MS);
  }

  function boot() {
    collectAndSync().catch(() => {});
    const observer = new MutationObserver(() => {
      collectAndSync().catch(() => {});
    });
    observer.observe(document.documentElement || document.body, { childList: true, subtree: true });
    setInterval(() => {
      collectAndSync().catch(() => {});
    }, RESCAN_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
