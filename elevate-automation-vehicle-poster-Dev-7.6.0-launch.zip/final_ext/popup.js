// popup.js — V3 backend-first access + version enforcement

(async function () {
  const DASHBOARD_URL = "https://elevate-automation-site.vercel.app/dashboard.html";

  const state = { session: null, currentTab: null, loading: false };

  function qs(s) { return document.querySelector(s); }
  function clean(v) { return String(v || "").replace(/\s+/g, " " ).trim(); }
  function lower(v) { return clean(v).toLowerCase(); }
  function numberOr(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
  function manifestVersion() { try { return chrome.runtime.getManifest()?.version || "0.0.0"; } catch { return "0.0.0"; } }
  function compareVersions(a, b) {
    const pa = String(a || "0.0.0").split(".").map((x) => Number(x) || 0);
    const pb = String(b || "0.0.0").split(".").map((x) => Number(x) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i += 1) {
      if ((pa[i] || 0) > (pb[i] || 0)) return 1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  function setStatus(msg = "", tone = "muted") {
    const el = qs("#eaPopupStatus");
    if (!el) return;
    if (!msg) { el.style.display = "none"; return; }
    el.style.display = "block";
    el.textContent = msg;
    el.className = `ea-popup-status ea-popup-status--${tone}`;
  }

  function setLoading(v) {
    state.loading = v;
    const btn = qs("#eaSyncBtn");
    if (!btn) return;
    btn.disabled = v;
    btn.textContent = v ? "Syncing..." : "Refresh Access";
  }

  async function getCurrentTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    state.currentTab = tabs?.[0] || null;
  }

  async function sendToWorker(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (res) => resolve(res || null));
    });
  }

  function extractSession(res) {
    if (!res) return null;
    return res.session || res.data || res;
  }

  function getPlan(session) { return clean(session?.subscription?.plan || session?.plan || "Starter") || "Starter"; }
  function getLimit(session) { return numberOr(session?.subscription?.posting_limit ?? session?.posting_limit, 0); }
  function getUsed(session) { return numberOr(session?.subscription?.posts_today ?? session?.posts_today, 0); }
  function getRemaining(session) {
    if (session?.subscription?.posts_remaining != null) return Math.max(numberOr(session.subscription.posts_remaining, 0), 0);
    return Math.max(getLimit(session) - getUsed(session), 0);
  }
  function isActive(session) {
    return Boolean(session?.subscription?.active || lower(session?.subscription?.status) === "active");
  }
  function isUpdateRequired(session) {
    if (session?.subscription?.update_required === true) return true;
    const minimum = clean(session?.subscription?.minimum_version || session?.minimum_version || "");
    return minimum ? compareVersions(manifestVersion(), minimum) < 0 : false;
  }
  function getAccessText(session) {
    if (!session) return "No Session";
    if (isUpdateRequired(session)) return "Update Required";
    if (!isActive(session)) return "Inactive";
    if (getRemaining(session) <= 0) return "Limit Reached";
    return "Active";
  }
  function getTone(session) {
    if (!session) return "warn";
    if (isUpdateRequired(session) || !isActive(session) || getRemaining(session) <= 0) return "bad";
    return "good";
  }
  function buildStat(label, value) {
    return `
      <div class="ea-popup-stat">
        <div class="ea-popup-stat-label">${label}</div>
        <div class="ea-popup-stat-value">${value}</div>
      </div>
    `;
  }

  function render(session) {
    const root = qs("#eaPopupRoot");
    if (!root) return;
    const currentVersion = manifestVersion();
    const latestVersion = clean(session?.subscription?.latest_version || session?.latest_version || currentVersion) || currentVersion;
    root.innerHTML = `
      <div class="ea-popup-shell">
        <div class="ea-popup-header">
          <div class="ea-popup-eyebrow">Elevate Automation</div>
          <div class="ea-popup-title">Extension Control</div>
        </div>

        <div id="eaPopupStatus" class="ea-popup-status" style="display:none;"></div>

        <div class="ea-popup-card ea-popup-card--gold">
          <div class="ea-popup-card-title">Access</div>
          <div class="ea-popup-badge ea-popup-badge--${getTone(session)}">
            ${getAccessText(session)}
          </div>

          <div class="ea-popup-grid">
            ${buildStat("Plan", getPlan(session))}
            ${buildStat("Remaining", getRemaining(session))}
            ${buildStat("Limit", getLimit(session))}
            ${buildStat("Used", getUsed(session))}
          </div>
        </div>

        <div class="ea-popup-card">
          <div class="ea-popup-card-title">Version</div>
          <div class="ea-popup-grid">
            ${buildStat("Current", currentVersion)}
            ${buildStat("Latest", latestVersion)}
            ${buildStat("Dealer", clean(session?.dealership?.name || "-"))}
            ${buildStat("Status", clean(session?.subscription?.status || "inactive") || "inactive")}
          </div>
        </div>

        <div class="ea-popup-actions">
          <button id="eaSyncBtn" class="ea-popup-btn ea-popup-btn--primary">Refresh Access</button>
          <button id="eaDashBtn" class="ea-popup-btn ea-popup-btn--secondary">Dashboard</button>
        </div>
      </div>
    `;
    qs("#eaSyncBtn").onclick = refresh;
    qs("#eaDashBtn").onclick = () => chrome.tabs.create({ url: DASHBOARD_URL });
  }

  async function refresh() {
    setLoading(true);
    setStatus("Syncing...", "warn");
    try {
      let res = await sendToWorker({
        type: "EA_FETCH_EXTENSION_STATE",
        clientVersion: manifestVersion(),
        hostname: state.currentTab?.url || "",
        pageUrl: state.currentTab?.url || ""
      });
      let session = extractSession(res);
      if (!session) {
        res = await sendToWorker({ type: "EA_GET_EXTENSION_STATE" });
        session = extractSession(res);
      }
      if (!session) { setStatus("No session found", "bad"); return; }
      state.session = session;
      render(session);
      if (isUpdateRequired(session)) {
        const latest = clean(session?.subscription?.latest_version || session?.latest_version || "") || "latest";
        setStatus(`Update required. Install version ${latest}.`, "bad");
      } else if (!isActive(session)) {
        setStatus("Subscription inactive", "bad");
      } else {
        setStatus("Synced", "good");
      }
    } catch {
      setStatus("Sync failed", "bad");
    } finally {
      setLoading(false);
    }
  }

  async function init() {
    await getCurrentTab();
    const res = await sendToWorker({ type: "EA_GET_EXTENSION_STATE" });
    const session = extractSession(res);
    if (session) {
      state.session = session;
      render(session);
      setStatus(isUpdateRequired(session) ? "Update required" : "Session loaded", isUpdateRequired(session) ? "bad" : "good");
    } else {
      setStatus("Not connected", "warn");
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
