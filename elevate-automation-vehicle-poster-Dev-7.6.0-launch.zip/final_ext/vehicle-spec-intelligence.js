// vehicle-spec-intelligence.js
// Elevate Automation Spec Intelligence V10
// Broad Canadian coverage + clean body/fuel inference

(function () {
  const LOG_PREFIX = "[Elevate Spec Intelligence V10]";

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function lower(value) {
    return clean(value).toLowerCase();
  }

  const MODEL_BODY_MAP = {
    // Toyota / Lexus
    corolla: "Sedan",
    camry: "Sedan",
    rav4: "SUV",
    highlander: "SUV",
    "4runner": "SUV",
    venza: "SUV",
    tundra: "Truck",
    tacoma: "Truck",
    sienna: "Van",
    rx: "SUV",
    nx: "SUV",
    gx: "SUV",

    // Honda / Acura
    civic: "Sedan",
    accord: "Sedan",
    crv: "SUV",
    "cr-v": "SUV",
    hrv: "SUV",
    "hr-v": "SUV",
    pilot: "SUV",
    passport: "SUV",
    odyssey: "Van",
    ridgeline: "Truck",
    rdx: "SUV",
    mdx: "SUV",

    // Ford / Lincoln
    "f150": "Truck",
    "f-150": "Truck",
    ranger: "Truck",
    maverick: "Truck",
    bronco: "SUV",
    "bronco sport": "SUV",
    explorer: "SUV",
    expedition: "SUV",
    escape: "SUV",
    edge: "SUV",
    aviator: "SUV",
    navigator: "SUV",

    // GM
    silverado: "Truck",
    colorado: "Truck",
    blazer: "SUV",
    traverse: "SUV",
    tahoe: "SUV",
    suburban: "SUV",
    equinox: "SUV",
    terrain: "SUV",
    acadia: "SUV",
    sierra: "Truck",
    canyon: "Truck",
    envision: "SUV",
    enclave: "SUV",

    // Ram / Dodge / Jeep / Chrysler
    "1500": "Truck",
    "1500 classic": "Truck",
    "2500": "Truck",
    "3500": "Truck",
    durango: "SUV",
    journey: "SUV",
    grandcherokee: "SUV",
    "grand cherokee": "SUV",
    wrangler: "SUV",
    gladiator: "Truck",

    // Mazda
    mazda3: "Sedan",
    "mazda 3": "Sedan",
    cx5: "SUV",
    "cx-5": "SUV",
    cx30: "SUV",
    "cx-30": "SUV",
    cx50: "SUV",
    "cx-50": "SUV",
    cx9: "SUV",
    "cx-9": "SUV",

    // Nissan / Infiniti
    sentra: "Sedan",
    altima: "Sedan",
    maxima: "Sedan",
    rogue: "SUV",
    murano: "SUV",
    pathfinder: "SUV",
    frontier: "Truck",
    qx50: "SUV",
    qx60: "SUV",

    // Hyundai / Kia / Genesis
    elantra: "Sedan",
    sonata: "Sedan",
    tucson: "SUV",
    santafe: "SUV",
    "santa fe": "SUV",
    palisade: "SUV",
    kona: "SUV",
    seltos: "SUV",
    sportage: "SUV",
    sorento: "SUV",
    telluride: "SUV",
    forte: "Sedan",
    g70: "Sedan",
    gv70: "SUV",
    gv80: "SUV",

    // Subaru
    wrx: "Sedan",
    outback: "Wagon",
    forester: "SUV",
    crosstrek: "SUV",
    impreza: "Sedan",

    // VW / Audi / Porsche / BMW / Mercedes / Volvo / Mini
    atlas: "SUV",
    tiguan: "SUV",
    taos: "SUV",
    jetta: "Sedan",
    golf: "Hatchback",
    q3: "SUV",
    q5: "SUV",
    q7: "SUV",
    x1: "SUV",
    x3: "SUV",
    x5: "SUV",
    glc: "SUV",
    gle: "SUV",
    cayenne: "SUV",
    macan: "SUV",
    xc60: "SUV",
    xc90: "SUV",

    // Mitsubishi
    outlander: "SUV",
    eclipsecross: "SUV",
    "eclipse cross": "SUV"
  };

  function modelKeys(vehicle) {
    const values = [
      lower(vehicle.model),
      lower(vehicle.title),
      lower([vehicle.make, vehicle.model].filter(Boolean).join(" ")),
      lower([vehicle.model, vehicle.trim].filter(Boolean).join(" "))
    ];

    return values.filter(Boolean);
  }

  function detectBodyStyle(vehicle) {
    const keys = modelKeys(vehicle);

    for (const key of keys) {
      for (const [model, body] of Object.entries(MODEL_BODY_MAP)) {
        if (key.includes(model)) return body;
      }
    }

    const text = keys.join(" ");

    if (/\btruck|pickup\b/.test(text)) return "Truck";
    if (/\bsuv|crossover\b/.test(text)) return "SUV";
    if (/\bsedan\b/.test(text)) return "Sedan";
    if (/\bcoupe\b/.test(text)) return "Coupe";
    if (/\bhatch\b/.test(text)) return "Hatchback";
    if (/\bwagon\b/.test(text)) return "Wagon";
    if (/\bvan|minivan\b/.test(text)) return "Van";

    return "";
  }

  function detectFuelType(vehicle) {
    const text = lower(
      [
        vehicle.fuel_type,
        vehicle.title,
        vehicle.model,
        vehicle.trim,
        vehicle.rawText
      ]
        .filter(Boolean)
        .join(" ")
    );

    if (/\bhybrid|phev|plug[- ]?in|prime\b/.test(text)) return "Hybrid";
    if (/\belectric|ev\b/.test(text)) return "Electric";
    if (/\bdiesel|tdi|duramax|ecodiesel|cummins\b/.test(text)) return "Diesel";
    if (vehicle.vin) return "Gasoline";
    return "";
  }

  function enrichSpecs(input) {
    const vehicle = { ...(input || {}) };
    vehicle.confidence = {
      body: Number(vehicle.confidence?.body || 0),
      fuel: Number(vehicle.confidence?.fuel || 0),
      color: Number(vehicle.confidence?.color || 0)
    };

    if (!vehicle.body_style) {
      const body = detectBodyStyle(vehicle);
      if (body) {
        vehicle.body_style = body;
        vehicle.confidence.body = Math.max(vehicle.confidence.body, 0.85);
      }
    }

    if (!vehicle.fuel_type) {
      const fuel = detectFuelType(vehicle);
      if (fuel) {
        vehicle.fuel_type = fuel;
        vehicle.confidence.fuel = Math.max(vehicle.confidence.fuel, 0.85);
      }
    }

    if (!vehicle.vehicle_type && vehicle.body_style) {
      vehicle.vehicle_type = "Cars & Trucks";
    }

    vehicle.specs = {
      ...(vehicle.specs || {}),
      body: clean(vehicle.specs?.body || vehicle.body_style),
      fuel: clean(vehicle.specs?.fuel || vehicle.fuel_type),
      exterior_color: clean(vehicle.specs?.exterior_color || vehicle.exterior_color),
      vehicle_type: clean(vehicle.specs?.vehicle_type || vehicle.vehicle_type)
    };

    return vehicle;
  }

  window.ElevateSpecIntelligence = {
    enrichSpecs,
    detectBodyStyle,
    detectFuelType
  };

  log("Loaded");
})();