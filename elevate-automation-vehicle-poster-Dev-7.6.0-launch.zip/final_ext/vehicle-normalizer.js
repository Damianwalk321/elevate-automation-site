// vehicle-normalizer.js
(function () {
  function clean(v){return String(v||"").replace(/\s+/g," ").trim();}
  function lower(v){return clean(v).toLowerCase();}
  function digits(v){return String(v||"").replace(/[^\d]/g,"");}
  function stripJunk(v){
    return clean(String(v||"")
      .replace(/[\u{1F300}-\u{1FAFF}]/gu, " ")
      .replace(/[\u2600-\u27BF]/gu, " ")
      .replace(/[•◆■►▶✅❌✔️➡️📍🚗💰🛡️📞]/gu, " ")
      .replace(/[^\x20-\x7E\u00C0-\u024F]/g, " "));
  }
  function sanitize(v){ return clean(stripJunk(v)); }
  function src(vehicle){ return clean([vehicle?.title, vehicle?.rawText, vehicle?.raw_text].filter(Boolean).join(" ")); }
  function extractYear(text){ return clean(text).match(/\b(19|20)\d{2}\b/)?.[0] || ""; }
  function extractMake(text){
    const raw = lower(text);
    const makes = [["toyota","Toyota"],["honda","Honda"],["ford","Ford"],["chevrolet","Chevrolet"],["chevy","Chevrolet"],["gmc","GMC"],["ram","Ram"],["dodge","Dodge"],["jeep","Jeep"],["mazda","Mazda"],["nissan","Nissan"],["hyundai","Hyundai"],["kia","Kia"],["subaru","Subaru"],["volkswagen","Volkswagen"],["vw","Volkswagen"],["audi","Audi"],["bmw","BMW"],["mercedes","Mercedes-Benz"],["porsche","Porsche"],["lexus","Lexus"],["acura","Acura"],["infiniti","Infiniti"],["genesis","Genesis"],["mitsubishi","Mitsubishi"],["buick","Buick"],["cadillac","Cadillac"],["lincoln","Lincoln"],["volvo","Volvo"],["mini","MINI"]];
    for (const [needle, value] of makes) if (new RegExp(`\\b${needle}\\b`, "i").test(raw)) return value;
    return "";
  }
  function splitModelTrim(vehicle){
    const year = sanitize(vehicle?.year || "");
    const make = sanitize(vehicle?.make || "");
    let work = sanitize(vehicle?.title || src(vehicle));
    if (year) work = work.replace(new RegExp(`\\b${year}\\b`, "i"), " ");
    if (make) work = work.replace(new RegExp(`\\b${make.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i"), " ");
    work = sanitize(work.replace(/\bin\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+\d+\b/g, " ").replace(/\bgrande prairie\b/gi, " ").replace(/\bedmonton\b/gi, " ").replace(/\balberta\b/gi, " "));
    work = work.replace(/\bmazda\s+3\b/i, "Mazda3");
    work = work.replace(/\bmazda3\s+3\b/i, "Mazda3");
    const tokens = work.split(/\s+/).filter(Boolean).filter((t) => !/^(in|at|stock|vin|price|km|kms|automatic|manual)$/i.test(t));
    if (!tokens.length) return { model:"", trim:"" };
    const joined = tokens.join(" ");
    const patterns = [[/^bronco sport\b/i,"Bronco Sport"],[/^cx[- ]5\b/i,"CX-5"],[/^cx[- ]50\b/i,"CX-50"],[/^mazda3\b/i,"Mazda3"],[/^1500 classic\b/i,"1500 Classic"],[/^double cab\b/i,"Double Cab"],[/^big horn\b/i,"Big Horn"],[/^high country\b/i,"High Country"],[/^sel premium\b/i,"SEL Premium"],[/^trd sport\b/i,"TRD Sport"],[/^trd off[- ]road\b/i,"TRD Off-Road"]];
    for (const [p,val] of patterns) {
      if (p.test(joined)) {
        const used = val.split(/\s+/).length;
        return { model: val, trim: tokens.slice(used).join(" ") };
      }
    }
    return { model: tokens[0] || "", trim: tokens.slice(1).join(" ") };
  }
  function normalizeBody(v){
    const raw = lower([v?.body_style, v?.body, v?.title, v?.rawText].filter(Boolean).join(" "));
    if (/\btundra|tacoma|silverado|colorado|sierra|f150|f-150|ram|ranger|maverick\b/.test(raw)) return "Truck";
    if (/\bbronco|explorer|envision|outlander|blazer|cx-5|cx5|seltos|pilot|rav4|highlander|sportage|sorento|rogue|murano|pathfinder|atlas|venza|durango|passport|cr-v\b/.test(raw)) return "SUV";
    if (/\bjetta|corolla|civic|accord|camry|wrx|mazda3|elantra|sentra|altima|malibu\b/.test(raw)) return "Sedan";
    if (/\boutback\b/.test(raw)) return "Wagon";
    return sanitize(v?.body_style || v?.body || "");
  }
  function normalizeFuel(v){
    const raw = lower([v?.fuel_type, v?.fuel, v?.title, v?.rawText].filter(Boolean).join(" "));
    if (/hybrid|phev|plug[- ]?in|prime/.test(raw)) return "Hybrid";
    if (/electric|\bev\b/.test(raw)) return "Electric";
    if (/diesel|tdi|duramax|cummins|ecodiesel/.test(raw)) return "Diesel";
    if (/gas|gasoline/.test(raw)) return "Gasoline";
    return sanitize(v?.fuel_type || v?.fuel || "");
  }
  function normalizeColor(v){
    const explicit = clean(v?.exterior_color || "");
    const generic = clean(v?.color || "");
    const title = clean(v?.title || "");
    const rawText = clean(v?.rawText || v?.raw_text || "");
    const source = lower([explicit, generic, title, rawText].filter(Boolean).join(" "));

    const extMatch = source.match(/(?:ext|exterior)\s*[:\-]?\s*([a-z ]+?)(?=(?:\s+int(?:erior)?\s*[:\-]?)|$)/i);
    let working = extMatch?.[1] ? lower(extMatch[1]) : source;
    working = working.replace(/(?:int|interior)\s*[:\-]?.*$/i, " ").trim();

    if (/^(?:int|interior)/.test(lower(explicit)) && !extMatch) return "";
    if (/^(?:int|interior)/.test(lower(generic)) && !extMatch) return "";

    const map = [["black","Black"],["white","White"],["silver","Silver"],["grey","Grey"],["gray","Grey"],["blue","Blue"],["red","Red"],["green","Green"],["brown","Brown"],["orange","Orange"],["yellow","Yellow"],["gold","Gold"],["beige","Beige"]];
    for (const [k,val] of map) if (working.includes(k)) return val;

    const fallback = sanitize(explicit || generic || "");
    if (/^(?:int|interior)/i.test(fallback)) return "";
    return fallback;
  }
  function normalizeLocation(v){
    for (const item of [v?.listing_location, v?.location, v?.profile?.listing_location]) {
      const s = sanitize(item);
      if (s) return s;
    }
    return "";
  }
  function normalizeVehicle(vehicle = {}){
    const out = { ...(vehicle || {}) };
    const source = src(out);
    out.vin = sanitize(out.vin || "").toUpperCase();
    out.stock = sanitize(out.stock || out.stock_number || out.stockNumber || "");
    out.year = sanitize(out.year || extractYear(source));
    out.make = sanitize(out.make || extractMake(source));
    const split = splitModelTrim({ ...out, title: out.title || source });
    out.model = sanitize(out.model || split.model);
    out.trim = sanitize(out.trim || split.trim);
    out.price = Number(out.price || out.list_price || out.asking_price || digits(out.price || "")) || "";
    out.km = Number(out.km || out.kilometers || out.mileage || digits(out.km || "")) || "";
    out.body_style = normalizeBody(out);
    out.fuel_type = normalizeFuel(out);
    out.exterior_color = normalizeColor(out);
    out.listing_location = normalizeLocation(out);
    out.location = out.listing_location;
    out.vehicle_type = sanitize(out.vehicle_type || out.specs?.vehicle_type || "") || "Car/Truck";
    out.title = sanitize([out.year, out.make, out.model, out.trim].filter(Boolean).join(" "));
    out.rawText = sanitize(out.rawText || out.raw_text || source);
    out.source_url = clean(out.source_url || out.sourceUrl || "");
    out.specs = { ...(out.specs || {}), body: out.body_style, fuel: out.fuel_type, exterior_color: out.exterior_color, vehicle_type: out.vehicle_type };
    return out;
  }
  window.ElevateVehicleNormalizer = { normalizeVehicle };
})();
