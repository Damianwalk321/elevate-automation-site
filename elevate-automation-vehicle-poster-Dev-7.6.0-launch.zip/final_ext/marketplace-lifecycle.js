// marketplace-lifecycle.js
// Elevate Automation Marketplace Lifecycle Engine V1 SAFE
// Manual-review lifecycle tracking only. No destructive auto-actions.

(function () {
  const STORAGE = {
    POSTED: "ea_posted",
    SNAPSHOT: "ea_inventory_snapshot",
    LISTINGS: "ea_marketplace_listings",
    REVIEW: "ea_marketplace_review_queue",
    HISTORY: "ea_marketplace_lifecycle_history"
  };

  function log(...a) {
    console.log("[Elevate Lifecycle V1 SAFE]", ...a);
  }

  function now() {
    return new Date().toISOString();
  }

  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function digitsOnly(v) {
    return String(v || "").replace(/[^\d]/g, "");
  }

  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(key, (data) => resolve(data?.[key]));
      } catch {
        resolve(null);
      }
    });
  }

  function storageSet(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, resolve);
      } catch {
        resolve();
      }
    });
  }

  function fingerprint(v) {
    if (!v) return "";

    const vin = clean(v.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(v.stock || v.stock_number || "").toUpperCase();
    if (stock) return `STOCK:${stock}`;

    return [
      clean(v.year || "").toUpperCase(),
      clean(v.make || "").toUpperCase(),
      clean(v.model || "").toUpperCase(),
      digitsOnly(v.price || ""),
      digitsOnly(v.kilometers || v.km || v.mileage || "")
    ].join("|");
  }

  async function getSnapshot() {
    return (await storageGet(STORAGE.SNAPSHOT)) || {};
  }

  async function getPosted() {
    return (await storageGet(STORAGE.POSTED)) || {};
  }

  async function getListings() {
    return (await storageGet(STORAGE.LISTINGS)) || {};
  }

  async function getReviewQueue() {
    return (await storageGet(STORAGE.REVIEW)) || {
      newVehicles: [],
      removedVehicles: [],
      priceChanges: [],
      updatedAt: null
    };
  }

  async function getHistory() {
    return (await storageGet(STORAGE.HISTORY)) || [];
  }

  async function setListings(data) {
    await storageSet({ [STORAGE.LISTINGS]: data || {} });
  }

  async function setReviewQueue(data) {
    await storageSet({
      [STORAGE.REVIEW]: {
        newVehicles: Array.isArray(data?.newVehicles) ? data.newVehicles : [],
        removedVehicles: Array.isArray(data?.removedVehicles) ? data.removedVehicles : [],
        priceChanges: Array.isArray(data?.priceChanges) ? data.priceChanges : [],
        updatedAt: now()
      }
    });
  }

  async function appendHistory(entry) {
    const history = await getHistory();
    history.unshift({
      ...entry,
      timestamp: now()
    });
    await storageSet({
      [STORAGE.HISTORY]: history.slice(0, 250)
    });
  }

  function normalizePostedMap(posted) {
    if (Array.isArray(posted)) {
      const map = {};
      for (const item of posted) {
        const key = fingerprint(item);
        if (!key) continue;
        map[key] = item;
      }
      return map;
    }

    if (posted && typeof posted === "object") {
      return posted;
    }

    return {};
  }

  function normalizeListingsMap(listings) {
    if (Array.isArray(listings)) {
      const map = {};
      for (const item of listings) {
        const key = fingerprint(item?.vehicle || item);
        if (!key) continue;
        map[key] = item?.vehicle ? item : { id: key, vehicle: item };
      }
      return map;
    }

    if (listings && typeof listings === "object") {
      return listings;
    }

    return {};
  }

  function normalizeSnapshotMap(snapshot) {
    if (Array.isArray(snapshot)) {
      const map = {};
      for (const item of snapshot) {
        const key = fingerprint(item);
        if (!key) continue;
        map[key] = item;
      }
      return map;
    }

    if (snapshot && typeof snapshot === "object") {
      return snapshot;
    }

    return {};
  }

  async function detectNewVehicles(snapshot, posted) {
    const newVehicles = [];

    Object.values(snapshot).forEach((vehicle) => {
      const key = fingerprint(vehicle);
      if (!key) return;

      if (!posted[key]) {
        newVehicles.push({
          key,
          vehicle,
          status: "review_new",
          detectedAt: now()
        });
      }
    });

    return newVehicles;
  }

  async function detectRemovedVehicles(snapshot, listings) {
    const removed = [];

    Object.values(listings).forEach((listing) => {
      const vehicle = listing?.vehicle || null;
      const key = fingerprint(vehicle);
      if (!key) return;

      if (!snapshot[key]) {
        removed.push({
          key,
          listingId: listing?.id || key,
          vehicle,
          status: "review_delete",
          lifecycle_status: "stale",
          detectedAt: now()
        });
      }
    });

    return removed;
  }

  async function detectPriceChanges(snapshot, listings) {
    const updates = [];

    Object.values(listings).forEach((listing) => {
      const vehicle = listing?.vehicle || null;
      const key = fingerprint(vehicle);
      if (!key) return;

      const current = snapshot[key];
      if (!current) return;

      const oldPrice = digitsOnly(vehicle?.price || "");
      const newPrice = digitsOnly(current?.price || "");

      if (oldPrice && newPrice && oldPrice !== newPrice) {
        updates.push({
          key,
          listingId: listing?.id || key,
          vehicle,
          oldPrice,
          newPrice,
          status: "review_price_update",
          detectedAt: now()
        });
      }
    });

    return updates;
  }

  async function buildLifecycleState() {
    const rawSnapshot = await getSnapshot();
    const rawPosted = await getPosted();
    const rawListings = await getListings();

    const snapshot = normalizeSnapshotMap(rawSnapshot);
    const posted = normalizePostedMap(rawPosted);
    const listings = normalizeListingsMap(rawListings);

    const newVehicles = await detectNewVehicles(snapshot, posted);
    const removedVehicles = await detectRemovedVehicles(snapshot, listings);
    const priceChanges = await detectPriceChanges(snapshot, listings);

    return {
      snapshot,
      posted,
      listings,
      newVehicles,
      removedVehicles,
      priceChanges
    };
  }

  async function syncListingsRegistryFromSnapshot() {
    const rawSnapshot = await getSnapshot();
    const snapshot = normalizeSnapshotMap(rawSnapshot);
    const currentListings = normalizeListingsMap(await getListings());

    const nextListings = { ...currentListings };

    Object.values(snapshot).forEach((vehicle) => {
      const key = fingerprint(vehicle);
      if (!key) return;

      if (!nextListings[key]) {
        nextListings[key] = {
          id: key,
          vehicle,
          lifecycle_status: "tracked",
          createdAt: now(),
          updatedAt: now()
        };
      } else {
        nextListings[key] = {
          ...nextListings[key],
          vehicle,
          updatedAt: now()
        };
      }
    });

    await setListings(nextListings);
    return nextListings;
  }

  async function runLifecycle() {
    const lifecycle = await buildLifecycleState();

    log("new vehicles", lifecycle.newVehicles.length);
    log("removed vehicles", lifecycle.removedVehicles.length);
    log("price changes", lifecycle.priceChanges.length);

    const reviewQueue = {
      newVehicles: lifecycle.newVehicles,
      removedVehicles: lifecycle.removedVehicles,
      priceChanges: lifecycle.priceChanges
    };

    await setReviewQueue(reviewQueue);

    await appendHistory({
      type: "lifecycle_run",
      counts: {
        newVehicles: lifecycle.newVehicles.length,
        removedVehicles: lifecycle.removedVehicles.length,
        priceChanges: lifecycle.priceChanges.length
      }
    });

    return {
      ok: true,
      counts: {
        newVehicles: lifecycle.newVehicles.length,
        removedVehicles: lifecycle.removedVehicles.length,
        priceChanges: lifecycle.priceChanges.length
      },
      reviewQueue
    };
  }

  async function markReviewItemResolved(bucket, key) {
    const queue = await getReviewQueue();
    if (!queue[bucket] || !Array.isArray(queue[bucket])) {
      return { ok: false, error: "invalid_bucket" };
    }

    queue[bucket] = queue[bucket].filter((item) => item?.key !== key);
    await setReviewQueue(queue);

    await appendHistory({
      type: "review_resolved",
      bucket,
      key
    });

    return { ok: true };
  }

  async function getLifecycleSummary() {
    const queue = await getReviewQueue();
    return {
      ok: true,
      counts: {
        newVehicles: Array.isArray(queue.newVehicles) ? queue.newVehicles.length : 0,
        removedVehicles: Array.isArray(queue.removedVehicles) ? queue.removedVehicles.length : 0,
        priceChanges: Array.isArray(queue.priceChanges) ? queue.priceChanges.length : 0
      },
      reviewQueue: queue
    };
  }

  window.ElevateLifecycle = {
    runLifecycle,
    getLifecycleSummary,
    markReviewItemResolved,
    syncListingsRegistryFromSnapshot
  };
})();
