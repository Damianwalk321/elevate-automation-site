// extension-session.js
// Elevate Automation Session Bridge V8.3
// Dealer-page safe session recovery + strict posting state enforcement

(function () {
  const SESSION_CACHE_KEY = "ea_extension_session_cache";
  const LEGACY_SESSION_KEY = "ea_extension_session";
  const LAST_EMAIL_KEY = "ea_last_email";
  const SESSION_TTL_MS = 1000 * 60 * 10;

  const POSTING_STATE_KEY = "ea_posting_state";
  const POSTING_INFLIGHT_KEY = "ea_posting_inflight";
  const POSTING_INFLIGHT_TTL_MS = 1000 * 60 * 5;

  function log(...args) {
    console.log("[Elevate Session]", ...args);
  }

  function warn(...args) {
    console.warn("[Elevate Session]", ...args);
  }

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function normalizeEmail(value) {
    return clean(value).toLowerCase();
  }

  function now() {
    return Date.now();
  }

  function safeHostname(input) {
    try {
      return new URL(input).hostname.replace(/^www\./, "").toLowerCase();
    } catch {
      return clean(input)
        .replace(/^https?:\/\//i, "")
        .replace(/^www\./i, "")
        .split("/")[0]
        .toLowerCase();
    }
  }

  function lower(value) {
    return clean(value).toLowerCase();
  }

  function fallbackPostingLimit(plan) {
    const raw = lower(plan);
    if (raw.includes("pro")) return 25;
    return 5;
  }

  function compareVersions(a, b) {
    const pa = String(a || "0.0.0").split(".").map((x) => Number(x) || 0);
    const pb = String(b || "0.0.0").split(".").map((x) => Number(x) || 0);
    const len = Math.max(pa.length, pb.length);

    for (let i = 0; i < len; i += 1) {
      const av = pa[i] || 0;
      const bv = pb[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }

    return 0;
  }

  function getCurrentExtensionVersion() {
    try {
      return chrome.runtime?.getManifest?.()?.version || "0.0.0";
    } catch {
      return "0.0.0";
    }
  }

  function resolvePostingLimit(subscription = {}, fallbackPlan = "") {
    const direct = normalizeFiniteNumber(
      subscription?.posting_limit ?? subscription?.daily_limit ?? subscription?.limit,
      0
    );

    if (direct > 0) return direct;
    return fallbackPostingLimit(fallbackPlan || subscription?.plan || "starter");
  }

  function normalizeFiniteNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function startOfTodayLocal() {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }

  function normalizeSession(raw) {
    if (!raw) return null;
    const session = raw.session || raw;

    const normalized = {
      user: session.user || {},
      organization: session.organization || {},
      dealership: session.dealership || {},
      profile: session.profile || {},
      subscription: session.subscription || {},
      scanner_config: session.scanner_config || {},
      meta: session.meta || {}
    };

    const plan = clean(
      normalized.subscription?.plan ||
      session.plan ||
      "Founder Beta"
    );

    const postingLimit = resolvePostingLimit(normalized.subscription, plan);
    const postsToday = Math.max(0, normalizeFiniteNumber(normalized.subscription?.posts_today, 0));
    const minimumVersion = clean(
      normalized.subscription?.minimum_version ||
      session.minimum_version ||
      normalized.meta?.minimum_version ||
      ""
    );
    const latestVersion = clean(
      normalized.subscription?.latest_version ||
      session.latest_version ||
      normalized.meta?.latest_version ||
      minimumVersion ||
      getCurrentExtensionVersion()
    );
    const isActive = Boolean(
      normalized.subscription?.active ??
      (clean(normalized.subscription?.status || "").toLowerCase() === "active")
    );
    const updateRequired =
      normalized.subscription?.update_required === true ||
      (minimumVersion ? compareVersions(getCurrentExtensionVersion(), minimumVersion) < 0 : false);

    normalized.subscription = {
      ...normalized.subscription,
      plan,
      active: isActive,
      status: clean(normalized.subscription?.status || (isActive ? "active" : "inactive")).toLowerCase() || "inactive",
      posting_limit: postingLimit,
      posts_today: postsToday,
      posts_remaining: Math.max(postingLimit - postsToday, 0),
      minimum_version: minimumVersion,
      latest_version: latestVersion,
      update_required: updateRequired,
      allowed_dealer_hosts: Array.isArray(normalized.subscription?.allowed_dealer_hosts)
        ? normalized.subscription.allowed_dealer_hosts.map((value) => safeHostname(value)).filter(Boolean)
        : []
    };

    normalized.meta = {
      ...(normalized.meta || {}),
      minimum_version: minimumVersion,
      latest_version: latestVersion,
      update_required: updateRequired
    };

    return normalized;
  }

  function buildProfileSnapshot(normalized) {
    return {
      full_name: clean(normalized?.profile?.full_name || normalized?.user?.full_name || normalized?.user?.name || ""),
      salesperson_name: clean(normalized?.profile?.full_name || normalized?.user?.full_name || normalized?.user?.name || ""),
      dealer_name: clean(normalized?.profile?.dealership || normalized?.profile?.dealer_name || normalized?.dealership?.name || ""),
      dealership: clean(normalized?.profile?.dealership || normalized?.profile?.dealer_name || normalized?.dealership?.name || ""),
      dealer_phone: clean(normalized?.profile?.dealer_phone || normalized?.dealership?.phone || ""),
      dealer_email: clean(normalized?.profile?.dealer_email || normalized?.dealership?.email || ""),
      phone: clean(normalized?.profile?.phone || normalized?.profile?.dealer_phone || normalized?.dealership?.phone || ""),
      email: clean(normalized?.profile?.email || normalized?.profile?.dealer_email || normalized?.dealership?.email || normalized?.user?.email || ""),
      province: clean(normalized?.profile?.province || normalized?.dealership?.province || ""),
      city: clean(normalized?.profile?.city || normalized?.dealership?.city || ""),
      listing_location: clean(normalized?.profile?.listing_location || normalized?.profile?.location || normalized?.dealership?.city || ""),
      location: clean(normalized?.profile?.listing_location || normalized?.profile?.location || normalized?.dealership?.city || ""),
      inventory_url: clean(normalized?.profile?.inventory_url || normalized?.dealership?.inventory_url || ""),
      dealer_site: clean(normalized?.profile?.dealer_website || normalized?.dealership?.website || ""),
      dealer_website: clean(normalized?.profile?.dealer_website || normalized?.dealership?.website || ""),
      scanner_type: clean(normalized?.scanner_config?.scanner_type || normalized?.dealership?.scanner_type || ""),
      compliance_signature: clean(normalized?.profile?.compliance_signature || "")
    };
  }

  function extractSessionPayload(response) {
    if (!response || typeof response !== "object") return null;
    const payload = response.session || response.data || response;
    return normalizeSession(payload);
  }

  async function storageGet(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, (result) => resolve(result || {}));
    });
  }

  async function storageSet(payload) {
    return new Promise((resolve) => {
      chrome.storage.local.set(payload, () => resolve(true));
    });
  }

  async function storageRemove(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.remove(keys, () => resolve(true));
    });
  }

  function runtimeSend(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            resolve({
              ok: false,
              error: runtimeError.message || "Runtime messaging failed"
            });
            return;
          }

          resolve(response || { ok: false, error: "No response" });
        });
      } catch (error) {
        resolve({
          ok: false,
          error: error?.message || "Runtime send failed"
        });
      }
    });
  }

  function extractEmailFromPageText() {
    try {
      const text = document.body?.innerText || "";
      const match = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
      return normalizeEmail(match?.[0] || "");
    } catch {
      return "";
    }
  }

  async function rememberEmail(email) {
    const normalized = normalizeEmail(email);
    if (!normalized) return;
    await storageSet({ [LAST_EMAIL_KEY]: normalized });
  }

  async function getStoredEmail() {
    const data = await storageGet([LAST_EMAIL_KEY]);
    return normalizeEmail(data?.[LAST_EMAIL_KEY] || "");
  }

  async function getCachedSession() {
    const data = await storageGet([
      SESSION_CACHE_KEY,
      LEGACY_SESSION_KEY,
      "elevate_session_snapshot",
      "ea_extension_session"
    ]);
    const cache = data?.[SESSION_CACHE_KEY];
    const legacy = data?.[LEGACY_SESSION_KEY] || null;
    const elevateSnapshot = data?.elevate_session_snapshot || null;
    const extensionSession = data?.ea_extension_session || null;

    if (cache?.data && cache?.fetchedAt && now() - cache.fetchedAt < SESSION_TTL_MS) {
      return normalizeSession(cache.data);
    }

    if (legacy) {
      return normalizeSession(legacy);
    }

    if (extensionSession) {
      return normalizeSession(extensionSession);
    }

    if (elevateSnapshot) {
      return normalizeSession(elevateSnapshot);
    }

    const workerState = await runtimeSend({ type: "EA_GET_EXTENSION_STATE" });
    const workerSession = extractSessionPayload(workerState);
    if (workerSession) {
      return workerSession;
    }

    return null;
  }

  async function syncPostingStateIntoStorage(session) {
    const normalized = normalizeSession(session);
    const plan = clean(normalized?.subscription?.plan || "Founder Beta");
    const postingLimit = resolvePostingLimit(normalized?.subscription || {}, plan);

    const postsToday = Math.max(
      0,
      normalizeFiniteNumber(normalized?.subscription?.posts_today, 0)
    );

    const postingState = {
      plan,
      posting_limit: postingLimit,
      posts_today: postsToday,
      posts_remaining: Math.max(postingLimit - postsToday, 0),
      updated_at: now(),
      reset_at: startOfTodayLocal()
    };

    await storageSet({
      [POSTING_STATE_KEY]: postingState,
      elevate_posts_today: postingState.posts_today,
      elevate_posting_limit: postingState.posting_limit,
      elevate_extension_usage_snapshot: {
        posts_today: postingState.posts_today,
        posting_limit: postingState.posting_limit,
        posts_remaining: postingState.posts_remaining
      }
    });

    return postingState;
  }

  async function setCachedSession(session) {
    const normalized = normalizeSession(session);
    const profileSnapshot = buildProfileSnapshot(normalized);

    await storageSet({
      [SESSION_CACHE_KEY]: {
        fetchedAt: now(),
        data: normalized
      },
      [LEGACY_SESSION_KEY]: normalized,
      ea_extension_session: normalized,
      elevate_session_snapshot: normalized,
      elevate_profile_snapshot: profileSnapshot,
      ea_profile_snapshot: profileSnapshot,
      ea_dashboard_profile_v1: profileSnapshot
    });

    await syncPostingStateIntoStorage(normalized);

    try {
      await runtimeSend({
        type: "SET_EXTENSION_SESSION",
        session: normalized
      });
    } catch {}

    window.__EA_EXTENSION_SESSION = normalized;
    window.__EA_PROFILE = profileSnapshot;

    return normalized;
  }

  async function fetchSessionByEmail(email) {
    const normalized = normalizeEmail(email);
    if (!normalized) {
      return { success: false, error: "Missing email" };
    }

    const response = await runtimeSend({
      type: "EA_FETCH_EXTENSION_STATE",
      email: normalized,
      hostname: safeHostname(window.location.href),
      pageUrl: window.location.href
    });

    const session = extractSessionPayload(response);

    if (!session) {
      return {
        success: false,
        error: response?.error || "Failed to fetch extension state"
      };
    }

    const saved = await setCachedSession(session);
    return {
      success: true,
      data: saved
    };
  }

  async function getPossibleEmail() {
    const stored = await getStoredEmail();
    if (stored) return stored;

    const page = extractEmailFromPageText();
    if (page) {
      await rememberEmail(page);
      return page;
    }

    const cached = await getCachedSession();
    if (cached?.user?.email) {
      await rememberEmail(cached.user.email);
      return cached.user.email;
    }

    return "";
  }

  async function getExtensionState() {
    const workerState = await runtimeSend({ type: "EA_GET_EXTENSION_STATE" });
    const workerSession = extractSessionPayload(workerState);
    if (workerSession) {
      const saved = await setCachedSession(workerSession);
      return {
        success: true,
        data: saved
      };
    }

    const cached = await getCachedSession();
    if (cached) {
      window.__EA_EXTENSION_SESSION = cached;
      window.__EA_PROFILE = buildProfileSnapshot(cached);
      await syncPostingStateIntoStorage(cached);
      return {
        success: true,
        data: cached
      };
    }

    const email = await getPossibleEmail();
    if (!email) {
      return {
        success: false,
        error: "No email/session found"
      };
    }

    return fetchSessionByEmail(email);
  }

  async function refreshExtensionState() {
    const workerState = await runtimeSend({
      type: "EA_FETCH_EXTENSION_STATE",
      hostname: safeHostname(window.location.href),
      pageUrl: window.location.href
    });

    const workerSession = extractSessionPayload(workerState);
    if (workerSession) {
      const saved = await setCachedSession(workerSession);
      return {
        success: true,
        data: saved
      };
    }

    let email = await getStoredEmail();

    if (!email) {
      const cached = await getCachedSession();
      if (cached?.user?.email) {
        email = cached.user.email;
      }
    }

    if (!email) {
      email = extractEmailFromPageText();
    }

    if (!email) {
      return {
        success: false,
        error: "No email/session found"
      };
    }

    await rememberEmail(email);
    return fetchSessionByEmail(email);
  }

  async function applyDashboardProfileSync(payload) {
    const existing = (await getCachedSession()) || {};

    const merged = {
      ...existing,
      user: {
        ...(existing.user || {}),
        email: normalizeEmail(
          payload?.user?.email ||
          payload?.email ||
          existing?.user?.email ||
          ""
        )
      },
      organization: {
        ...(existing.organization || {}),
        ...(payload?.organization || {})
      },
      dealership: {
        ...(existing.dealership || {}),
        ...(payload?.dealership || {}),
        website: clean(
          payload?.dealership?.website ||
          payload?.dealer_site ||
          existing?.dealership?.website ||
          ""
        ),
        inventory_url: clean(
          payload?.dealership?.inventory_url ||
          payload?.inventory_url ||
          existing?.dealership?.inventory_url ||
          ""
        ),
        scanner_type: clean(
          payload?.dealership?.scanner_type ||
          payload?.scanner_type ||
          existing?.dealership?.scanner_type ||
          "generic"
        )
      },
      profile: {
        ...(existing.profile || {}),
        ...(payload?.profile || payload || {})
      },
      subscription: {
        ...(existing.subscription || {}),
        ...(payload?.subscription || {}),
        active:
          payload?.subscription?.active ??
          payload?.active ??
          existing?.subscription?.active ??
          false,
        status:
          payload?.subscription?.status ||
          payload?.status ||
          existing?.subscription?.status ||
          "inactive",
        plan:
          payload?.subscription?.plan ||
          payload?.plan ||
          existing?.subscription?.plan ||
          "Founder Beta",
        posting_limit:
          Number(payload?.subscription?.posting_limit ?? payload?.posting_limit ?? existing?.subscription?.posting_limit ?? 0),
        posts_today:
          Number(payload?.subscription?.posts_today ?? payload?.posts_today ?? existing?.subscription?.posts_today ?? 0),
        posts_remaining:
          Number(payload?.subscription?.posts_remaining ?? payload?.posts_remaining ?? existing?.subscription?.posts_remaining ?? 0),
        license_key:
          clean(
            payload?.subscription?.license_key ||
            payload?.license_key ||
            existing?.subscription?.license_key ||
            ""
          )
      },
      scanner_config: {
        ...(existing.scanner_config || {}),
        ...(payload?.scanner_config || {}),
        scanner_type: clean(
          payload?.scanner_config?.scanner_type ||
          payload?.scanner_type ||
          existing?.scanner_config?.scanner_type ||
          existing?.dealership?.scanner_type ||
          "generic"
        )
      }
    };

    if (merged?.user?.email) {
      await rememberEmail(merged.user.email);
    }

    const saved = await setCachedSession(merged);
    log("Dashboard sync applied:", {
      user: saved?.user?.email,
      dealership: saved?.dealership?.name,
      scanner: saved?.scanner_config?.scanner_type
    });

    return saved;
  }

  function doesCurrentPageMatchDealer(session, pageUrl = window.location.href) {
    const dealership = session?.dealership || {};
    const current = safeHostname(pageUrl);
    const websiteHost = safeHostname(dealership.website || "");
    const inventoryHost = safeHostname(dealership.inventory_url || "");

    if (!current) return false;
    if (!websiteHost && !inventoryHost) return true;

    return (
      (websiteHost &&
        (current === websiteHost ||
          current.endsWith(`.${websiteHost}`) ||
          websiteHost.endsWith(`.${current}`))) ||
      (inventoryHost &&
        (current === inventoryHost ||
          current.endsWith(`.${inventoryHost}`) ||
          inventoryHost.endsWith(`.${current}`)))
    );
  }

  function getPostingLocation(session) {
    const profile = session?.profile || {};
    const dealership = session?.dealership || {};

    const direct = clean(profile.listing_location || "");
    if (direct) return direct;

    const city = clean(profile.city || dealership.city || "");
    const province = clean(profile.province || dealership.province || "");

    if (city && province) return `${city}, ${province}`;
    return city || "";
  }

  async function getRawPostingState() {
    const data = await storageGet([POSTING_STATE_KEY]);
    return data?.[POSTING_STATE_KEY] || null;
  }

  async function setRawPostingState(state) {
    const safe = {
      plan: clean(state?.plan || "Founder Beta"),
      posting_limit: Math.max(0, normalizeFiniteNumber(state?.posting_limit, 0)),
      posts_today: Math.max(0, normalizeFiniteNumber(state?.posts_today, 0)),
      posts_remaining: Math.max(0, normalizeFiniteNumber(state?.posts_remaining, 0)),
      updated_at: normalizeFiniteNumber(state?.updated_at, now()),
      reset_at: normalizeFiniteNumber(state?.reset_at, startOfTodayLocal())
    };

    await storageSet({
      [POSTING_STATE_KEY]: safe,
      elevate_posts_today: safe.posts_today,
      elevate_posting_limit: safe.posting_limit,
      elevate_extension_usage_snapshot: {
        posts_today: safe.posts_today,
        posting_limit: safe.posting_limit,
        posts_remaining: safe.posts_remaining
      }
    });

    return safe;
  }

  async function getPostingState() {
    const session = await getCachedSession();
    const plan = clean(session?.subscription?.plan || "Founder Beta");
    const postingLimit = resolvePostingLimit(session?.subscription || {}, plan);

    const raw = await getRawPostingState();
    const todayStart = startOfTodayLocal();

    let postsToday = 0;
    if (raw && raw.reset_at === todayStart) {
      postsToday = Math.max(0, normalizeFiniteNumber(raw.posts_today, 0));
    } else {
      postsToday = Math.max(0, normalizeFiniteNumber(session?.subscription?.posts_today, 0));
    }

    const postingState = {
      plan,
      posting_limit: postingLimit,
      posts_today: postsToday,
      posts_remaining: Math.max(postingLimit - postsToday, 0),
      updated_at: now(),
      reset_at: todayStart
    };

    await setRawPostingState(postingState);

    if (session) {
      session.subscription = {
        ...(session.subscription || {}),
        plan: postingState.plan,
        posting_limit: postingState.posting_limit,
        posts_today: postingState.posts_today,
        posts_remaining: postingState.posts_remaining
      };
      await setCachedSession(session);
    }

    return postingState;
  }

  async function getRawInflightPost() {
    const data = await storageGet([POSTING_INFLIGHT_KEY]);
    return data?.[POSTING_INFLIGHT_KEY] || null;
  }

  async function getInflightPost() {
    const inflight = await getRawInflightPost();
    if (!inflight) return null;

    const startedAt = normalizeFiniteNumber(inflight.started_at, 0);
    if (!startedAt || now() - startedAt > POSTING_INFLIGHT_TTL_MS) {
      await clearInflightPost();
      return null;
    }

    return inflight;
  }

  async function setInflightPost(vehicleKey, meta = {}) {
    const key = clean(vehicleKey);
    if (!key) {
      return { success: false, error: "Missing vehicle key" };
    }

    const existing = await getInflightPost();
    if (existing && existing.vehicle_key === key) {
      return {
        success: false,
        error: "Vehicle already inflight",
        data: existing
      };
    }

    if (existing && existing.vehicle_key !== key) {
      return {
        success: false,
        error: "Another vehicle is already inflight",
        data: existing
      };
    }

    const payload = {
      vehicle_key: key,
      started_at: now(),
      page_url: window.location.href,
      meta: meta || {}
    };

    await storageSet({
      [POSTING_INFLIGHT_KEY]: payload
    });

    return {
      success: true,
      data: payload
    };
  }

  async function clearInflightPost(vehicleKey = "") {
    const current = await getRawInflightPost();
    if (!current) {
      await storageRemove([POSTING_INFLIGHT_KEY]);
      return { success: true };
    }

    const wanted = clean(vehicleKey);
    if (wanted && clean(current.vehicle_key) !== wanted) {
      return {
        success: false,
        error: "Inflight vehicle mismatch",
        data: current
      };
    }

    await storageRemove([POSTING_INFLIGHT_KEY]);
    return { success: true };
  }

  async function canUserPostNow(vehicleKey = "") {
    const postingState = await getPostingState();
    const currentInflight = await getInflightPost();
    const wantedKey = clean(vehicleKey);
    const session = await getCachedSession();

    if (currentInflight) {
      if (!wantedKey || currentInflight.vehicle_key === wantedKey) {
        return {
          success: true,
          allowed: false,
          reason: "Vehicle already inflight",
          state: postingState,
          inflight: currentInflight
        };
      }

      return {
        success: true,
        allowed: false,
        reason: "Another vehicle is already inflight",
        state: postingState,
        inflight: currentInflight
      };
    }

    if (session?.subscription?.active === false) {
      return {
        success: true,
        allowed: false,
        reason: "Subscription inactive",
        state: postingState,
        inflight: null
      };
    }

    if (session?.subscription?.update_required) {
      return {
        success: true,
        allowed: false,
        reason: `Update required (${session.subscription.latest_version || session.subscription.minimum_version || "latest"})`,
        state: postingState,
        inflight: null
      };
    }

    if (postingState.posts_today >= postingState.posting_limit) {
      return {
        success: true,
        allowed: false,
        reason: `Daily posting limit reached (${postingState.posting_limit})`,
        state: postingState,
        inflight: null
      };
    }

    return {
      success: true,
      allowed: true,
      reason: "",
      state: postingState,
      inflight: null
    };
  }

  async function registerSuccessfulPost(vehicleKey = "") {
    const key = clean(vehicleKey);
    if (!key) {
      return {
        success: false,
        error: "Missing vehicle key"
      };
    }

    const inflight = await getInflightPost();
    if (inflight && inflight.vehicle_key !== key) {
      return {
        success: false,
        error: "Inflight vehicle mismatch",
        data: inflight
      };
    }

    const postingState = await getPostingState();

    if (postingState.posts_today >= postingState.posting_limit) {
      await clearInflightPost(key);
      return {
        success: false,
        error: `Daily posting limit reached (${postingState.posting_limit})`,
        state: postingState
      };
    }

    const nextState = {
      ...postingState,
      posts_today: postingState.posts_today + 1,
      posts_remaining: Math.max(postingState.posting_limit - (postingState.posts_today + 1), 0),
      updated_at: now(),
      reset_at: startOfTodayLocal()
    };

    await setRawPostingState(nextState);

    const session = await getCachedSession();
    if (session) {
      session.subscription = {
        ...(session.subscription || {}),
        plan: clean(session.subscription?.plan || nextState.plan),
        posting_limit: nextState.posting_limit,
        posts_today: nextState.posts_today,
        posts_remaining: nextState.posts_remaining
      };
      await setCachedSession(session);
    }

    await clearInflightPost(key);

    return {
      success: true,
      state: nextState
    };
  }

  function listenForDashboardProfileSync() {
    window.addEventListener("message", async (event) => {
      const data = event?.data;
      if (!data || data.type !== "ELEVATE_PROFILE_SYNC") return;

      try {
        await applyDashboardProfileSync(data.payload || {});
      } catch (error) {
        warn("Dashboard sync event failed:", error?.message || error);
      }
    });
  }

  window.ElevateExtensionSession = {
    getExtensionState,
    refreshExtensionState,
    applyDashboardProfileSync,
    doesCurrentPageMatchDealer,
    getPostingLocation,
    getPostingState,
    canUserPostNow,
    registerSuccessfulPost,
    getInflightPost,
    setInflightPost,
    clearInflightPost,
    clearSessionCache: async () => {
      await storageRemove([
        SESSION_CACHE_KEY,
        LEGACY_SESSION_KEY,
        POSTING_STATE_KEY,
        POSTING_INFLIGHT_KEY,
        "ea_extension_session",
        "elevate_session_snapshot",
        "elevate_profile_snapshot",
        "ea_profile_snapshot",
        "ea_dashboard_profile_v1"
      ]);
      window.__EA_EXTENSION_SESSION = null;
      window.__EA_PROFILE = null;
      return { success: true };
    }
  };

  listenForDashboardProfileSync();

  setTimeout(async () => {
    try {
      const result = await getExtensionState();

      if (result?.success && result?.data) {
        await getPostingState();
        log("Session bootstrapped:", {
          user: result.data?.user?.email,
          organization: result.data?.organization?.name,
          dealership: result.data?.dealership?.name,
          scanner: result.data?.scanner_config?.scanner_type
        });
      } else {
        warn("Session bootstrap failed:", result?.error || "Unknown error");
      }
    } catch (error) {
      warn("Session bootstrap failed:", error?.message || error);
    }
  }, 100);
})();
