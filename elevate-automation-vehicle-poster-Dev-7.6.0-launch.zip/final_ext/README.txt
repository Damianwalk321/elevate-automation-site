INSTALLATION

1. Delete the current extension from chrome://extensions
2. Download and unzip this package
3. Open Chrome
4. Go to chrome://extensions
5. Turn on Developer Mode
6. Click Load unpacked
7. Select the unzipped folder that contains manifest.json

WHAT CHANGED IN V3.2.5

- Fuel Type is treated as a dropdown step
- Kilometers copy/fill uses number-only format everywhere in the assistant
- Auto-fill now runs automatically when a new vehicle is loaded after Post / Next Queue
- The helper refreshes from saved vehicle state after page reload
- Better verification/retry behavior for Kilometers

MAP ORDER

Vehicle Type
Year
Make
Location
Model
Kilometers
Price
Body Style
Exterior Colour
Fuel Type
Description

V3.2.5.14 PATCH
- Built on restored stable branch
- Mileage uses keyboard-style sequence targeting the left pane after model
- Price behavior left unchanged from restored stable branch
- Auto Type Mileage button added
- Grey normalizes to gray
- Fuel type matches Facebook labels

V3.2.5.15 PATCH
- Copy Kilometers now uses clipboard fallback
- Mileage auto typing now tries the third left-pane input first, then retries across left-pane text inputs
- Built on the stable keyboard mileage sequence branch

V3.2.5.16 PATCH
- Copy Kilometers now resolves raw KM from multiple vehicle fields
- Shows 'No kilometers found' if source data is empty
- Added Show Kilometers button for quick validation

V3.2.5.17 PATCH
- Mileage typing no longer targets Location or Price fields
- Mileage candidate now excludes mapped/likely Location and Price inputs
- Built on the copy-KM hard-fix branch

V3.2.5.18 PATCH
- Auto Mileage is now integrated directly into Auto Fill Sequential Order
- Mileage still avoids Location and Price fields
- Manual Auto Mileage button remains available as fallback

V3.2.5.19 PATCH
- Auto Fill Sequential Order now uses the same working mileage path as the Auto Mileage button
- Added a small timing delay before mileage in the main flow
- Keeps manual Auto Mileage button as fallback

V3.2.5.20 PATCH
- Main autofill now triggers mileage immediately after Model using the same working Auto Mileage path
- Kilometers step is skipped once mileage is handled

V3.2.5.21 PATCH
- Reordered sequence to: Vehicle Type, Location, Year, Make, Model, Mileage, Price, Body Style, Exterior Colour, Fuel Type, Description
- Mileage label updated in the helper UI

V3.2.5.22 PATCH
- Mileage is now a hard-required step
- Auto Fill Sequential Order stops immediately if mileage cannot be filled
- Uses the same Auto Mileage path inside the main flow

V3.2.5.23 PATCH
- Mileage failure now hard-stops the sequence
- Price verification checks the actual field value to prevent false 'skipped Price' reports

V3.2.5.24 PATCH
- Auto Fill Sequential Order and Auto Mileage now call the exact same mileage action
- Sequence continues only if that shared mileage action succeeds

V3.2.5.25 PATCH
- Fixed a JavaScript syntax error in the shared mileage action
- Restores the Auto Poster Assistant panel on Post
- Keeps the current workflow pattern intact

V3.2.5.26 PATCH
- Auto Mileage button now uses the same success verification as the working main autofill mileage path
- Fixes false 'Mileage field not found' message when mileage actually fills

V3.2.5.27 PATCH
- Sequential mileage step now uses the exact same shared mileage success path as the working assistant action
- Removes the split success/failure reporting between sequential autofill and the mileage action button

V3.2.5.28 PATCH
- Sequential mileage status now waits and re-checks visible fields before reporting failure
- Fixes false 'Mileage field not found' after mileage actually fills

V3.2.5.29 PATCH
- Sequential autofill now trusts the working mileage action
- Removes the repeated false-negative mileage status behavior

V3.2.5.30 PATCH
- Auto Fill Sequential Order now invokes the exact same Auto Mileage action as the working button
- Added blur/settle delay before mileage runs
- Mileage also triggers immediately after Model before Price

V4.0.0 FEATURE
- Added Inventory Scanner on dealer page
- Added Queue Preview panel
- Added Build Queue / Start Posting flow
- Rebranded to Elevate Automation – Vehicle Poster Assistant

V4.0.1 FIX
- Fixed Queue Selected callback scope bug

V4.0.2 FIX
- Fixed broken dealer-panel template syntax that was preventing inventory.js from running
- Restores card buttons and scanner panel
- Added Selected count tile

V4.1.0 FEATURE
- Added automatic first cover photo extraction from dealer card/detail page
- Added Upload Cover Photo button in Marketplace assistant
- Marketplace now auto-attempts cover photo upload on load

V4.1.1 FIX
- Cover photo upload now uses direct image blob fetch instead of data URL reconstruction
- Validates file size and upload MIME type before injecting into Facebook
- Fixes Facebook 'Can't Read Files' upload error for supported image files

V4.1.2 FIX
- Expanded host permissions so dealer/CDN image URLs can be fetched by the extension
- Improved background image fetch handling with redirects and clearer errors

V4.1.3 FIX
- Cover photo now fetches through the extension background, resizes to max 1600px, and compresses to JPEG before upload
- Designed to keep uploads under Facebook's 10 MB limit and avoid unreadable file errors
