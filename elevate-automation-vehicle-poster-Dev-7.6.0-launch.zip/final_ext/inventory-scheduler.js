// inventory-scheduler.js
// Elevate Automation Inventory Scheduler V18

const SCAN_INTERVAL = 15 * 60 * 1000

function log(...a){
console.log("[Elevate Scheduler]",...a)
}

function sleep(ms){
return new Promise(r=>setTimeout(r,ms))
}

function isInventoryPage(url){

url = url.toLowerCase()

return (
url.includes("inventory") ||
url.includes("vehicle") ||
url.includes("used") ||
url.includes("search")
)

}

async function findInventoryTab(){

return new Promise(resolve=>{

chrome.tabs.query({},tabs=>{

for(const tab of tabs){

if(isInventoryPage(tab.url)){
resolve(tab)
return
}

}

resolve(null)

})

})

}

async function triggerScan(tab){

chrome.tabs.sendMessage(tab.id,{
type:"EA_TRIGGER_SCAN"
})

log("scan triggered",tab.url)

}

async function schedulerLoop(){

while(true){

const tab = await findInventoryTab()

if(tab){

await triggerScan(tab)

}else{

log("no inventory tab open")

}

await sleep(SCAN_INTERVAL)

}

}

chrome.runtime.onInstalled.addListener(()=>{

log("scheduler installed")

schedulerLoop()

})

chrome.runtime.onStartup.addListener(()=>{

log("scheduler started")

schedulerLoop()

})