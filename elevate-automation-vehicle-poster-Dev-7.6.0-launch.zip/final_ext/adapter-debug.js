// adapter-debug.js
// Lightweight debug surface for adapter routing and health

(function () {
  const state = {
    lastRoute: null,
    lastCandidates: [],
    lastWinner: null,
    lastResult: null,
    lastFailure: null,
    updatedAt: 0
  };

  function set(partial = {}) {
    Object.assign(state, partial || {});
    state.updatedAt = Date.now();
    return getState();
  }

  function getState() {
    return JSON.parse(JSON.stringify(state));
  }

  function inspect() {
    return {
      state: getState(),
      domainProfile: window.ElevateAdapterIntelligence?.getDomainProfile?.(location.hostname) || null,
      logs: window.ElevateAdapterTelemetry?.getLogs?.(25) || []
    };
  }

  window.ElevateAdapterDebug = {
    set,
    getState,
    inspect,
    clear() {
      state.lastRoute = null;
      state.lastCandidates = [];
      state.lastWinner = null;
      state.lastResult = null;
      state.lastFailure = null;
      state.updatedAt = Date.now();
      return true;
    }
  };
})();
