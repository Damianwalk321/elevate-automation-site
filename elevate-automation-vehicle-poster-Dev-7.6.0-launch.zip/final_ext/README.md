# elevate-automation-vehicle-poster
Elevate Automation – Vehicle Poster Chrome extension for automating Facebook Marketplace vehicle listings from dealer inventory.
