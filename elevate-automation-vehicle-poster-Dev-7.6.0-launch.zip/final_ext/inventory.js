// inventory.js
// Elevate Automation Inventory V13.2 STRICT
// Fixes:
// 1) Hard-lock vehicle detail URLs through scan -> queue -> load -> posting
// 2) Prevents queue/current payloads from degrading into search.html
// 3) Strengthens dashboard profile hydration for salesperson + dealer
// 4) Preserves current scanner UI / queue / stale / Marketplace launch flow
// 5) Strict duplicate blocking / posting limits / compliance readiness before launch
// 6) Lifecycle sync triggers wired to worker

(function () {
  const LOG_PREFIX = "[Elevate Inventory V13.2 STRICT]";
  const PANEL_ID = "ea-inventory-panel-v13";

  const STORAGE_KEYS = {
    QUEUE: "ea_inventory_queue_v13",
    CURRENT: "ea_inventory_current_v13",
    LAST_SCAN: "ea_inventory_last_scan_v13",
    POSTED: "ea_inventory_posted_v13",
    STALE: "ea_inventory_stale_v13",
    REVIEW: "ea_inventory_review_v13",
    PROFILE_CACHE: "ea_profile_cache_v13"
  };

  const SEARCH_PAGE_PATTERNS = [
    /search\.html/i,
    /\/used\/search/i,
    /\/new\/search/i,
    /\/inventory\/?$/i,
    /\/inventory\?/i,
    /\/used-inventory/i,
    /\/new-inventory/i,
    /\/vehicles\?/i,
    /\/cars\?/i
  ];

  let isRendering = false;
  let isScanning = false;
  let currentScanResults = [];
  let currentSession = null;
  let workerPostedKeys = new Set();
  let lastStatusMessage = "Ready.";

  function log(...args) { console.log(LOG_PREFIX, ...args); }
  function warn(...args) { console.warn(LOG_PREFIX, ...args); }
  function clean(value) { return String(value || "").replace(/\s+/g, " ").trim(); }
  function lower(value) { return clean(value).toLowerCase(); }
  function digits(value) { return String(value || "").replace(/[^\d]/g, ""); }
  function money(value) { const n = Number(value); return Number.isFinite(n) && n > 0 ? `$${n.toLocaleString()}` : ""; }
  function km(value) { const n = Number(value); return Number.isFinite(n) && n >= 0 ? `${n.toLocaleString()} KM` : ""; }

  function escapeHtml(str) {
    return String(str || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function stripJunk(value) {
    return clean(String(value || "")
      .replace(/[\u{1F300}-\u{1FAFF}]/gu, " ")
      .replace(/[\u2600-\u27BF]/gu, " ")
      .replace(/[•◆■►▶✅❌✔️➡️📍🚗💰🛡️📞]/gu, " ")
      .replace(/[^\x20-\x7E\u00C0-\u024F]/g, " "));
  }

  function safeJsonParse(value, fallback) {
    try { return JSON.parse(value); } catch { return fallback; }
  }

  function readStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      return safeJsonParse(raw, fallback);
    } catch {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      warn("writeStorage failed:", key, error?.message || error);
    }
  }

  function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

  async function waitForBody(timeoutMs = 8000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (document.body) return document.body;
      await wait(50);
    }
    return null;
  }

  function getQueue() { return readStorage(STORAGE_KEYS.QUEUE, []); }
  function setQueue(queue) { writeStorage(STORAGE_KEYS.QUEUE, Array.isArray(queue) ? queue : []); }
  function getCurrentVehicle() { return readStorage(STORAGE_KEYS.CURRENT, null); }
  function setCurrentVehicle(vehicle) { writeStorage(STORAGE_KEYS.CURRENT, vehicle || null); }
  function getPostedVehicles() { return readStorage(STORAGE_KEYS.POSTED, []); }
  function setPostedVehicles(list) { writeStorage(STORAGE_KEYS.POSTED, Array.isArray(list) ? list : []); }
  function getStaleVehicles() { return readStorage(STORAGE_KEYS.STALE, []); }
  function setStaleVehicles(list) { writeStorage(STORAGE_KEYS.STALE, Array.isArray(list) ? list : []); }
  function getReviewItems() { return readStorage(STORAGE_KEYS.REVIEW, []); }
  function setReviewItems(list) { writeStorage(STORAGE_KEYS.REVIEW, Array.isArray(list) ? list : []); }
  function getProfileCache() { return readStorage(STORAGE_KEYS.PROFILE_CACHE, {}); }
  function setProfileCache(profile) { writeStorage(STORAGE_KEYS.PROFILE_CACHE, profile || {}); }

  function toAbsoluteUrl(url, base = window.location.href) {
    try {
      if (!clean(url)) return "";
      return new URL(url, base).href;
    } catch {
      return "";
    }
  }

  function isLikelySearchPageUrl(url) {
    const value = clean(url);
    if (!value) return true;
    return SEARCH_PAGE_PATTERNS.some((pattern) => pattern.test(value));
  }

  function looksLikeVehicleDetailUrl(url) {
    const value = clean(url);
    if (!value) return false;
    if (isLikelySearchPageUrl(value)) return false;
    return (
      /\/vehicle\//i.test(value) ||
      /\/used\/vehicle\//i.test(value) ||
      /\/new\/vehicle\//i.test(value) ||
      /\/vehicledetails\//i.test(value) ||
      /\/details\//i.test(value) ||
      /\/vdp\//i.test(value) ||
      /\/inventory\/[a-z0-9-]+/i.test(value) ||
      /-id\d+/i.test(value) ||
      /\/[0-9]{4}-[a-z0-9-]+/i.test(value)
    );
  }

  function getCurrentHost() {
    return clean(window.location.hostname || "").replace(/^www\./i, "").toLowerCase();
  }

  function getLinkedDealerHost(profileOverride = null, sessionOverride = null) {
    const profile = profileOverride || getProfileFromSession(sessionOverride || currentSession);
    const session = sessionOverride || currentSession || {};
    const dealership = session?.dealership || {};
    const candidates = [
      profile?.inventory_url,
      profile?.inventoryUrl,
      profile?.dealer_website,
      profile?.dealer_site,
      dealership?.inventory_url,
      dealership?.website
    ];

    for (const candidate of candidates) {
      const abs = toAbsoluteUrl(candidate || "");
      if (!abs) continue;
      try {
        return clean(new URL(abs).hostname).replace(/^www\./i, "").toLowerCase();
      } catch {}
    }

    return "";
  }

  function hostsMatch(currentHost, linkedHost) {
    const current = clean(currentHost).replace(/^www\./i, "").toLowerCase();
    const linked = clean(linkedHost).replace(/^www\./i, "").toLowerCase();

    if (!current || !linked) return false;
    if (current === linked) return true;
    if (current.endsWith(`.${linked}`)) return true;
    return false;
  }

  function firstNonEmpty(...values) {
    for (const value of values) {
      const v = clean(value);
      if (v) return v;
    }
    return "";
  }

  function getLockedDetailUrl(vehicle = {}) {
    const candidates = [
      vehicle.detail_url_locked,
      vehicle.detailUrlLocked,
      vehicle.detailUrl,
      vehicle.vdp_url,
      vehicle.vdpUrl,
      vehicle.vehicleUrl,
      vehicle.source_url,
      vehicle.sourceUrl,
      vehicle.link,
      vehicle.url
    ];

    for (const candidate of candidates) {
      const abs = toAbsoluteUrl(candidate);
      if (looksLikeVehicleDetailUrl(abs)) return abs;
    }

    return "";
  }

  function normalizeProfileShape(raw = {}) {
    const obj = raw || {};
    const dealership = obj.dealership || {};
    const profile = obj.profile || {};
    const user = obj.user || {};

    const full_name = firstNonEmpty(
      obj.full_name,
      obj.salesperson_name,
      obj.salesperson,
      obj.rep_name,
      obj.name,
      profile.full_name,
      profile.salesperson_name,
      profile.salesperson,
      user.full_name,
      user.name
    );

    const dealer_name = firstNonEmpty(
      obj.dealer_name,
      obj.dealership_name,
      obj.dealership,
      obj.dealer,
      obj.company_name,
      obj.store_name,
      profile.dealer_name,
      profile.dealership_name,
      profile.dealership,
      dealership.name,
      dealership.dealer_name,
      dealership.dealership_name
    );

    const listing_location = firstNonEmpty(
      obj.listing_location,
      obj.location,
      obj.city,
      profile.listing_location,
      profile.location,
      dealership.city
    );

    const province = firstNonEmpty(
      obj.province,
      profile.province,
      dealership.province
    );

    const phone = firstNonEmpty(
      obj.phone,
      obj.mobile,
      obj.dealer_phone,
      profile.phone,
      profile.mobile,
      profile.dealer_phone,
      dealership.phone
    );

    const dealer_phone = firstNonEmpty(
      obj.dealer_phone,
      obj.phone,
      profile.dealer_phone,
      dealership.phone
    );

    const email = firstNonEmpty(
      obj.email,
      obj.dealer_email,
      profile.email,
      profile.dealer_email,
      dealership.email
    );

    const dealer_email = firstNonEmpty(
      obj.dealer_email,
      obj.email,
      profile.dealer_email,
      dealership.email
    );

    const inventory_url = firstNonEmpty(
      obj.inventory_url,
      obj.inventoryUrl,
      profile.inventory_url,
      profile.inventoryUrl,
      dealership.inventory_url
    );

    const dealer_website = firstNonEmpty(
      obj.dealer_website,
      obj.dealer_site,
      obj.website,
      profile.dealer_website,
      dealership.website
    );

    const scanner_type = firstNonEmpty(
      obj.scanner_type,
      profile.scanner_type,
      obj.scanner,
      dealership.scanner_type
    );

    const city = firstNonEmpty(
      obj.city,
      profile.city,
      dealership.city,
      listing_location
    );

    const compliance_signature = firstNonEmpty(
      obj.compliance_signature,
      profile.compliance_signature
    );

    return {
      full_name,
      salesperson_name: full_name,
      dealer_name,
      dealership: dealer_name,
      dealer_phone,
      dealer_email,
      phone,
      email,
      listing_location,
      location: listing_location,
      city,
      province,
      inventory_url,
      dealer_website,
      compliance_signature,
      scanner_type
    };
  }

  async function runtimeMessage(payload) {
    return await new Promise((resolve) => {
      try {
        if (!chrome?.runtime?.sendMessage) return resolve(null);
        chrome.runtime.sendMessage(payload, (response) => resolve(response || null));
      } catch {
        resolve(null);
      }
    });
  }

  async function engineSaveQueue(queue) { return await runtimeMessage({ type: "SAVE_QUEUE", queue }); }
  async function engineSaveCurrentVehicle(vehicle, source = "inventory") { return await runtimeMessage({ type: "SAVE_CURRENT_VEHICLE", vehicle, source }); }
  async function engineSaveProfileSnapshot(profile) { return await runtimeMessage({ type: "SAVE_PROFILE_SNAPSHOT", profile }); }
  async function engineSyncInventory(snapshot) { return await runtimeMessage({ type: "EA_SYNC_INVENTORY", snapshot }); }
  async function engineGetPostedVehicles() { return await runtimeMessage({ type: "GET_POSTED_VEHICLES" }); }
  async function engineIsVehiclePosted(vehicle) { return await runtimeMessage({ type: "IS_VEHICLE_POSTED", vehicle }); }
  async function engineMarkVehiclePosted(vehicle) { return await runtimeMessage({ type: "MARK_VEHICLE_POSTED", vehicle }); }

  async function refreshWorkerPostedRegistry() {
    try {
      const res = await engineGetPostedVehicles();
      const list = Array.isArray(res?.postedVehicles)
        ? res.postedVehicles
        : (Array.isArray(res?.vehicles) ? res.vehicles : []);
      workerPostedKeys = new Set(list.map((item) => clean(item)).filter(Boolean));
      return workerPostedKeys;
    } catch {
      return workerPostedKeys;
    }
  }

  async function isPostedInWorker(vehicle) {
    try {
      const key = getVehicleKey(vehicle);
      if (!key) return false;
      if (workerPostedKeys.has(key)) return true;
      const res = await engineIsVehiclePosted(vehicle);
      const posted = Boolean(res?.posted);
      if (posted && res?.key) workerPostedKeys.add(clean(res.key));
      if (posted && key) workerPostedKeys.add(key);
      return posted;
    } catch {
      return false;
    }
  }

  function isPostedKnown(vehicle) {
    const key = getVehicleKey(vehicle);
    if (!key) return false;
    if (workerPostedKeys.has(key)) return true;
    return getPostedVehicles().some((item) => getVehicleKey(item) === key);
  }

  function getPostingLimit() {
    const plan = lower(currentSession?.subscription?.plan || currentSession?.plan || "");
    return plan.includes("pro") ? 25 : 5;
  }

  function getPostsToday() {
    const usage = readStorage("ea_extension_usage_snapshot", {});
    if (Number.isFinite(Number(usage?.posts_today))) return Number(usage.posts_today);

    const fromChrome = Number(localStorage.getItem("ea_posts_today") || "0");
    if (Number.isFinite(fromChrome)) return fromChrome;

    return 0;
  }

  function persistPostingUsageSnapshot(snapshot = {}) {
    const postingLimit = Number(snapshot.posting_limit || getPostingLimit() || 0) || 0;
    const postsToday = Number(snapshot.posts_today ?? getPostsToday() ?? 0) || 0;
    const usage = {
      posts_today: postsToday,
      posting_limit: postingLimit,
      posts_remaining: Math.max(postingLimit - postsToday, 0)
    };

    try {
      localStorage.setItem("ea_posts_today", String(usage.posts_today));
      localStorage.setItem("ea_posting_limit", String(usage.posting_limit));
      localStorage.setItem("ea_extension_usage_snapshot", JSON.stringify(usage));
    } catch {}

    try {
      chrome.storage.local.set({
        elevate_posts_today: usage.posts_today,
        elevate_posting_limit: usage.posting_limit,
        elevate_extension_usage_snapshot: usage,
        elevate_posted_vehicles: Array.from(workerPostedKeys)
      });
    } catch {}

    return usage;
  }

  function resetQueueState({ clearCurrent = true } = {}) {
    try {
      setQueue([]);
      writeStorage(STORAGE_KEYS.LAST_SCAN, []);
      currentScanResults = [];
      if (clearCurrent) {
        setCurrentVehicle(null);
        window.__EA_CURRENT_VEHICLE = null;
      }
      try {
        chrome.storage.local.set({
          elevate_vehicle_queue: [],
          vehicleQueue: [],
          elevate_current_vehicle: clearCurrent ? null : getCurrentVehicle()
        });
      } catch {}
    } catch (error) {
      warn("resetQueueState failed:", error?.message || error);
    }
  }

  async function triggerLifecycleSync(payload = {}) {
    try {
      const reviewItems = getReviewItems();
      const staleItems = getStaleVehicles();
      const queueItems = getQueue();
      const postedItems = getPostedVehicles();
      const usage = persistPostingUsageSnapshot({
        posts_today: payload.posts_today,
        posting_limit: payload.posting_limit
      });

      let session = null;
      try {
        session = await runtimeMessage({ type: "GET_EXTENSION_SESSION" });
      } catch {}

      const normalizedSession = session?.session || session?.data || session || {};
      const sessionUser = normalizedSession?.user || {};
      const sessionProfile = normalizedSession?.profile || {};

      const computedPayload = {
        user_id: clean(payload.user_id || normalizedSession?.user_id || sessionUser?.id || ""),
        email: clean(payload.email || normalizedSession?.email || sessionUser?.email || "").toLowerCase(),
        dealership_id: clean(payload.dealership_id || normalizedSession?.dealership_id || sessionProfile?.dealership_id || ""),
        hostname: window.location.hostname,
        page_url: window.location.href,
        client_version: clean(chrome?.runtime?.getManifest?.().version || ""),
        queue_count: Array.isArray(queueItems) ? queueItems.length : 0,
        active_listings: payload.active_listings ?? Math.max(Array.isArray(postedItems) ? postedItems.length : 0, workerPostedKeys.size),
        stale_listings: Array.isArray(staleItems) ? staleItems.length : 0,
        review_queue_count: Array.isArray(reviewItems) ? reviewItems.length : 0,
        review_new_count: payload.review_new_count ?? 0,
        review_delete_count:
          payload.review_delete_count ??
          (Array.isArray(reviewItems)
            ? reviewItems.filter((item) => clean(item?.status || "").toLowerCase() === "review_delete").length
            : 0),
        review_price_change_count: payload.review_price_change_count ?? 0,
        posts_today: payload.posts_today ?? usage.posts_today,
        posts_this_month: payload.posts_this_month ?? usage.posts_today,
        posting_limit: payload.posting_limit ?? usage.posting_limit,
        posts_remaining: payload.posts_remaining ?? usage.posts_remaining,
        total_views: payload.total_views ?? 0,
        total_messages: payload.total_messages ?? 0,
        lifecycle_updated_at: new Date().toISOString(),
        listings: Array.isArray(payload.listings) ? payload.listings : [],
        ...payload
      };

      return await runtimeMessage({ type: "SYNC_LIFECYCLE", payload: computedPayload });
    } catch (error) {
      warn("triggerLifecycleSync failed:", error?.message || error);
      return null;
    }
  }

  async function getSession() {
    try {
      const data = await new Promise((resolve) => {
        chrome.storage.local.get([
          "ea_extension_session",
          "elevate_session_snapshot",
          "elevate_profile_snapshot",
          "ea_profile_snapshot",
          "ea_dashboard_profile_v1",
          "ea_user_profile",
          "ea_user_data"
        ], resolve);
      });

      const session =
        data?.ea_extension_session ||
        data?.elevate_session_snapshot ||
        window.__EA_EXTENSION_SESSION ||
        null;

      const profileCandidate = normalizeProfileShape({
        ...(data?.ea_dashboard_profile_v1 || {}),
        ...(data?.elevate_profile_snapshot || {}),
        ...(data?.ea_profile_snapshot || {}),
        ...(data?.ea_user_profile || {}),
        ...(data?.ea_user_data || {})
      });

      if (profileCandidate && (profileCandidate.full_name || profileCandidate.dealer_name)) {
        window.__EA_PROFILE = profileCandidate;
      }

      return session;
    } catch {
      return window.__EA_EXTENSION_SESSION || null;
    }
  }

  async function getDashboardProfileCache() {
    try {
      const data = await new Promise((resolve) => {
        chrome.storage.local.get([
          "ea_dashboard_profile_v1",
          "elevate_profile_snapshot",
          "ea_profile_snapshot",
          "ea_user_profile",
          "ea_user_data"
        ], resolve);
      });

      const localCandidates = normalizeProfileShape({
        ...(getProfileCache() || {}),
        ...(safeJsonParse(localStorage.getItem("ea_dashboard_profile_v1") || "{}", {}) || {}),
        ...(safeJsonParse(localStorage.getItem("elevate_profile_snapshot") || "{}", {}) || {}),
        ...(safeJsonParse(localStorage.getItem("ea_profile_snapshot") || "{}", {}) || {})
      });

      const merged = normalizeProfileShape({
        ...localCandidates,
        ...(data?.ea_user_data || {}),
        ...(data?.ea_user_profile || {}),
        ...(data?.ea_profile_snapshot || {}),
        ...(data?.elevate_profile_snapshot || {}),
        ...(data?.ea_dashboard_profile_v1 || {}),
        ...(window.__EA_PROFILE || {})
      });

      return merged;
    } catch {
      return normalizeProfileShape({
        ...(window.__EA_PROFILE || {}),
        ...(getProfileCache() || {})
      });
    }
  }

  function normalizeAccess(session) {
    return Boolean(
      session?.access ||
      session?.active ||
      session?.subscription?.active ||
      session?.subscription?.status === "active"
    );
  }

  function getProfileFromSession(sessionOverride = null) {
    const session = sessionOverride || currentSession || {};
    const profile = session?.profile || {};
    const dealership = session?.dealership || {};
    const user = session?.user || {};
    const cached = normalizeProfileShape({
      ...(window.__EA_PROFILE || {}),
      ...(getProfileCache() || {})
    });

    const merged = normalizeProfileShape({
      ...cached,
      ...profile,
      ...dealership,
      ...user,
      full_name: firstNonEmpty(
        profile.full_name,
        profile.salesperson_name,
        profile.name,
        user.full_name,
        user.name,
        cached.full_name
      ),
      dealer_name: firstNonEmpty(
        profile.dealer_name,
        profile.dealership_name,
        profile.dealership,
        dealership.name,
        dealership.dealer_name,
        cached.dealer_name
      ),
      listing_location: firstNonEmpty(
        profile.listing_location,
        profile.location,
        cached.listing_location,
        dealership.city
      ),
      province: firstNonEmpty(
        profile.province,
        cached.province,
        dealership.province
      ),
      dealer_phone: firstNonEmpty(
        profile.dealer_phone,
        dealership.phone,
        cached.dealer_phone
      ),
      dealer_email: firstNonEmpty(
        profile.dealer_email,
        dealership.email,
        cached.dealer_email
      ),
      phone: firstNonEmpty(
        profile.phone,
        profile.dealer_phone,
        cached.phone,
        cached.dealer_phone,
        dealership.phone
      ),
      email: firstNonEmpty(
        profile.email,
        profile.dealer_email,
        cached.email,
        cached.dealer_email,
        dealership.email
      ),
      inventory_url: firstNonEmpty(
        profile.inventory_url,
        cached.inventory_url,
        dealership.inventory_url
      ),
      dealer_website: firstNonEmpty(
        profile.dealer_website,
        cached.dealer_website,
        dealership.website
      ),
      compliance_signature: firstNonEmpty(
        profile.compliance_signature,
        cached.compliance_signature
      ),
      scanner_type: firstNonEmpty(
        session?.scanner_config?.scanner_type,
        dealership.scanner_type,
        cached.scanner_type
      )
    });

    return normalizeProfileShape(merged);
  }
function getActiveAdapterId() {
  try {
    return clean(window.ElevateScannerRouter?.getActiveAdapterId?.() || "generic").toLowerCase();
  } catch {
    return "generic";
  }
}

  function shouldRunOnThisPage() {
    const pathname = lower(window.location.pathname);
    const href = lower(window.location.href);
    if (href.includes("facebook.com/marketplace")) return false;
    if (pathname.includes("dashboard")) return false;
    if (pathname.includes("login")) return false;
    return true;
  }

  function shouldRenderScannerForLinkedDealer(profileOverride = null, sessionOverride = null) {
    const session = sessionOverride || currentSession;
    if (!normalizeAccess(session)) return false;

    const linkedHost = getLinkedDealerHost(profileOverride, sessionOverride);
    if (!linkedHost) return false;

    const currentHost = getCurrentHost();
    return hostsMatch(currentHost, linkedHost);
  }

  async function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    const body = await waitForBody();
    if (!body) return null;

    panel = document.createElement("div");
    panel.id = PANEL_ID;
    Object.assign(panel.style, {
      position: "fixed",
      top: "20px",
      right: "20px",
      width: "390px",
      maxHeight: "86vh",
      overflowY: "auto",
      zIndex: "999999",
      background: "linear-gradient(180deg,#101114 0%,#171a21 100%)",
      border: "1px solid rgba(212,175,55,.22)",
      borderRadius: "18px",
      boxShadow: "0 18px 45px rgba(0,0,0,.42)",
      color: "#fff",
      fontFamily: "Inter, Arial, sans-serif"
    });

    body.appendChild(panel);
    return panel;
  }

  function removePanel() {
    document.getElementById(PANEL_ID)?.remove();
  }

  function getVehicleKey(vehicle) {
    if (window.ElevateQueueManager?.buildVehicleKey) {
      return window.ElevateQueueManager.buildVehicleKey(vehicle);
    }

    const vin = clean(vehicle?.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(vehicle?.stock || vehicle?.stock_number || "").toUpperCase();
    if (stock) return `STOCK:${stock}`;

    return [
      clean(vehicle?.year || "").toUpperCase(),
      clean(vehicle?.make || "").toUpperCase(),
      clean(vehicle?.model || "").toUpperCase(),
      String(vehicle?.price || "").replace(/[^\d]/g, ""),
      String(vehicle?.km || vehicle?.kilometers || vehicle?.mileage || "").replace(/[^\d]/g, "")
    ].join("|");
  }

  function canPostMore() {
    return getPostsToday() < getPostingLimit();
  }

  function isComplianceReady(profile) {
    return Boolean(
      clean(profile?.full_name) &&
      clean(profile?.dealer_name) &&
      clean(profile?.listing_location) &&
      clean(profile?.province)
    );
  }

  function isVehicleBlocked(vehicle, opts = {}) {
    const key = getVehicleKey(vehicle);
    if (!key) return true;

    const excludeCurrent = !!opts.excludeCurrent;
    const current = getCurrentVehicle();
    const currentKey = getVehicleKey(current);

    const posted = getPostedVehicles();
    const queue = getQueue();

    if (workerPostedKeys.has(key)) return true;
    if (posted.some((v) => getVehicleKey(v) === key)) return true;

    if (queue.some((v) => {
      const qKey = getVehicleKey(v);
      if (!qKey) return false;
      if (excludeCurrent && currentKey && qKey === currentKey) return false;
      return qKey === key;
    })) return true;

    return false;
  }

  function normalizeColorLabel(color) {
    const c = lower(color);
    if (!c) return "";
    if (c.includes("black")) return "Black";
    if (c.includes("white")) return "White";
    if (c.includes("silver")) return "Silver";
    if (c.includes("grey") || c.includes("gray") || c.includes("graphite") || c.includes("charcoal")) return "Grey";
    if (c.includes("blue")) return "Blue";
    if (c.includes("red") || c.includes("burgundy") || c.includes("maroon")) return "Red";
    if (c.includes("green")) return "Green";
    if (c.includes("brown") || c.includes("bronze") || c.includes("mocha")) return "Brown";
    if (c.includes("orange")) return "Orange";
    if (c.includes("yellow") || c.includes("gold")) return "Yellow";
    if (c.includes("beige") || c.includes("tan") || c.includes("champagne")) return "Beige";
    if (c.includes("purple")) return "Purple";
    return stripJunk(color);
  }

  function dedupeUrls(list) {
    const seen = new Set();
    return (list || []).filter((item) => {
      const key = clean(item).split("?")[0];
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function lockVehicleDetailUrl(vehicle = {}) {
    const locked = getLockedDetailUrl(vehicle);
    if (!locked) return { ...vehicle };

    return {
      ...vehicle,
      detail_url_locked: locked,
      detailUrlLocked: locked,
      detailUrl: locked,
      vdp_url: locked,
      vdpUrl: locked,
      vehicleUrl: locked,
      source_url: locked,
      sourceUrl: locked
    };
  }

  function aliasVehicleFields(vehicle) {
    let v = { ...(vehicle || {}) };

    const locked = getLockedDetailUrl(v);
    if (locked) {
      v.detail_url_locked = locked;
      v.detailUrlLocked = locked;
      v.detailUrl = locked;
      v.vdp_url = locked;
      v.vdpUrl = locked;
      v.vehicleUrl = locked;
      v.source_url = locked;
      v.sourceUrl = locked;
    }

    v.price = Number(v.price || v.list_price || v.asking_price || digits(v.price || "")) || "";
    v.km = Number(v.km || v.kilometers || v.mileage || digits(v.km || "")) || "";

    v.year = stripJunk(v.year || "");
    v.make = stripJunk(v.make || "");
    v.model = stripJunk(v.model || "");
    v.trim = stripJunk(v.trim || "");
    v.vin = stripJunk(v.vin || "").toUpperCase();
    v.stock = stripJunk(v.stock || v.stock_number || v.stockNumber || "");

    v.body_style = stripJunk(v.body_style || v.body || v.specs?.body || "");
    v.fuel_type = stripJunk(v.fuel_type || v.fuel || v.specs?.fuel || "");
    v.exterior_color = normalizeColorLabel(v.exterior_color || v.color || v.specs?.exterior_color || "");

    v.vehicle_type = stripJunk(v.vehicle_type || v.specs?.vehicle_type || "");
    v.location = stripJunk(v.location || v.listing_location || "");
    v.listing_location = stripJunk(v.listing_location || v.location || "");

    v.title = stripJunk(v.title || [v.year, v.make, v.model, v.trim].filter(Boolean).join(" "));
    v.rawText = stripJunk(v.rawText || v.raw_text || "");

    const photos = dedupeUrls([
      ...(Array.isArray(v.photoUrls) ? v.photoUrls : []),
      ...(Array.isArray(v.photos) ? v.photos : []),
      ...(Array.isArray(v.images) ? v.images : []),
      clean(v.coverPhotoUrl || v.cover_photo_url || ""),
      clean(v.photo || ""),
      clean(v.primaryPhoto || "")
    ]);

    v.photoUrls = photos.slice(0, 20);
    v.coverPhotoUrl = clean(v.coverPhotoUrl || v.cover_photo_url || v.photoUrls?.[0] || "");

    v.specs = {
      ...(v.specs || {}),
      body: v.body_style || "",
      fuel: v.fuel_type || "",
      exterior_color: v.exterior_color || "",
      vehicle_type: v.vehicle_type || ""
    };

    return v;
  }

  function extractYear(text) {
    return clean(text).match(/\b(19|20)\d{2}\b/)?.[0] || "";
  }

  function extractMake(text) {
    const raw = lower(text);
    const makes = [
      ["toyota", "Toyota"], ["honda", "Honda"], ["ford", "Ford"], ["chevrolet", "Chevrolet"], ["chevy", "Chevrolet"],
      ["gmc", "GMC"], ["ram", "Ram"], ["dodge", "Dodge"], ["jeep", "Jeep"], ["mazda", "Mazda"],
      ["nissan", "Nissan"], ["hyundai", "Hyundai"], ["kia", "Kia"], ["subaru", "Subaru"], ["volkswagen", "Volkswagen"],
      ["vw", "Volkswagen"], ["audi", "Audi"], ["bmw", "BMW"], ["mercedes", "Mercedes-Benz"], ["porsche", "Porsche"],
      ["lexus", "Lexus"], ["acura", "Acura"], ["infiniti", "Infiniti"], ["genesis", "Genesis"], ["mitsubishi", "Mitsubishi"]
    ];
    for (const [needle, value] of makes) {
      if (new RegExp(`\\b${needle}\\b`, "i").test(raw)) return value;
    }
    return "";
  }

  function extractFuelCandidate(text) {
    const raw = lower(text);
    if (/\bhybrid|phev|plug[- ]?in|prime\b/.test(raw)) return "Hybrid";
    if (/\belectric|ev\b/.test(raw)) return "Electric";
    if (/\bdiesel|tdi|duramax|ecodiesel|cummins\b/.test(raw)) return "Diesel";
    if (/\bgasoline|gas\b/.test(raw)) return "Gasoline";
    return "";
  }

  function extractColorCandidate(text) {
    const raw = lower(text);
    if (raw.includes("black")) return "Black";
    if (raw.includes("white")) return "White";
    if (raw.includes("silver")) return "Silver";
    if (raw.includes("grey") || raw.includes("gray")) return "Grey";
    if (raw.includes("blue")) return "Blue";
    if (raw.includes("red")) return "Red";
    return "";
  }

  function extractBodyCandidate(text) {
    const raw = lower(text);
    if (/\btundra|tacoma|silverado|colorado|sierra|f150|f-150|f250|f-250|ram|1500 classic|ranger|maverick\b/.test(raw)) return "Truck";
    if (/\bronco sport|bronco|explorer|envision|outlander|blazer|cx5|cx-5|atlas|venza|durango|pilot|rav4|highlander|rogue|murano|pathfinder|passport|cr-v\b/.test(raw)) return "SUV";
    if (/\bwrx|corolla|mazda3|civic|accord|camry|elantra|sentra|altima|malibu|jetta|passat\b/.test(raw)) return "Sedan";
    if (/\boutback\b/.test(raw)) return "Wagon";
    return "";
  }

  function extractVehicleTypeCandidate(text) {
    const raw = lower(text);
    if (/motorcycle|harley|ducati|gsxr/.test(raw)) return "Motorcycle";
    if (/atv|utv|rzr|snowmobile|ski-doo|seadoo/.test(raw)) return "Powersport";
    if (/rv|camper|motorhome|travel trailer|fifth wheel/.test(raw)) return "RV/Camper";
    if (/utility trailer|dump trailer|enclosed trailer|\btrailer\b/.test(raw)) return "Trailer";
    if (/boat|pontoon|wake boat|fishing boat/.test(raw)) return "Boat";
    if (/commercial|industrial|forklift|excavator|loader/.test(raw)) return "Commercial/Industrial";
    return "";
  }

  function collectInlinePhotoUrls(node) {
    if (!node?.querySelectorAll) return [];

    const urls = [];
    const imgs = Array.from(node.querySelectorAll("img"));

    for (const img of imgs) {
      const candidates = [
        img.getAttribute("src"),
        img.getAttribute("data-src"),
        img.getAttribute("data-lazy"),
        img.getAttribute("data-original"),
        img.getAttribute("data-image"),
        img.getAttribute("data-full"),
        img.getAttribute("data-zoom-image")
      ];

      const srcset = clean(img.getAttribute("srcset"));
      if (srcset) {
        srcset.split(",").forEach((part) => {
          const first = clean(part).split(/\s+/)[0];
          if (first) candidates.push(first);
        });
      }

      for (const value of candidates) {
        const abs = toAbsoluteUrl(value);
        if (abs) urls.push(abs);
      }
    }

    return dedupeUrls(urls).slice(0, 20);
  }

  function extractDetailUrlFromNode(node) {
    if (!node?.querySelectorAll) return "";

    const linkSelectors = [
      'a[href*="/used/vehicle/"]',
      'a[href*="/new/vehicle/"]',
      'a[href*="/vehicle/"]',
      'a[href*="/vehicledetails/"]',
      'a[href*="/details/"]',
      'a[href*="-id"]',
      "h2 a",
      "h3 a",
      ".vehicle-title a",
      ".inventory-title a",
      ".title a",
      "a"
    ];

    for (const selector of linkSelectors) {
      const links = Array.from(node.querySelectorAll(selector));
      for (const link of links) {
        const href = clean(link.getAttribute("href") || link.href || "");
        const abs = toAbsoluteUrl(href);
        if (looksLikeVehicleDetailUrl(abs)) return abs;
      }
    }

    const attrCandidates = [
      node.getAttribute?.("data-ea-source-url"),
      node.getAttribute?.("data-url"),
      node.getAttribute?.("data-link"),
      node.getAttribute?.("data-vdp-url"),
      node.getAttribute?.("data-href")
    ];

    for (const candidate of attrCandidates) {
      const abs = toAbsoluteUrl(candidate);
      if (looksLikeVehicleDetailUrl(abs)) return abs;
    }

    return "";
  }

  function resolveVehicleSourceUrl(rawSourceUrl, sourceNode, shell) {
    const direct = toAbsoluteUrl(rawSourceUrl);
    if (looksLikeVehicleDetailUrl(direct)) return direct;

    const fromSourceNode = extractDetailUrlFromNode(sourceNode);
    if (looksLikeVehicleDetailUrl(fromSourceNode)) return fromSourceNode;

    const fromShell = extractDetailUrlFromNode(shell);
    if (looksLikeVehicleDetailUrl(fromShell)) return fromShell;

    return "";
  }

  function buildRawVehicleFromShell(shell) {
    const sourceNode = shell?.__eaSourceNode || null;
    const rawText = clean(shell?.getAttribute("data-ea-source-text") || "");
    const title = clean(shell?.getAttribute("data-ea-title") || "");
    const price = Number(digits(shell?.getAttribute("data-ea-price") || "")) || "";
    const kmValue = Number(digits(shell?.getAttribute("data-ea-km") || "")) || "";
    const stock = clean(shell?.getAttribute("data-ea-stock") || "");
    const vin = clean(shell?.getAttribute("data-ea-vin") || "").toUpperCase();

    const rawSourceUrl = clean(shell?.getAttribute("data-ea-source-url") || "");
    const sourceUrl = resolveVehicleSourceUrl(rawSourceUrl, sourceNode, shell);

    const imageUrl = clean(shell?.getAttribute("data-ea-image-url") || "");
    const shellPhotoUrls = safeJsonParse(shell?.getAttribute("data-ea-photo-urls") || "[]", []);
    const inlinePhotoUrls = collectInlinePhotoUrls(sourceNode || shell);
    const profile = getProfileFromSession();
    const sourceText = clean([title, rawText].filter(Boolean).join(" "));

    return lockVehicleDetailUrl({
      title,
      rawText,
      price,
      km: kmValue,
      kilometers: kmValue,
      mileage: kmValue,
      stock,
      vin,
      source_url: sourceUrl,
      sourceUrl,
      detail_url_locked: sourceUrl,
      detailUrl: sourceUrl,
      vdp_url: sourceUrl,
      vehicleUrl: sourceUrl,
      coverPhotoUrl: imageUrl,
      cover_photo_url: imageUrl,
      photoUrls: dedupeUrls([
        ...(Array.isArray(shellPhotoUrls) ? shellPhotoUrls : []),
        ...inlinePhotoUrls
      ]).slice(0, 20),
      dealer_name: profile.dealer_name,
      dealer_phone: profile.dealer_phone,
      dealer_email: profile.dealer_email,
      salesperson_name: profile.full_name,
      location: profile.listing_location,
      listing_location: profile.listing_location,
      scanner_type: profile.scanner_type,
      year: extractYear(sourceText),
      make: extractMake(sourceText),
      fuel_type: extractFuelCandidate(sourceText),
      exterior_color: extractColorCandidate(sourceText),
      body_style: extractBodyCandidate(sourceText),
      vehicle_type: extractVehicleTypeCandidate(sourceText),
      __eaSourceNode: sourceNode || null
    });
  }

  function runNormalizer(vehicle) {
    try {
      if (window.ElevateVehicleNormalizer?.normalizeVehicle) {
        return aliasVehicleFields(window.ElevateVehicleNormalizer.normalizeVehicle(vehicle));
      }
    } catch (error) {
      warn("normalizeVehicle failed:", error?.message || error);
    }
    return aliasVehicleFields(vehicle);
  }

  function runVinDecoder(vehicle) {
    try {
      if (window.ElevateVINDecoder?.decodeVIN) {
        return aliasVehicleFields(window.ElevateVINDecoder.decodeVIN(vehicle));
      }
    } catch (error) {
      warn("decodeVIN failed:", error?.message || error);
    }
    return aliasVehicleFields(vehicle);
  }

  function runSpecIntelligence(vehicle) {
    let v = aliasVehicleFields(vehicle);

    try {
      if (window.ElevateSpecIntelligence?.enrichSpecs) {
        v = aliasVehicleFields(window.ElevateSpecIntelligence.enrichSpecs(v));
      }
    } catch (error) {
      warn("enrichSpecs failed:", error?.message || error);
    }

    try {
      if (!v.body_style && window.ElevateSpecIntelligence?.detectBodyStyle) {
        v.body_style = clean(window.ElevateSpecIntelligence.detectBodyStyle(v));
      }
    } catch (error) {
      warn("detectBodyStyle failed:", error?.message || error);
    }

    try {
      if (!v.fuel_type && window.ElevateSpecIntelligence?.detectFuelType) {
        v.fuel_type = clean(window.ElevateSpecIntelligence.detectFuelType(v));
      } else if (!v.fuel_type && window.ElevateSpecIntelligence?.detectFuel) {
        v.fuel_type = clean(window.ElevateSpecIntelligence.detectFuel(v));
      }
    } catch (error) {
      warn("detectFuel failed:", error?.message || error);
    }

    return aliasVehicleFields(v);
  }

  function runSpecEnrichment(vehicle) {
    let v = aliasVehicleFields(vehicle);
    try {
      if (window.ElevateSpecEnrichment?.enrichVehicle) {
        v = aliasVehicleFields(window.ElevateSpecEnrichment.enrichVehicle(v));
      } else if (window.ElevateSpecEnrichment?.enrichVehicleSpecs) {
        v = aliasVehicleFields(window.ElevateSpecEnrichment.enrichVehicleSpecs(v));
      }
    } catch (error) {
      warn("spec enrichment failed:", error?.message || error);
    }
    return aliasVehicleFields(v);
  }

  async function runMediaEnrichment(vehicle, sourceNode) {
    let v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));
    const lockedBefore = getLockedDetailUrl(v);

    try {
      if (window.ElevateMediaEngine?.buildListing) {
        v = aliasVehicleFields(
  await window.ElevateMediaEngine.buildListing(
    v,
    sourceNode,
    getProfileFromSession(),
    { adapterId: getActiveAdapterId() }
  )
);
      
      const photos = await window.ElevateMediaEngine.collectVehicleImages(
  v,
  {
    maxImages: 20,
    sourceNode: sourceNode || v.__eaSourceNode || null,
    fallbackImages: Array.isArray(v.photoUrls) ? v.photoUrls : [],
    adapterId: getActiveAdapterId(),
    profile: getProfileFromSession()
  }
);

        if (Array.isArray(photos) && photos.length) {
          v.photoUrls = dedupeUrls(photos);
          if (!v.coverPhotoUrl) v.coverPhotoUrl = clean(v.photoUrls[0]);
        }
      }
    } catch (error) {
      warn("media enrichment failed:", error?.message || error);
    }

    try {
      if ((!v.exterior_color || !clean(v.exterior_color)) && window.ElevateMediaEngine?.inferDominantExteriorColor) {
        const detected = await window.ElevateMediaEngine.inferDominantExteriorColor(v, v.photoUrls || []);
        if (detected) v.exterior_color = normalizeColorLabel(detected);
      }
    } catch (error) {
      warn("inferDominantExteriorColor failed:", error?.message || error);
    }

    if (lockedBefore) {
      v = lockVehicleDetailUrl({ ...v, source_url: lockedBefore, sourceUrl: lockedBefore });
    }

    return aliasVehicleFields(v);
  }

  function fillHardFallbacks(vehicle) {
    let v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));
    const text = lower([v.title, v.make, v.model, v.trim, v.rawText].filter(Boolean).join(" "));

    if (!v.fuel_type) {
      if (text.includes("hybrid")) v.fuel_type = "Hybrid";
      else if (text.includes("electric") || text.includes("ev")) v.fuel_type = "Electric";
      else if (text.includes("diesel")) v.fuel_type = "Diesel";
      else if (v.vin) v.fuel_type = "Gasoline";
    }

    if (!v.body_style) {
      if (/\btundra|tacoma|silverado|colorado|sierra|f150|f-150|ram|ranger|maverick\b/.test(text)) v.body_style = "Truck";
      else if (/\bronco|explorer|envision|outlander|blazer|cx5|cx-5|atlas|venza|durango|pilot|rav4|highlander|rogue|murano|pathfinder\b/.test(text)) v.body_style = "SUV";
      else if (/\bwrx|jetta|corolla|civic|accord|camry|elantra|sentra|altima|malibu|mazda3\b/.test(text)) v.body_style = "Sedan";
    }

    if (!v.vehicle_type) {
      v.vehicle_type = extractVehicleTypeCandidate(text) || "Car/Truck";
    }

    const locked = getLockedDetailUrl(v);
    if (locked) {
      v = lockVehicleDetailUrl(v);
    }

    return aliasVehicleFields(v);
  }

  async function enrichVehicle(rawVehicle, sourceNode) {
    let vehicle = aliasVehicleFields(lockVehicleDetailUrl(rawVehicle));
    vehicle.adapter_id = getActiveAdapterId();
vehicle.scanner_type = firstNonEmpty(
  vehicle.scanner_type,
  vehicle.adapter_id,
  getProfileFromSession()?.scanner_type
);
    vehicle = runNormalizer(vehicle);
    vehicle = runVinDecoder(vehicle);
    vehicle = runSpecIntelligence(vehicle);
    vehicle = runSpecEnrichment(vehicle);
    vehicle = await runMediaEnrichment(vehicle, sourceNode);
    vehicle = fillHardFallbacks(vehicle);
    return aliasVehicleFields(lockVehicleDetailUrl(vehicle));
  }

  async function hydrateVehicleForPosting(vehicle, sourceNode = null) {
    let v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));
    const lockedBefore = getLockedDetailUrl(v);

    try {
      if (window.ElevateMediaEngine?.hydrateVehiclePhotosFromDetailPage) {
        v = aliasVehicleFields(await window.ElevateMediaEngine.hydrateVehiclePhotosFromDetailPage(v, sourceNode));
      } else if (window.ElevateMediaEngine?.buildListing) {
        v = aliasVehicleFields(await window.ElevateMediaEngine.buildListing(v, sourceNode, getProfileFromSession()));
      } else if (window.ElevateMediaEngine?.collectVehicleImages) {
        const photos = await window.ElevateMediaEngine.collectVehicleImages(v, {
          maxImages: 20,
          sourceNode: sourceNode || v.__eaSourceNode || null,
          fallbackImages: Array.isArray(v.photoUrls) ? v.photoUrls : []
        });

        if (Array.isArray(photos) && photos.length) {
          v.photoUrls = dedupeUrls(photos);
          if (!v.coverPhotoUrl) v.coverPhotoUrl = clean(v.photoUrls[0]);
        }
      }
    } catch (error) {
      warn("hydrateVehicleForPosting failed:", error?.message || error);
    }

    if (lockedBefore) {
      v = lockVehicleDetailUrl({ ...v, source_url: lockedBefore, sourceUrl: lockedBefore });
    }

    return aliasVehicleFields(v);
  }

  function buildPreparedPayload(vehicle) {
    let v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));
    const profile = getProfileFromSession();
    const title = clean(v.title || [v.year, v.make, v.model, v.trim].filter(Boolean).join(" "));

    const lockedDetailUrl = getLockedDetailUrl(v);

    const description = window.ElevateDescriptionBuilder?.buildDescription
      ? (() => {
          try {
            return clean(window.ElevateDescriptionBuilder.buildDescription(
              {
                ...v,
                source_url: lockedDetailUrl || "",
                sourceUrl: lockedDetailUrl || "",
                location: v.listing_location || profile.listing_location || "",
                bodyStyle: v.body_style,
                exteriorColor: v.exterior_color,
                fuelType: v.fuel_type
              },
              {
                full_name: profile.full_name,
                phone: profile.phone,
                dealership: profile.dealer_name,
                dealer_name: profile.dealer_name,
                listing_location: profile.listing_location,
                province: profile.province,
                dealer_email: profile.dealer_email,
                dealer_phone: profile.dealer_phone
              }
            ));
          } catch {
            return clean(v.description || "");
          }
        })()
      : clean(v.description || "");

    return {
      id: getVehicleKey(v),
      title,
      year: v.year,
      make: v.make,
      model: v.model,
      trim: v.trim,
      price: String(v.price || ""),
      kilometers: String(v.km || ""),
      mileage: String(v.km || ""),
      vin: v.vin,
      stock: v.stock,
      vehicleType: v.vehicle_type || "Car/Truck",
      bodyStyle: v.body_style || v.bodyStyle || v.specs?.body || "",
      exteriorColor: v.exterior_color || v.exteriorColor || v.specs?.exterior_color || "",
      fuelType: v.fuel_type || v.fuelType || v.specs?.fuel || "Gasoline",
      location: v.listing_location || profile.listing_location || "",
      listing_location: v.listing_location || profile.listing_location || "",
      coverPhotoUrl: v.coverPhotoUrl || "",
      photoUrls: Array.isArray(v.photoUrls) ? v.photoUrls.slice(0, 20) : [],
      sourceUrl: lockedDetailUrl || "",
      source_url: lockedDetailUrl || "",
      detail_url_locked: lockedDetailUrl || "",
      detailUrl: lockedDetailUrl || "",
      vdp_url: lockedDetailUrl || "",
      vehicleUrl: lockedDetailUrl || "",
      dealer_name: profile.dealer_name || v.dealer_name || "",
      dealership: profile.dealer_name || v.dealer_name || "",
      dealer_phone: profile.dealer_phone || v.dealer_phone || "",
      dealer_email: profile.dealer_email || v.dealer_email || "",
      salesperson_name: profile.full_name || v.salesperson_name || "",
      full_name: profile.full_name || "",
      phone: profile.phone || "",
      description,
      prepared_at: Date.now(),
      profile: {
        full_name: profile.full_name || "",
        phone: profile.phone || "",
        dealership: profile.dealer_name || "",
        dealer_name: profile.dealer_name || "",
        dealer_phone: profile.dealer_phone || "",
        dealer_email: profile.dealer_email || "",
        listing_location: profile.listing_location || "",
        province: profile.province || "",
        scanner_type: profile.scanner_type || ""
      }
    };
  }

  function sanitizeVehicleForQueue(vehicle) {
    const locked = getLockedDetailUrl(vehicle);
    const v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));
    return {
      ...v,
      __eaSourceNode: null,
      source_url: locked || "",
      sourceUrl: locked || "",
      detail_url_locked: locked || "",
      detailUrl: locked || "",
      vdp_url: locked || "",
      vehicleUrl: locked || ""
    };
  }

  async function syncPipelineToExtension(preparedVehicle = null) {
    await refreshWorkerPostedRegistry();
    const profile = getProfileFromSession();
    const queuePayload = getQueue().map((item) => buildPreparedPayload(lockVehicleDetailUrl(item)));
    const inventorySnapshot = Object.fromEntries(
      currentScanResults.map((v) => [getVehicleKey(v), buildPreparedPayload(lockVehicleDetailUrl(v))])
    );

    setProfileCache(profile);
    window.__EA_PROFILE = normalizeProfileShape({
      ...(window.__EA_PROFILE || {}),
      ...profile
    });

    if (preparedVehicle) await engineSaveCurrentVehicle(preparedVehicle, "inventory");
    await engineSaveQueue(queuePayload);
    await engineSaveProfileSnapshot(profile);
    await engineSyncInventory(inventorySnapshot);

    try {
      const payload = {
        elevate_current_vehicle: preparedVehicle ? buildPreparedPayload(lockVehicleDetailUrl(preparedVehicle)) : null,
        elevate_vehicle_queue: queuePayload,
        elevate_profile_snapshot: profile,
        ea_profile_snapshot: profile,
        ea_dashboard_profile_v1: profile,
        ea_extension_session: currentSession || null,
        elevate_session_snapshot: currentSession || null,
        elevate_inventory_snapshot: inventorySnapshot,
        elevate_posted_vehicles: Array.from(workerPostedKeys)
      };
      if (preparedVehicle) payload.elevate_posting_trigger = Date.now();
      await chrome.storage.local.set(payload);
    } catch (error) {
      warn("chrome.storage sync failed:", error?.message || error);
    }
  }

  function getStats() {
    return {
      queueCount: getQueue().length,
      postedCount: Math.max(getPostedVehicles().length, workerPostedKeys.size),
      resultsCount: currentScanResults.length,
      staleCount: getStaleVehicles().length,
      current: getCurrentVehicle()
    };
  }

  function isAlreadyPosted(vehicle) {
    return isPostedKnown(vehicle);
  }

  function removeVehicleFromQueue(vehicle) {
    const key = getVehicleKey(vehicle);
    const queue = getQueue().filter((item) => getVehicleKey(item) !== key);
    setQueue(queue);
  }

  function syncStaleInventory(scanResults) {
    const currentKeys = new Set((scanResults || []).map(getVehicleKey).filter(Boolean));
    const posted = getPostedVehicles();

    const stale = posted
      .filter((item) => {
        const key = getVehicleKey(item);
        return key && !currentKeys.has(key);
      })
      .map((item) => ({
        ...item,
        stale_reason: "Missing from latest dealer inventory scan",
        lifecycle_status: "stale",
        flagged_at: Date.now()
      }));

    setStaleVehicles(stale);
    setReviewItems(
      stale.map((item) => ({
        key: getVehicleKey(item),
        vin: item.vin || "",
        stock: item.stock || "",
        title: item.title || [item.year, item.make, item.model, item.trim].filter(Boolean).join(" "),
        status: "review_delete",
        lifecycle_status: "stale",
        flagged_at: item.flagged_at
      }))
    );
  }

  async function startPostingVehicle(vehicle) {
    let v = aliasVehicleFields(lockVehicleDetailUrl(vehicle));

    if (!v || !v.title) {
      lastStatusMessage = "No vehicle ready to post.";
      await safeRender();
      return;
    }

    await refreshWorkerPostedRegistry();
    const profile = getProfileFromSession();

    if (!isComplianceReady(profile)) {
      lastStatusMessage = "Compliance profile incomplete.";
      await safeRender();
      return;
    }

    if (!canPostMore()) {
      lastStatusMessage = "Posting limit reached.";
      await safeRender();
      return;
    }

    if (await isPostedInWorker(v) || isVehicleBlocked(v, { excludeCurrent: true })) {
      lastStatusMessage = "Blocked: vehicle already queued or posted.";
      await safeRender();
      return;
    }

    try {
      v = await hydrateVehicleForPosting(v, v.__eaSourceNode || null);
      const payload = buildPreparedPayload(lockVehicleDetailUrl(v));

      removeVehicleFromQueue(v);

      setCurrentVehicle(payload);
      window.__EA_CURRENT_VEHICLE = payload;
      await syncPipelineToExtension(payload);

      await triggerLifecycleSync({
        queue_count: getQueue().length,
        active_listings: getPostedVehicles().length,
        listings: [payload]
      });

      window.open("https://www.facebook.com/marketplace/create/vehicle", "_blank");
      lastStatusMessage = "Opening Marketplace with prepared vehicle...";
    } catch (err) {
      warn("Posting failed:", err?.message || err);
      lastStatusMessage = "Failed to launch Marketplace posting.";
    }

    await safeRender();
  }

  function buildResultCard(vehicle, index) {
    const title = clean(vehicle?.title || [vehicle?.year, vehicle?.make, vehicle?.model, vehicle?.trim].filter(Boolean).join(" ")) || "Vehicle";
    const priceText = money(vehicle?.price) || "—";
    const kmText = km(vehicle?.km) || "—";
    const bodyText = clean(vehicle?.body_style || vehicle?.specs?.body || "") || "—";
    const fuelText = clean(vehicle?.fuel_type || vehicle?.specs?.fuel || "") || "—";
    const colorText = clean(vehicle?.exterior_color || vehicle?.specs?.exterior_color || "") || "—";
    const photoCount = Array.isArray(vehicle?.photoUrls) ? vehicle.photoUrls.length : (vehicle?.coverPhotoUrl ? 1 : 0);
    const postedBadge = isAlreadyPosted(vehicle)
      ? `<div style="font-size:11px;color:#9fe3ac;font-weight:700;">Already posted</div>`
      : "";

    return `
      <div style="background:#171920;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:12px;display:grid;gap:8px;">
        <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
          <div style="font-size:13px;font-weight:800;line-height:1.35;">${escapeHtml(title)}</div>
          ${postedBadge}
        </div>
        <div style="font-size:12px;color:rgba(255,255,255,.78);display:grid;grid-template-columns:1fr 1fr;gap:6px;">
          <div><strong>Color:</strong> ${escapeHtml(colorText)}</div>
          <div><strong>Photos:</strong> ${escapeHtml(String(photoCount || 0))}</div>
          <div><strong>Price:</strong> ${escapeHtml(priceText)}</div>
          <div><strong>KM:</strong> ${escapeHtml(kmText)}</div>
          <div><strong>VIN:</strong> ${escapeHtml(vehicle?.vin || "—")}</div>
          <div><strong>Stock:</strong> ${escapeHtml(vehicle?.stock || "—")}</div>
          <div><strong>Fuel:</strong> ${escapeHtml(fuelText)}</div>
          <div><strong>Body:</strong> ${escapeHtml(bodyText)}</div>
        </div>
        <div style="font-size:11px;color:rgba(255,255,255,.55);word-break:break-all;">
          <strong>Detail URL:</strong> ${escapeHtml(getLockedDetailUrl(vehicle) || "Not resolved")}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
          <button class="ea-add-queue-btn" data-index="${index}" style="border:none;border-radius:10px;padding:11px;background:#21242d;color:#fff;font-weight:700;cursor:pointer;">Add to Queue</button>
          <button class="ea-load-now-btn" data-index="${index}" style="border:none;border-radius:10px;padding:11px;background:#21242d;color:#fff;font-weight:700;cursor:pointer;">Load Now</button>
          <button class="ea-start-post-btn" data-index="${index}" style="border:none;border-radius:10px;padding:11px;background:linear-gradient(135deg,#d4af37,#b78d20);color:#101114;font-weight:800;cursor:pointer;">Start Posting</button>
        </div>
      </div>
    `;
  }

  async function safeRender() {
    if (isRendering) return;
    isRendering = true;
    try { await render(); }
    catch (error) { warn("render failed:", error?.message || error); }
    finally { isRendering = false; }
  }

  async function addVehicleToQueue(vehicle) {
    const v = sanitizeVehicleForQueue(vehicle);

    await refreshWorkerPostedRegistry();
    if (await isPostedInWorker(v) || isVehicleBlocked(v)) {
      lastStatusMessage = "Blocked: vehicle already queued or posted.";
      return;
    }

    const queue = getQueue();
    const key = getVehicleKey(v);

    if (queue.some((item) => getVehicleKey(item) === key)) {
      lastStatusMessage = "Vehicle already in queue.";
      return;
    }

    queue.push(v);
    setQueue(queue);
    await syncPipelineToExtension(getCurrentVehicle());

    await triggerLifecycleSync({
      queue_count: queue.length,
      active_listings: getPostedVehicles().length,
      listings: queue.map((item) => buildPreparedPayload(lockVehicleDetailUrl(item)))
    });

    lastStatusMessage = "Added to queue.";
  }

  async function addToQueueByIndex(index) {
    const vehicle = currentScanResults[index];
    if (!vehicle) return;
    await addVehicleToQueue(vehicle);
    await safeRender();
  }

  async function loadNowByIndex(index) {
    const vehicle = currentScanResults[index];
    if (!vehicle) return;

    await refreshWorkerPostedRegistry();
    if (await isPostedInWorker(vehicle)) {
      lastStatusMessage = "Vehicle already posted.";
      await safeRender();
      return;
    }

    try {
      const hydrated = await hydrateVehicleForPosting(lockVehicleDetailUrl(aliasVehicleFields(vehicle)), vehicle.__eaSourceNode || null);
      const payload = buildPreparedPayload(lockVehicleDetailUrl(hydrated));
      setCurrentVehicle(payload);
      window.__EA_CURRENT_VEHICLE = payload;
      await syncPipelineToExtension(payload);

      await triggerLifecycleSync({
        queue_count: getQueue().length,
        active_listings: getPostedVehicles().length,
        listings: [payload]
      });

      lastStatusMessage = "Vehicle loaded.";
    } catch (error) {
      warn("loadNowByIndex failed:", error?.message || error);
      lastStatusMessage = "Vehicle handoff failed.";
    }

    await safeRender();
  }

  async function loadNextFromQueue() {
    await refreshWorkerPostedRegistry();
    const queue = getQueue();
    if (!queue.length) {
      lastStatusMessage = "Queue is empty.";
      await safeRender();
      return;
    }

    let next = null;
    while (queue.length) {
      const candidate = lockVehicleDetailUrl(queue.shift());
      if (await isPostedInWorker(candidate)) continue;
      next = candidate;
      break;
    }
    setQueue(queue);

    if (!next) {
      lastStatusMessage = "Queue empty.";
      await syncPipelineToExtension(null);
      await safeRender();
      return;
    }

    try {
      const hydrated = await hydrateVehicleForPosting(next, null);
      const payload = buildPreparedPayload(lockVehicleDetailUrl(hydrated));
      setCurrentVehicle(payload);
      window.__EA_CURRENT_VEHICLE = payload;
      await syncPipelineToExtension(payload);

      await triggerLifecycleSync({
        queue_count: queue.length,
        active_listings: getPostedVehicles().length,
        listings: [payload]
      });

      lastStatusMessage = "Loaded next queued vehicle.";
    } catch (error) {
      warn("loadNextFromQueue failed:", error?.message || error);
      lastStatusMessage = "Next vehicle handoff failed.";
    }

    await safeRender();
  }

  async function markCurrentVehiclePosted() {
    const current = getCurrentVehicle();
    if (!current) {
      lastStatusMessage = "No current vehicle loaded.";
      await safeRender();
      return;
    }

    await refreshWorkerPostedRegistry();
    const posted = getPostedVehicles();
    const key = getVehicleKey(current);

    if (!posted.some((item) => getVehicleKey(item) === key)) {
      posted.push({ ...current, posted_at: Date.now() });
      setPostedVehicles(posted);
    }

    try {
      await engineMarkVehiclePosted(current);
      if (key) workerPostedKeys.add(key);
    } catch {}

    removeVehicleFromQueue(current);
    await syncPipelineToExtension(null);

    await triggerLifecycleSync({
      active_listings: posted.length,
      queue_count: getQueue().length,
      listings: posted
    });

    lastStatusMessage = "Marked current vehicle as posted.";
    await safeRender();
  }

  async function refreshSessionState() {
    currentSession = await getSession();
    await refreshWorkerPostedRegistry();

    const dashboardProfile = await getDashboardProfileCache();
    const sessionProfile = getProfileFromSession(currentSession);
    const mergedProfile = normalizeProfileShape({
      ...dashboardProfile,
      ...sessionProfile
    });

    persistPostingUsageSnapshot();
resetQueueState({ clearCurrent: false });

    if (Object.keys(mergedProfile).length) {
      window.__EA_PROFILE = mergedProfile;
      setProfileCache(mergedProfile);

      try {
        await chrome.storage.local.set({
          ea_dashboard_profile_v1: mergedProfile,
          elevate_profile_snapshot: mergedProfile,
          ea_profile_snapshot: mergedProfile
        });
      } catch (error) {
        warn("refresh profile storage sync failed:", error?.message || error);
      }
    }

    if (!shouldRenderScannerForLinkedDealer(mergedProfile, currentSession)) {
      removePanel();
      await syncPipelineToExtension(null);
      await triggerLifecycleSync({ queue_count: 0 });
      lastStatusMessage = currentSession ? "Scanner hidden: current site does not match linked dealer." : "No active extension session found.";
      return Boolean(currentSession);
    }

    await syncPipelineToExtension(getCurrentVehicle());
    await triggerLifecycleSync({
      queue_count: 0,
      active_listings: Math.max(getPostedVehicles().length, workerPostedKeys.size)
    });
    lastStatusMessage = currentSession ? "Session refreshed." : "No active extension session found.";
    await safeRender();
    return Boolean(currentSession);
  }

  async function runScan() {
    if (isScanning) return;

    await refreshWorkerPostedRegistry();
    isScanning = true;
    lastStatusMessage = "Scanning inventory...";
    await safeRender();

    try {
      if (!window.ElevateScannerRouter?.findVehicleCards) {
        lastStatusMessage = "Scanner router not loaded.";
        return;
      }

      const shells = await Promise.resolve(window.ElevateScannerRouter.findVehicleCards(document));
      if (!Array.isArray(shells) || !shells.length) {
        currentScanResults = [];
        syncStaleInventory(currentScanResults);
        await syncPipelineToExtension(getCurrentVehicle());

        await triggerLifecycleSync({
          queue_count: getQueue().length,
          active_listings: getPostedVehicles().length,
          stale_listings: getStaleVehicles().length,
          review_queue_count: getReviewItems().length,
          review_delete_count: getReviewItems().filter((item) => clean(item?.status || "").toLowerCase() === "review_delete").length,
          listings: []
        });

        lastStatusMessage = "Scan complete. 0 vehicles found.";
        return;
      }

      const enriched = [];
      for (const shell of shells) {
        try {
          const rawVehicle = buildRawVehicleFromShell(shell);
          const finalVehicle = await enrichVehicle(rawVehicle, shell.__eaSourceNode || null);
          enriched.push(lockVehicleDetailUrl(finalVehicle));
        } catch (error) {
          warn("Vehicle enrichment failed:", error?.message || error);
        }
      }

      const seen = new Set();
      currentScanResults = enriched.filter((vehicle) => {
        const key = getVehicleKey(vehicle);
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      });

      writeStorage(STORAGE_KEYS.LAST_SCAN, currentScanResults.map(sanitizeVehicleForQueue));
      syncStaleInventory(currentScanResults);
      await syncPipelineToExtension(getCurrentVehicle());

      await triggerLifecycleSync({
        queue_count: getQueue().length,
        active_listings: getPostedVehicles().length,
        stale_listings: getStaleVehicles().length,
        review_queue_count: getReviewItems().length,
        review_delete_count: getReviewItems().filter((item) => clean(item?.status || "").toLowerCase() === "review_delete").length,
        listings: currentScanResults.map((item) => buildPreparedPayload(lockVehicleDetailUrl(item)))
      });

      lastStatusMessage = `Scan complete. ${currentScanResults.length} vehicles found.`;
    } catch (error) {
      warn("runScan failed:", error?.message || error);
      lastStatusMessage = "Scan failed.";
    } finally {
      isScanning = false;
      await safeRender();
    }
  }

  function bindPanelActions() {
    document.getElementById("eaRunScanBtn")?.addEventListener("click", async () => { await runScan(); });
    document.getElementById("eaLoadNextBtn")?.addEventListener("click", async () => { await loadNextFromQueue(); });
    document.getElementById("eaMarkPostedBtn")?.addEventListener("click", async () => { await markCurrentVehiclePosted(); });
    document.getElementById("eaRefreshSessionBtn")?.addEventListener("click", async () => { await refreshSessionState(); });

    document.getElementById("eaStartPostingCurrentBtn")?.addEventListener("click", async () => {
      let current = getCurrentVehicle();
      if (!current && currentScanResults.length) current = currentScanResults[0];
      await startPostingVehicle(current);
    });

    document.getElementById("eaStartPostingLoadedBtn")?.addEventListener("click", async () => {
      let current = getCurrentVehicle();
      if (!current && currentScanResults.length) current = currentScanResults[0];
      await startPostingVehicle(current);
    });

    document.querySelectorAll(".ea-add-queue-btn").forEach((button) => {
      button.onclick = async () => { await addToQueueByIndex(Number(button.getAttribute("data-index"))); };
    });

    document.querySelectorAll(".ea-load-now-btn").forEach((button) => {
      button.onclick = async () => { await loadNowByIndex(Number(button.getAttribute("data-index"))); };
    });

    document.querySelectorAll(".ea-start-post-btn").forEach((button) => {
      button.onclick = async () => { await startPostingVehicle(currentScanResults[Number(button.getAttribute("data-index"))]); };
    });
  }

  async function render() {
    const profile = getProfileFromSession();
    if (!shouldRenderScannerForLinkedDealer(profile, currentSession)) {
      removePanel();
      return;
    }

    const panel = await ensurePanel();
    if (!panel) return;

    const stats = getStats();
    const current = getCurrentVehicle();
    const accessActive = normalizeAccess(currentSession);

    panel.innerHTML = `
      <div style="padding:18px 18px 12px;border-bottom:1px solid rgba(255,255,255,.05);display:flex;justify-content:space-between;gap:12px;align-items:flex-start;">
        <div>
          <div style="font-size:11px;letter-spacing:.14em;color:#d4af37;font-weight:700;margin-bottom:6px;">ELEVATE AUTOMATION</div>
          <div style="font-size:16px;font-weight:800;line-height:1.15;">Inventory Scanner</div>
          <div style="font-size:12px;color:rgba(255,255,255,.62);margin-top:4px;">Profile-synced compliance listing builder</div>
        </div>
        <div style="background:${accessActive ? "#183a25" : "#4b2f2f"};color:${accessActive ? "#b8f3c7" : "#ffd5d5"};padding:7px 10px;border-radius:999px;font-size:11px;font-weight:700;">
          ${accessActive ? "READY" : "INACTIVE"}
        </div>
      </div>

      <div style="padding:16px;display:grid;gap:14px;">
        <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:14px;">
          <div style="font-size:14px;font-weight:800;color:#d4af37;margin-bottom:10px;">Profile + Compliance</div>
          <div style="font-size:12px;color:rgba(255,255,255,.8);display:grid;gap:6px;">
            <div><strong>Salesperson:</strong> ${escapeHtml(profile.full_name || "Not set")}</div>
            <div><strong>Dealer:</strong> ${escapeHtml(profile.dealer_name || "Not set")}</div>
            <div><strong>Province:</strong> ${escapeHtml(profile.province || "Not set")}</div>
            <div><strong>Scanner:</strong> ${escapeHtml(profile.scanner_type || "generic")}</div>
            <div><strong>Plan Limit:</strong> ${escapeHtml(String(getPostingLimit()))}</div>
            <div><strong>Posts Today:</strong> ${escapeHtml(String(getPostsToday()))}</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;">
          <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:12px;"><div style="font-size:10px;color:#d4af37;letter-spacing:.10em;font-weight:700;margin-bottom:6px;">QUEUE</div><div style="font-size:15px;font-weight:800;">${stats.queueCount}</div></div>
          <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:12px;"><div style="font-size:10px;color:#d4af37;letter-spacing:.10em;font-weight:700;margin-bottom:6px;">POSTED</div><div style="font-size:15px;font-weight:800;">${stats.postedCount}</div></div>
          <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:12px;"><div style="font-size:10px;color:#d4af37;letter-spacing:.10em;font-weight:700;margin-bottom:6px;">RESULTS</div><div style="font-size:15px;font-weight:800;">${stats.resultsCount}</div></div>
          <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:12px;padding:12px;"><div style="font-size:10px;color:#d4af37;letter-spacing:.10em;font-weight:700;margin-bottom:6px;">STALE</div><div style="font-size:15px;font-weight:800;">${stats.staleCount}</div></div>
        </div>

        <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:14px;">
          <div style="font-size:14px;font-weight:800;color:#d4af37;margin-bottom:10px;">Scanner Control</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <button id="eaRunScanBtn" style="border:none;border-radius:12px;padding:12px;background:linear-gradient(135deg,#d4af37,#b78d20);color:#101114;font-weight:800;cursor:pointer;">${isScanning ? "Scanning..." : "Run Scan"}</button>
            <button id="eaLoadNextBtn" style="border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px;background:#21242d;color:#fff;font-weight:700;cursor:pointer;">Load Next</button>
            <button id="eaStartPostingCurrentBtn" style="border:none;border-radius:12px;padding:12px;background:linear-gradient(135deg,#d4af37,#b78d20);color:#101114;font-weight:800;cursor:pointer;">Start Posting</button>
            <button id="eaRefreshSessionBtn" style="border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px;background:#21242d;color:#fff;font-weight:700;cursor:pointer;">Refresh Session</button>
          </div>
          <div style="display:grid;grid-template-columns:1fr;gap:10px;margin-top:10px;">
            <button id="eaMarkPostedBtn" style="border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px;background:#21242d;color:#fff;font-weight:700;cursor:pointer;">Mark Posted</button>
          </div>
          <div id="eaScannerStatus" style="margin-top:10px;font-size:12px;color:#d4af37;min-height:16px;">${escapeHtml(lastStatusMessage)}</div>
        </div>

        <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:14px;">
          <div style="font-size:14px;font-weight:800;color:#d4af37;margin-bottom:10px;">Current Loaded Vehicle</div>
          ${
            current ? `
              <div style="display:grid;gap:6px;font-size:12px;color:rgba(255,255,255,.86);">
                <div><strong>Title:</strong> ${escapeHtml(current.title || "—")}</div>
                <div><strong>Price:</strong> ${escapeHtml(money(current.price) || "—")}</div>
                <div><strong>KM:</strong> ${escapeHtml(km(current.kilometers || current.km) || "—")}</div>
                <div><strong>VIN:</strong> ${escapeHtml(current.vin || "—")}</div>
                <div><strong>Fuel:</strong> ${escapeHtml(current.fuelType || current.fuel_type || "—")}</div>
                <div><strong>Body:</strong> ${escapeHtml(current.bodyStyle || current.body_style || "—")}</div>
                <div><strong>Color:</strong> ${escapeHtml(current.exteriorColor || current.exterior_color || "—")}</div>
                <div><strong>Photos:</strong> ${escapeHtml(String((current.photoUrls || []).length || (current.coverPhotoUrl ? 1 : 0) || 0))}</div>
                <div><strong>Detail URL:</strong> ${escapeHtml(getLockedDetailUrl(current) || "—")}</div>
                <div style="display:grid;grid-template-columns:1fr;gap:8px;margin-top:8px;">
                  <button id="eaStartPostingLoadedBtn" style="border:none;border-radius:10px;padding:11px;background:linear-gradient(135deg,#d4af37,#b78d20);color:#101114;font-weight:800;cursor:pointer;">Start Posting This Vehicle</button>
                </div>
              </div>` : `<div style="font-size:12px;color:rgba(255,255,255,.62);">No current vehicle loaded.</div>`
          }
        </div>

        ${
          stats.staleCount ? `
            <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:14px;">
              <div style="font-size:14px;font-weight:800;color:#d4af37;margin-bottom:10px;">Stale Listing Review</div>
              <div style="display:grid;gap:8px;font-size:12px;color:rgba(255,255,255,.82);">
                ${getStaleVehicles().slice(0, 5).map((item) => `
                  <div style="background:#111318;border:1px solid rgba(255,255,255,.05);border-radius:10px;padding:10px;">
                    <div style="font-weight:700;">${escapeHtml(item.title || [item.year, item.make, item.model, item.trim].filter(Boolean).join(" "))}</div>
                    <div>VIN: ${escapeHtml(item.vin || "—")} | Stock: ${escapeHtml(item.stock || "—")}</div>
                    <div style="color:#f3c36b;">Flagged for delete/review</div>
                    <div style="color:rgba(255,255,255,.6);">Lifecycle: ${escapeHtml(item.lifecycle_status || "stale")}</div>
                  </div>`).join("")}
              </div>
            </div>` : ""
        }

        <div style="background:#171920;border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:14px;">
          <div style="font-size:14px;font-weight:800;color:#d4af37;margin-bottom:10px;">Scan Results</div>
          <div style="display:grid;gap:10px;">
            ${currentScanResults.length ? currentScanResults.map((vehicle, index) => buildResultCard(vehicle, index)).join("") : `<div style="font-size:12px;color:rgba(255,255,255,.62);">No scan results yet. Run scan to detect visible inventory vehicles.</div>`}
          </div>
        </div>
      </div>
    `;

    bindPanelActions();
  }

  async function boot() {
    if (!shouldRunOnThisPage()) {
      log("Inventory boot skipped on non-inventory page:", window.location.href);
      return;
    }

    currentSession = await getSession();
    await refreshWorkerPostedRegistry();

    const dashboardProfile = await getDashboardProfileCache();
    const sessionProfile = getProfileFromSession(currentSession);
    const mergedProfile = normalizeProfileShape({
      ...dashboardProfile,
      ...sessionProfile
    });

    persistPostingUsageSnapshot();
    resetQueueState({ clearCurrent: true });

    if (mergedProfile && (mergedProfile.full_name || mergedProfile.dealer_name)) {
      window.__EA_PROFILE = mergedProfile;
      setProfileCache(mergedProfile);

      try {
        await chrome.storage.local.set({
          ea_dashboard_profile_v1: mergedProfile,
          elevate_profile_snapshot: mergedProfile,
          ea_profile_snapshot: mergedProfile
        });
      } catch (error) {
        warn("boot profile storage sync failed:", error?.message || error);
      }
    }

    if (!shouldRenderScannerForLinkedDealer(mergedProfile, currentSession)) {
      removePanel();
      await syncPipelineToExtension(null);
      await triggerLifecycleSync({
        queue_count: 0,
        active_listings: Math.max(getPostedVehicles().length, workerPostedKeys.size)
      });
      log("Inventory boot skipped: current site does not match linked dealer.", {
        currentHost: getCurrentHost(),
        linkedHost: getLinkedDealerHost(mergedProfile, currentSession)
      });
      return;
    }

    currentScanResults = readStorage(STORAGE_KEYS.LAST_SCAN, []).map(aliasVehicleFields);
    await syncPipelineToExtension(getCurrentVehicle());
    await triggerLifecycleSync({
      queue_count: 0,
      active_listings: Math.max(getPostedVehicles().length, workerPostedKeys.size)
    });
    await safeRender();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
