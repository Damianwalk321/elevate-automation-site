// description-generator.js
// Elevate Automation Description Builder V2
// Compatibility wrapper that routes final listing copy through the compliance engine

(function () {
  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function digits(v) {
    return String(v || "").replace(/[^\d]/g, "");
  }

  function money(v) {
    const n = Number(digits(v));
    return Number.isFinite(n) && n > 0 ? `$${n.toLocaleString()}` : "";
  }

  function km(v) {
    const n = Number(digits(v));
    return Number.isFinite(n) && n >= 0 ? `${n.toLocaleString()} KM` : "";
  }

  function formatPhone(phone) {
    const raw = digits(phone);
    if (raw.length === 10) {
      return `${raw.slice(0, 3)}-${raw.slice(3, 6)}-${raw.slice(6)}`;
    }
    return clean(phone);
  }

  function normalizeProvince(value) {
    const raw = clean(value).toUpperCase();
    if (raw === "ALBERTA" || raw === "AB") return "AB";
    if (raw === "BRITISH COLUMBIA" || raw === "BC") return "BC";
    return raw;
  }

  function pick(...values) {
    for (const value of values) {
      const out = clean(value);
      if (out) return out;
    }
    return "";
  }

  function normalizeProfile(profile = {}, vehicle = {}) {
    return {
      full_name: pick(profile.full_name, profile.salesperson_name, vehicle?.profile?.full_name, vehicle?.salesperson_name),
      salesperson_name: pick(profile.salesperson_name, profile.full_name, vehicle?.profile?.full_name, vehicle?.salesperson_name),
      phone: pick(profile.phone, vehicle?.profile?.phone, vehicle?.dealer_phone),
      dealer_phone: pick(profile.dealer_phone, profile.phone, vehicle?.profile?.dealer_phone, vehicle?.dealer_phone),
      dealer_email: pick(profile.dealer_email, profile.email, vehicle?.profile?.dealer_email, vehicle?.dealer_email),
      email: pick(profile.email, profile.dealer_email, vehicle?.profile?.email, vehicle?.dealer_email),
      dealer_name: pick(profile.dealer_name, profile.dealership, vehicle?.profile?.dealer_name, vehicle?.dealer_name),
      dealership: pick(profile.dealership, profile.dealer_name, vehicle?.profile?.dealership, vehicle?.dealer_name),
      province: normalizeProvince(pick(profile.province, vehicle?.profile?.province)),
      listing_location: pick(profile.listing_location, profile.location, vehicle?.listing_location, vehicle?.location),
      location: pick(profile.location, profile.listing_location, vehicle?.location, vehicle?.listing_location),
      compliance_signature: pick(profile.compliance_signature)
    };
  }

  function featureList(vehicle = {}) {
    const raw = clean([
      vehicle.bodyStyle,
      vehicle.body_style,
      vehicle.fuelType,
      vehicle.fuel_type,
      vehicle.trim,
      vehicle.title,
      vehicle.rawText,
      vehicle.features?.join(" "),
      vehicle.specs?.features?.join(" ")
    ].join(" ")).toLowerCase();

    const feats = [];
    if (/heated seats/.test(raw)) feats.push("Heated Seats");
    if (/backup camera|rear camera/.test(raw)) feats.push("Backup Camera");
    if (/apple carplay|carplay/.test(raw)) feats.push("Apple CarPlay");
    if (/android auto/.test(raw)) feats.push("Android Auto");
    if (/blind spot/.test(raw)) feats.push("Blind Spot Monitoring");
    if (/sunroof|moonroof/.test(raw)) feats.push("Sunroof");
    if (/remote start/.test(raw)) feats.push("Remote Start");
    if (/bluetooth/.test(raw)) feats.push("Bluetooth");
    if (/navigation|nav/.test(raw)) feats.push("Navigation");
    if (/awd|4wd|4x4/.test(raw)) feats.push("AWD / 4x4");

    return [...new Set(feats)].slice(0, 5);
  }

  function buildFallbackDescription(vehicle = {}, profile = {}) {
    const p = normalizeProfile(profile, vehicle);

    const title = clean([vehicle.year, vehicle.make, vehicle.model, vehicle.trim].filter(Boolean).join(" "));
    const drivetrain = pick(vehicle.drivetrain, vehicle.specs?.drivetrain);
    const transmission = pick(vehicle.transmission, vehicle.specs?.transmission, /cvt/i.test(clean(vehicle.rawText)) ? "CVT" : "");
    const fuel = pick(vehicle.fuelType, vehicle.fuel_type, vehicle.specs?.fuel);
    const features = featureList(vehicle);

    const specLine = [transmission, drivetrain, fuel].filter(Boolean).join(" | ");
    const priceLine = money(vehicle.price);
    const kmLine = km(vehicle.kilometers || vehicle.km || vehicle.mileage);
    const phone = formatPhone(p.phone || p.dealer_phone);

    const blocks = [
      `${title}${drivetrain ? ` | ${drivetrain}` : ""} 🚗`,
      "",
      kmLine ? `• ${kmLine}` : "",
      specLine ? `• ${specLine}` : "",
      "",
      ...features.map((f) => `✔ ${f}`),
      features.length ? "" : "",
      "Vehicle is in good condition for its age and mileage.",
      "",
      priceLine ? `💰 ${priceLine}` : "",
      p.province === "AB"
        ? "Price does not include GST or applicable fees."
        : "Price does not include taxes or applicable fees.",
      "",
      p.full_name || p.salesperson_name,
      p.dealer_name || p.dealership,
      p.province === "AB" ? "AMVIC Licensed Dealer" : (p.compliance_signature || ""),
      phone ? `📞 ${phone}` : "",
      p.dealer_email ? `📩 ${p.dealer_email}` : "",
      "",
      "Message me for details or send your number to book a test drive."
    ].filter(Boolean);

    return blocks.join("\n").trim();
  }

  function buildDescription(vehicle = {}, profile = {}) {
    const p = normalizeProfile(profile, vehicle);

    if (window.ElevateComplianceEngine?.buildListing) {
      try {
        const listing = window.ElevateComplianceEngine.buildListing(vehicle, p);
        if (listing?.description) {
          return listing.description;
        }
      } catch (error) {
        console.warn("[Elevate Description Builder] Compliance engine build failed:", error);
      }
    }

    return buildFallbackDescription(vehicle, p);
  }

  window.ElevateDescriptionBuilder = {
    buildDescription
  };
})();
