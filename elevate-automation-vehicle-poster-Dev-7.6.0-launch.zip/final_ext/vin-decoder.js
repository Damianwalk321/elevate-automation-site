// vin-decoder.js
// Elevate Automation VIN Decoder V11
// Expanded make/year/body/fuel hints for intelligence layer

(function () {
  const LOG_PREFIX = "[Elevate VIN Decoder V11]";

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  const YEAR_MAP = {
    A: 2010, B: 2011, C: 2012, D: 2013, E: 2014,
    F: 2015, G: 2016, H: 2017, J: 2018, K: 2019,
    L: 2020, M: 2021, N: 2022, P: 2023, R: 2024,
    S: 2025, T: 2026
  };

  const WMI_MAP = {
    // Toyota / Lexus
    "2T1": "Toyota", "2T3": "Toyota", "4T1": "Toyota", "5TD": "Toyota", "5TF": "Toyota", "JTE": "Toyota", "JT3": "Toyota", "JTD": "Toyota",
    "2T2": "Lexus", "JTH": "Lexus",

    // Honda / Acura
    "1HG": "Honda", "2HG": "Honda", "JHM": "Honda", "5FN": "Honda",
    "19U": "Acura", "JH4": "Acura", "5J8": "Acura",

    // Ford / Lincoln
    "1FA": "Ford", "1FB": "Ford", "1FC": "Ford", "1FD": "Ford", "1FM": "Ford", "1FT": "Ford", "2FM": "Ford", "2FT": "Ford", "3FA": "Ford", "3FD": "Ford", "3FM": "Ford", "3FT": "Ford",
    "5LM": "Lincoln", "1LN": "Lincoln",

    // GM
    "1G1": "Chevrolet", "1GC": "Chevrolet", "2G1": "Chevrolet", "2GC": "Chevrolet", "3GC": "Chevrolet",
    "1GN": "Chevrolet", "3GN": "Chevrolet",
    "1GT": "GMC", "2GT": "GMC", "3GT": "GMC",
    "LRB": "Buick",
    "1GY": "Cadillac",

    // Ram / Dodge / Jeep / Chrysler
    "1C6": "Ram", "3C6": "Ram",
    "1C4": "Dodge", "2C4": "Dodge", "3C4": "Dodge",
    "1C3": "Chrysler", "2C3": "Chrysler",
    "1J4": "Jeep", "1C4J": "Jeep",

    // Mazda
    "JM1": "Mazda", "JM3": "Mazda",

    // Nissan / Infiniti
    "1N4": "Nissan", "1N6": "Nissan", "3N1": "Nissan", "JN1": "Nissan", "JN8": "Nissan",
    "JNK": "Infiniti", "5N1": "Infiniti",

    // Hyundai / Kia / Genesis
    "KMH": "Hyundai", "5NM": "Hyundai", "5NP": "Hyundai",
    "KNA": "Kia", "KND": "Kia", "KNDJ": "Kia",
    "KMT": "Genesis", "KMU": "Genesis",

    // Subaru
    "JF1": "Subaru", "JF2": "Subaru", "4S4": "Subaru",

    // VW / Audi / Porsche / BMW / Mercedes / Volvo / Mini
    "3VW": "Volkswagen", "WVW": "Volkswagen", "1VW": "Volkswagen",
    "WA1": "Audi", "WAU": "Audi", "TRU": "Audi",
    "WP0": "Porsche",
    "WBA": "BMW", "WBS": "BMW", "5UX": "BMW", "5YM": "BMW",
    "WDD": "Mercedes", "WDC": "Mercedes", "4JG": "Mercedes",
    "YV1": "Volvo", "YV4": "Volvo",
    "WMW": "Mini",

    // Mitsubishi
    "JA4": "Mitsubishi"
  };

  const BODY_HINTS_BY_MODEL = [
    { pattern: /\btundra|tacoma|silverado|colorado|sierra|f150|f-150|ram|1500\b/i, body: "Truck" },
    { pattern: /\bbronco sport|bronco|explorer|durango|outlander|blazer|envision|cx-5|cx5|atlas|venza|pilot|highlander|rav4|seltos|sportage|sorento|rogue|murano|pathfinder|taos|tiguan\b/i, body: "SUV" },
    { pattern: /\bcorolla|camry|civic|accord|mazda3|elantra|sentra|altima|malibu|wrx\b/i, body: "Sedan" },
    { pattern: /\boutback\b/i, body: "Wagon" },
    { pattern: /\bodyssey|sienna|pacifica\b/i, body: "Van" }
  ];

  function detectMakeFromVIN(vin) {
    const wmi3 = vin.slice(0, 3);
    const wmi4 = vin.slice(0, 4);

    return WMI_MAP[wmi4] || WMI_MAP[wmi3] || "";
  }

  function detectYearFromVIN(vin) {
    const code = vin[9];
    return YEAR_MAP[code] || "";
  }

  function detectFuelHint(vehicle) {
    const text = `${clean(vehicle.title)} ${clean(vehicle.model)} ${clean(vehicle.trim)}`.toLowerCase();

    if (/\bhybrid|phev|plug[- ]?in|prime\b/.test(text)) return "Hybrid";
    if (/\belectric|ev\b/.test(text)) return "Electric";
    if (/\bdiesel|tdi|duramax|ecodiesel|cummins\b/.test(text)) return "Diesel";
    return "";
  }

  function detectBodyHint(vehicle) {
    const text = `${clean(vehicle.title)} ${clean(vehicle.model)} ${clean(vehicle.trim)}`;
    for (const rule of BODY_HINTS_BY_MODEL) {
      if (rule.pattern.test(text)) return rule.body;
    }
    return "";
  }

  function decodeVIN(input) {
    const vehicle = { ...(input || {}) };
    const vin = clean(vehicle.vin || "").toUpperCase();

    if (!vin || vin.length !== 17) return vehicle;

    const make = detectMakeFromVIN(vin);
    const year = detectYearFromVIN(vin);
    const fuelHint = detectFuelHint(vehicle);
    const bodyHint = detectBodyHint(vehicle);

    if (!vehicle.make && make) vehicle.make = make;
    if (!vehicle.year && year) vehicle.year = String(year);

    if (!vehicle.fuel_type && fuelHint) {
      vehicle.fuel_type = fuelHint;
      vehicle.confidence = { ...(vehicle.confidence || {}), fuel: Math.max(Number(vehicle.confidence?.fuel || 0), 0.75) };
    }

    if (!vehicle.body_style && bodyHint) {
      vehicle.body_style = bodyHint;
      vehicle.confidence = { ...(vehicle.confidence || {}), body: Math.max(Number(vehicle.confidence?.body || 0), 0.7) };
    }

    vehicle.vin_meta = {
      ...(vehicle.vin_meta || {}),
      wmi: vin.slice(0, 3),
      year_code: vin[9] || "",
      serial: vin.slice(11),
      decoded_make: make || "",
      decoded_year: year || ""
    };

    return vehicle;
  }

  window.ElevateVINDecoder = {
    decodeVIN
  };

  log("Loaded");
})();