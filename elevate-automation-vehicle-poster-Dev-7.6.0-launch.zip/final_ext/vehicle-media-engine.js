(() => {
  const ENGINE_VERSION = 'V2.0.0';

  const BAD_IMAGE_KEYWORDS = [
    'logo',
    'logos',
    'dealerlogo',
    'brandlogo',
    'placeholder',
    'no-image',
    'noimage',
    'comingsoon',
    'coming-soon',
    'default',
    'spinner',
    'loading',
    'playbutton',
    'icon',
    'badge',
    'stock-image',
    'stockimage',
    'map',
    'button',
    'banner',
    'header',
    'footer'
  ];

  const GOOD_IMAGE_HINTS = [
    'inventory',
    'vehicle',
    'vehicles',
    'photo',
    'photos',
    'image',
    'images',
    'media',
    'gallery',
    'cdn',
    'unit',
    'vin',
    'img',
    'uploads'
  ];

  const GALLERY_SELECTORS = [
    '[data-gallery] img',
    '[class*="gallery"] img',
    '[class*="carousel"] img',
    '[class*="slider"] img',
    '[class*="swiper"] img',
    '[class*="slick"] img',
    '[class*="vehicle"] img',
    '[class*="inventory"] img',
    '[class*="media"] img',
    '[id*="gallery"] img',
    '[id*="carousel"] img',
    '[id*="slider"] img',
    'picture img',
    'img'
  ];

  const LINK_IMAGE_SELECTORS = [
    'a[href*=".jpg"]',
    'a[href*=".jpeg"]',
    'a[href*=".png"]',
    'a[href*=".webp"]'
  ];

  function log(...args) {
    console.log(`[ElevateMediaEngine ${ENGINE_VERSION}]`, ...args);
  }

  function warn(...args) {
    console.warn(`[ElevateMediaEngine ${ENGINE_VERSION}]`, ...args);
  }

  function safeString(v) {
    return typeof v === 'string' ? v.trim() : '';
  }

  function toAbsoluteUrl(url, baseUrl) {
    try {
      if (!url) return '';
      if (url.startsWith('data:')) return '';
      if (url.startsWith('blob:')) return '';
      return new URL(url, baseUrl).href;
    } catch {
      return '';
    }
  }

  function normalizeWhitespace(str) {
    return safeString(str).replace(/\s+/g, ' ').trim();
  }

  function decodeHtmlEntities(str) {
    try {
      const txt = document.createElement('textarea');
      txt.innerHTML = str;
      return txt.value;
    } catch {
      return str;
    }
  }

  function parseSrcset(srcset) {
    const raw = safeString(srcset);
    if (!raw) return [];

    return raw
      .split(',')
      .map(part => safeString(part).split(/\s+/)[0])
      .filter(Boolean);
  }

  function stripUrlNoise(url) {
    try {
      const u = new URL(url);
      // Keep common image sizing params only if needed.
      // For dedupe, remove fragment.
      u.hash = '';
      return u.href;
    } catch {
      return url;
    }
  }

  function getFilename(url) {
    try {
      const pathname = new URL(url).pathname || '';
      return pathname.split('/').pop() || '';
    } catch {
      return '';
    }
  }

  function hasBadKeyword(str) {
    const s = safeString(str).toLowerCase();
    if (!s) return false;
    return BAD_IMAGE_KEYWORDS.some(k => s.includes(k));
  }

  function hasGoodHint(str) {
    const s = safeString(str).toLowerCase();
    if (!s) return false;
    return GOOD_IMAGE_HINTS.some(k => s.includes(k));
  }

  function looksLikeVehicleImage(url) {
    const raw = safeString(url).toLowerCase();
    if (!raw) return false;

    if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(raw) && !hasGoodHint(raw)) {
      return false;
    }

    if (hasBadKeyword(raw)) {
      return false;
    }

    return true;
  }

  function scoreImageUrl(url) {
    const raw = safeString(url).toLowerCase();
    let score = 0;

    if (!raw) return score;

    if (/\.(jpg|jpeg|png|webp)(\?|$)/i.test(raw)) score += 20;
    if (hasGoodHint(raw)) score += 15;
    if (raw.includes('inventory')) score += 10;
    if (raw.includes('vehicle')) score += 10;
    if (raw.includes('gallery')) score += 8;
    if (raw.includes('vin')) score += 6;
    if (raw.includes('photo')) score += 6;
    if (raw.includes('image')) score += 4;
    if (raw.includes('thumb')) score -= 8;
    if (raw.includes('thumbnail')) score -= 10;
    if (raw.includes('logo')) score -= 100;
    if (raw.includes('placeholder')) score -= 100;
    if (raw.includes('no-image')) score -= 100;
    if (raw.includes('spinner')) score -= 100;

    const filename = getFilename(raw);
    if (filename && /^\d+\.(jpg|jpeg|png|webp)$/i.test(filename)) score += 4;

    return score;
  }

  function uniqueByNormalizedUrl(urls) {
    const seen = new Set();
    const out = [];

    for (const url of urls) {
      const clean = stripUrlNoise(url);
      if (!clean || seen.has(clean)) continue;
      seen.add(clean);
      out.push(clean);
    }

    return out;
  }
  
function getAdapterIdFromOptions(vehicle = {}, options = {}, profile = {}) {
  return String(
    options?.adapterId ||
    vehicle?.adapter_id ||
    vehicle?.scanner_type ||
    profile?.scanner_type ||
    window.ElevateScannerRouter?.getActiveAdapterId?.() ||
    "generic"
  ).trim().toLowerCase();
}
  function extractImageCandidatesFromImg(img, baseUrl) {
    const candidates = [];

    if (!img) return candidates;

    const attrs = [
      img.getAttribute('src'),
      img.getAttribute('data-src'),
      img.getAttribute('data-lazy'),
      img.getAttribute('data-original'),
      img.getAttribute('data-image'),
      img.getAttribute('data-full'),
      img.getAttribute('data-zoom-image'),
      img.getAttribute('data-large_image'),
      img.getAttribute('data-large-image'),
      img.getAttribute('data-srcset')
    ];

    const srcset = img.getAttribute('srcset');
    if (srcset) attrs.push(...parseSrcset(srcset));

    const dataSrcset = img.getAttribute('data-srcset');
    if (dataSrcset) attrs.push(...parseSrcset(dataSrcset));

    for (const val of attrs) {
      const abs = toAbsoluteUrl(safeString(val), baseUrl);
      if (abs) candidates.push(abs);
    }

    return candidates;
  }

  function extractImagesFromDom(doc, baseUrl) {
    const results = [];

    for (const selector of GALLERY_SELECTORS) {
      const imgs = Array.from(doc.querySelectorAll(selector));
      for (const img of imgs) {
        results.push(...extractImageCandidatesFromImg(img, baseUrl));
      }
    }

    for (const selector of LINK_IMAGE_SELECTORS) {
      const links = Array.from(doc.querySelectorAll(selector));
      for (const link of links) {
        const href = toAbsoluteUrl(link.getAttribute('href'), baseUrl);
        if (href) results.push(href);
      }
    }

    const ogImage =
      doc.querySelector('meta[property="og:image"]')?.getAttribute('content') ||
      doc.querySelector('meta[name="og:image"]')?.getAttribute('content');

    if (ogImage) {
      const abs = toAbsoluteUrl(ogImage, baseUrl);
      if (abs) results.push(abs);
    }

    return results;
  }

  function deepCollectStrings(value, bucket) {
    if (!value) return;
    if (typeof value === 'string') {
      bucket.push(value);
      return;
    }
    if (Array.isArray(value)) {
      for (const item of value) deepCollectStrings(item, bucket);
      return;
    }
    if (typeof value === 'object') {
      for (const key of Object.keys(value)) {
        deepCollectStrings(value[key], bucket);
      }
    }
  }

  function extractImagesFromJsonLd(doc, baseUrl) {
    const out = [];
    const scripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));

    for (const script of scripts) {
      const raw = safeString(script.textContent);
      if (!raw) continue;

      try {
        const data = JSON.parse(raw);
        const strings = [];
        deepCollectStrings(data, strings);

        for (const s of strings) {
          const decoded = decodeHtmlEntities(s);
          const matchUrls = decoded.match(/https?:\/\/[^\s"'<>]+/gi) || [];
          for (const u of matchUrls) {
            const abs = toAbsoluteUrl(u, baseUrl);
            if (abs) out.push(abs);
          }
        }
      } catch {
        // ignore broken JSON-LD
      }
    }

    return out;
  }

  function extractImagesFromScripts(doc, baseUrl) {
    const out = [];
    const scripts = Array.from(doc.querySelectorAll('script'));

    const regexes = [
      /https?:\/\/[^\s"'<>]+?\.(?:jpg|jpeg|png|webp)(?:\?[^\s"'<>]*)?/gi,
      /["'](\/[^"']+?\.(?:jpg|jpeg|png|webp)(?:\?[^"']*)?)["']/gi
    ];

    for (const script of scripts) {
      const text = safeString(script.textContent);
      if (!text) continue;

      for (const regex of regexes) {
        let match;
        while ((match = regex.exec(text)) !== null) {
          const candidate = match[1] || match[0];
          const abs = toAbsoluteUrl(candidate, baseUrl);
          if (abs) out.push(abs);
        }
      }
    }

    return out;
  }

  function filterAndRankImages(urls) {
    const ranked = uniqueByNormalizedUrl(urls)
      .map(url => ({
        url,
        score: scoreImageUrl(url)
      }))
      .filter(item => looksLikeVehicleImage(item.url) && item.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(item => item.url);

    return ranked;
  }

  async function fetchHtml(url) {
    const res = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store'
    });

    if (!res.ok) {
      throw new Error(`Failed to fetch detail page: ${res.status} ${res.statusText}`);
    }

    return await res.text();
  }

  function parseHtml(html) {
    return new DOMParser().parseFromString(html, 'text/html');
  }

  async function collectDetailPageImages({
    sourceUrl,
    html = '',
    maxImages = 20
  } = {}) {
    try {
      if (!sourceUrl) {
        warn('collectDetailPageImages called without sourceUrl');
        return [];
      }

      let pageHtml = html;
      if (!pageHtml) {
        pageHtml = await fetchHtml(sourceUrl);
      }

      const doc = parseHtml(pageHtml);

      const domImages = extractImagesFromDom(doc, sourceUrl);
      const jsonLdImages = extractImagesFromJsonLd(doc, sourceUrl);
      const scriptImages = extractImagesFromScripts(doc, sourceUrl);

      const combined = [
        ...domImages,
        ...jsonLdImages,
        ...scriptImages
      ];

      const filtered = filterAndRankImages(combined).slice(0, maxImages);

      log('collectDetailPageImages', {
        sourceUrl,
        domImages: domImages.length,
        jsonLdImages: jsonLdImages.length,
        scriptImages: scriptImages.length,
        finalImages: filtered.length
      });

      return filtered;
    } catch (err) {
      warn('collectDetailPageImages failed', sourceUrl, err);
      return [];
    }
  }

  async function collectVehicleImages(vehicle = {}, options = {}) {
const {
  maxImages = 20,
  fallbackImages = [],
  sourceNode = null,
  profile = {}
} = options;

const adapterId = getAdapterIdFromOptions(vehicle, options, profile);




try {
  if (window.ElevateDealerAdapters?.resolveCandidates) {
    const adapterCandidates = await window.ElevateDealerAdapters.resolveCandidates(
      vehicle,
      sourceNode,
      profile,
      adapterId
    );

    if (Array.isArray(adapterCandidates) && adapterCandidates.length) {
      const merged = uniqueByNormalizedUrl([
        ...adapterCandidates,
       ...(Array.isArray(fallbackImages) ? fallbackImages : [])
      ]);

      return merged.slice(0, options?.maxImages || 20);
    }
  }
} catch (error) {
  warn("adapter candidate resolution failed", adapterId, error);
}

    const vehicleUrl =
      safeString(vehicle.sourceUrl) ||
      safeString(vehicle.url) ||
      safeString(vehicle.link) ||
      safeString(vehicle.vehicleUrl);

    const seedImages = Array.isArray(vehicle.images) ? vehicle.images : [];
    const cardImage =
      safeString(vehicle.image) ||
      safeString(vehicle.photo) ||
      safeString(vehicle.thumbnail);

    const seeded = [
      ...seedImages,
      cardImage,
      ...fallbackImages
    ]
      .filter(Boolean)
      .map(url => toAbsoluteUrl(url, vehicleUrl || location.href))
      .filter(Boolean);

    let detailImages = [];
    if (vehicleUrl) {
      detailImages = await collectDetailPageImages({
        sourceUrl: vehicleUrl,
        maxImages
      });
    }

    const merged = filterAndRankImages([
      ...detailImages,
      ...seeded
    ]).slice(0, maxImages);

    return merged;
  }

  async function testCurrentPage() {
    const sourceUrl = location.href;
    const images = await collectDetailPageImages({ sourceUrl, maxImages: 20 });
    log('testCurrentPage result', images);
    return images;
  }

  window.ElevateMediaEngine = {
    version: ENGINE_VERSION,
    collectDetailPageImages,
    collectVehicleImages,
    testCurrentPage
  };

  log('loaded');
})();
