// compliance-profile-engine.js
// Elevate Automation Compliance + Profile Injection Engine V3
// Alberta / BC compliance enforcement + compliant listing/caption builder + auto-fix

(function () {
  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function lower(value) {
    return clean(value).toLowerCase();
  }

  function digits(value) {
    return String(value || "").replace(/[^\d]/g, "");
  }

  function normalizeProvince(value) {
    const raw = clean(value).toUpperCase();
    if (raw === "ALBERTA" || raw === "AB") return "AB";
    if (raw === "BRITISH COLUMBIA" || raw === "BC") return "BC";
    return raw;
  }

  function money(value) {
    const n = Number(digits(value));
    if (!n) return "";
    return `$${n.toLocaleString()}`;
  }

  function km(value) {
    const n = Number(digits(value));
    if (!n && n !== 0) return "";
    return n || n === 0 ? `${n.toLocaleString()} KM` : "";
  }

  function formatPhone(phone) {
    const raw = digits(phone);
    if (raw.length === 10) {
      return `${raw.slice(0, 3)}-${raw.slice(3, 6)}-${raw.slice(6)}`;
    }
    return clean(phone);
  }

  function pick(...values) {
    for (const value of values) {
      const out = clean(value);
      if (out) return out;
    }
    return "";
  }

  function buildVehicleKey(vehicle) {
    if (!vehicle) return "";

    const vin = clean(vehicle?.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(vehicle?.stock || vehicle?.stock_number || "");
    if (stock) return `STOCK:${stock}`;

    return [
      clean(vehicle?.year || ""),
      clean(vehicle?.make || ""),
      clean(vehicle?.model || ""),
      digits(vehicle?.price || ""),
      digits(vehicle?.km || vehicle?.kilometers || vehicle?.mileage || "")
    ].join("|");
  }

  function normalizeProfile(profile = {}) {
    const province = normalizeProvince(
      pick(profile.province, profile.compliance_zone, profile.compliance_mode)
    );

    const dealer_name = pick(profile.dealer_name, profile.dealership);
    const salesperson_name = pick(profile.salesperson_name, profile.full_name);
    const phone = pick(profile.phone, profile.dealer_phone);
    const dealer_phone = pick(profile.dealer_phone, profile.phone);
    const dealer_email = pick(profile.dealer_email, profile.email);
    const email = pick(profile.email, profile.dealer_email);
    const location = pick(profile.listing_location, profile.location, profile.city);

    const compliance_signature = pick(
      profile.compliance_signature,
      buildComplianceSignature({ province })
    );

    return {
      ...profile,
      province,
      dealer_name,
      dealership: dealer_name,
      salesperson_name,
      full_name: salesperson_name,
      phone,
      dealer_phone,
      dealer_email,
      email,
      listing_location: location,
      location,
      compliance_signature
    };
  }

  function buildComplianceSignature(profile = {}) {
    const province = normalizeProvince(profile?.province);
    if (province === "AB") return "AMVIC Licensed Dealer";
    if (province === "BC") return "Licensed Motor Dealer";
    return "";
  }

  function buildVehicleHeader(vehicle = {}) {
    const title = clean([
      vehicle?.year,
      vehicle?.make,
      vehicle?.model,
      vehicle?.trim || vehicle?.specs?.trim
    ].filter(Boolean).join(" "));

    const drivetrain = pick(vehicle?.drivetrain, vehicle?.specs?.drivetrain);
    return clean(`${title}${drivetrain ? ` | ${drivetrain}` : ""} 🚗`);
  }

  function inferFeatures(vehicle = {}) {
    const hay = lower([
      vehicle?.description,
      vehicle?.title,
      vehicle?.trim,
      vehicle?.rawText,
      vehicle?.bodyStyle,
      vehicle?.body_style,
      vehicle?.features?.join(" "),
      vehicle?.specs?.features?.join(" "),
      vehicle?.specs?.packages?.join(" ")
    ].join(" "));

    const features = [];

    if (/heated seats/.test(hay)) features.push("Heated Seats");
    if (/backup camera|rear camera/.test(hay)) features.push("Backup Camera");
    if (/apple carplay|carplay/.test(hay)) features.push("Apple CarPlay");
    if (/android auto/.test(hay)) features.push("Android Auto");
    if (/blind spot/.test(hay)) features.push("Blind Spot Monitoring");
    if (/sunroof|moonroof/.test(hay)) features.push("Sunroof");
    if (/remote start/.test(hay)) features.push("Remote Start");
    if (/bluetooth/.test(hay)) features.push("Bluetooth");
    if (/navigation|nav\b/.test(hay)) features.push("Navigation");
    if (/lane keep|lane assist/.test(hay)) features.push("Lane Assist");
    if (/adaptive cruise/.test(hay)) features.push("Adaptive Cruise Control");
    if (/\bawd\b|4wd|4x4/.test(hay)) features.push("AWD / 4x4");

    return [...new Set(features)].slice(0, 5);
  }

  function buildVehicleSpecs(vehicle = {}) {
    const mileage = km(vehicle?.km || vehicle?.kilometers || vehicle?.mileage);
    const transmission = pick(vehicle?.transmission, vehicle?.specs?.transmission);
    const drivetrain = pick(vehicle?.drivetrain, vehicle?.specs?.drivetrain);
    const fuel = pick(vehicle?.fuelType, vehicle?.fuel_type, vehicle?.specs?.fuel);
    const priceText = money(vehicle?.price);

    const lines = [];

    if (mileage) lines.push(`• ${mileage}`);

    const specRow = [transmission, drivetrain, fuel].filter(Boolean).join(" | ");
    if (specRow) lines.push(`• ${specRow}`);

    const features = Array.isArray(vehicle?.features) && vehicle.features.length
      ? vehicle.features.slice(0, 5)
      : inferFeatures(vehicle);

    if (features.length) {
      lines.push("");
      features.forEach((f) => lines.push(`✔ ${clean(f)}`));
    }

    if (priceText) {
      lines.push("");
      lines.push(`💰 ${priceText}`);
    }

    return lines;
  }

  function buildPriceDisclosure(profile = {}) {
    const p = normalizeProfile(profile);
    if (p.province === "AB") {
      return "Price does not include GST or applicable fees.";
    }
    return "Price does not include taxes or applicable fees.";
  }

  function buildProvinceComplianceLines(profile = {}) {
    const p = normalizeProfile(profile);
    const lines = [];

    if (p.province === "AB") {
      lines.push("Vehicle availability and pricing are subject to change.");
      lines.push("See dealer for full details, current pricing, and disclosure information.");
      if (p.compliance_signature) lines.push(p.compliance_signature);
      return lines;
    }

    if (p.province === "BC") {
      lines.push("Vehicle availability and pricing are subject to change.");
      lines.push("See dealer for full details and current vehicle disclosure information.");
      if (p.compliance_signature) lines.push(p.compliance_signature);
      return lines;
    }

    lines.push("Vehicle availability and pricing are subject to change.");
    return lines;
  }

  function buildDealerBlock(profile = {}) {
    const p = normalizeProfile(profile);
    const phone = formatPhone(p.phone || p.dealer_phone);

    return [
      p.salesperson_name || p.full_name,
      p.dealer_name || p.dealership,
      p.compliance_signature,
      phone ? `📞 ${phone}` : "",
      p.dealer_email ? `📩 ${p.dealer_email}` : ""
    ].filter(Boolean);
  }

  function getBlockedPhraseRules(province) {
    const base = [
      { pattern: /\bguaranteed\s+approval\b/i, code: "blocked_guaranteed_approval", reason: "Blocked phrase: guaranteed approval" },
      { pattern: /\beveryone\s+approved\b/i, code: "blocked_everyone_approved", reason: "Blocked phrase: everyone approved" },
      { pattern: /\b100%\s*approval\b/i, code: "blocked_100_approval", reason: "Blocked phrase: 100% approval" },
      { pattern: /\bno\s+credit\s+check\b/i, code: "blocked_no_credit_check", reason: "Blocked phrase: no credit check" },
      { pattern: /\bzero\s+down\b/i, code: "blocked_zero_down", reason: "Blocked phrase: zero down" },
      { pattern: /\binstant\s+approval\b/i, code: "blocked_instant_approval", reason: "Blocked phrase: instant approval" },
      { pattern: /\bdrive\s+away\s+today\b/i, code: "blocked_drive_away_today", reason: "Blocked phrase: drive away today" },
      { pattern: /\bpriced?\s+to\s+sell\b/i, code: "blocked_priced_to_sell", reason: "Blocked phrase: priced to sell" }
    ];

    if (province === "AB" || province === "BC") {
      base.push({
        pattern: /\bamvic\b(?!\s+licensed\s+dealer)/i,
        code: "blocked_bad_amvic_usage",
        reason: "AMVIC references must use approved dealer disclosure wording"
      });
    }

    return base;
  }

  function sanitizeTextForCompliance(text, profile = {}) {
    const p = normalizeProfile(profile);
    let out = String(text || "");

    const replacements = [
      [/\bguaranteed\s+approval\b/gi, "financing options available"],
      [/\beveryone\s+approved\b/gi, "message for financing options"],
      [/\b100%\s*approval\b/gi, "financing options available"],
      [/\bno\s+credit\s+check\b/gi, "message for financing details"],
      [/\bzero\s+down\b/gi, "message for financing options"],
      [/\binstant\s+approval\b/gi, "message for financing options"],
      [/\bdrive\s+away\s+today\b/gi, "message for current availability"],
      [/\bpriced?\s+to\s+sell\b/gi, "competitively priced"]
    ];

    for (const [pattern, replacement] of replacements) {
      out = out.replace(pattern, replacement);
    }

    out = out.replace(/\n{3,}/g, "\n\n").trim();

    const lines = out.split("\n").map((line) => clean(line)).filter(Boolean);
    const signature = p.compliance_signature || buildComplianceSignature(p);

    const hasDealer = p.dealer_name && lines.some((line) => lower(line).includes(lower(p.dealer_name)));
    const hasSales = p.salesperson_name && lines.some((line) => lower(line).includes(lower(p.salesperson_name)));
    const hasSignature = signature && lines.some((line) => lower(line) === lower(signature));

    if (p.dealer_name && !hasDealer) lines.push(p.dealer_name);
    if (p.salesperson_name && !hasSales) lines.push(p.salesperson_name);
    if (signature && !hasSignature) lines.push(signature);

    return lines.join("\n").trim();
  }

  function validateComplianceProfile(profile = {}) {
    const p = normalizeProfile(profile);

    if (!p.province) {
      return { valid: false, code: "missing_province", reason: "Missing compliance province" };
    }

    if (p.province !== "AB" && p.province !== "BC") {
      return { valid: false, code: "unsupported_province", reason: "Unsupported compliance province" };
    }

    if (!p.dealer_name) {
      return { valid: false, code: "missing_dealer_name", reason: "Missing dealership name" };
    }

    if (!p.salesperson_name) {
      return { valid: false, code: "missing_salesperson", reason: "Missing salesperson name" };
    }

    if (!p.phone && !p.dealer_phone && !p.email && !p.dealer_email) {
      return { valid: false, code: "missing_contact", reason: "Missing dealer contact info" };
    }

    if (!p.location) {
      return { valid: false, code: "missing_location", reason: "Missing listing location" };
    }

    if (!p.compliance_signature) {
      return { valid: false, code: "missing_signature", reason: "Missing compliance signature" };
    }

    return { valid: true };
  }

  function validateVehicleCompliance(vehicle = {}, profile = {}) {
    const p = normalizeProfile(profile);
    const profileCheck = validateComplianceProfile(p);
    if (!profileCheck.valid) return profileCheck;

    if (!clean(vehicle?.year)) return { valid: false, code: "missing_year", reason: "Missing vehicle year" };
    if (!clean(vehicle?.make)) return { valid: false, code: "missing_make", reason: "Missing vehicle make" };
    if (!clean(vehicle?.model)) return { valid: false, code: "missing_model", reason: "Missing vehicle model" };
    if (!digits(vehicle?.price)) return { valid: false, code: "missing_price", reason: "Missing vehicle price" };

    const listing = buildListing(vehicle, p, { skipValidation: true });
    const assembledText = [
      listing?.title || "",
      listing?.description || "",
      listing?.caption || ""
    ].join("\n");

    const blockedRules = getBlockedPhraseRules(p.province);
    for (const rule of blockedRules) {
      if (rule.pattern.test(assembledText)) {
        return {
          valid: false,
          code: rule.code,
          reason: rule.reason
        };
      }
    }

    return { valid: true };
  }

  function buildDescription(vehicle = {}, profile = {}) {
    const p = normalizeProfile(profile);
    const complianceCheck = validateComplianceProfile(p);
    if (!complianceCheck.valid) return "";

    const blocks = [
      buildVehicleHeader(vehicle),
      "",
      ...buildVehicleSpecs(vehicle),
      "",
      "Vehicle is in good condition for its age and mileage.",
      "",
      buildPriceDisclosure(p),
      "",
      ...buildDealerBlock(p),
      "",
      "📩 Message me for details or send your number to book a test drive."
    ];

    return sanitizeTextForCompliance(blocks.join("\n").trim(), p);
  }

  function buildCaption(vehicle = {}, profile = {}) {
    const p = normalizeProfile(profile);
    const complianceCheck = validateComplianceProfile(p);
    if (!complianceCheck.valid) return "";

    const priceText = money(vehicle?.price);
    const kmText = km(vehicle?.km || vehicle?.kilometers || vehicle?.mileage);
    const title = clean([
      vehicle?.year,
      vehicle?.make,
      vehicle?.model,
      vehicle?.trim || vehicle?.specs?.trim
    ].filter(Boolean).join(" "));
    const location = p.listing_location || p.location || "";
    const salesperson = p.salesperson_name || p.full_name || "our team";

    const lines = [
      title,
      [priceText, kmText].filter(Boolean).join(" • "),
      location ? `Located in ${location}` : "",
      `Message ${salesperson} for availability and details.`,
      p.compliance_signature
    ].filter(Boolean);

    return sanitizeTextForCompliance(lines.join("\n"), p);
  }

  function buildListing(vehicle = {}, profile = {}, opts = {}) {
    const p = normalizeProfile(profile);
    const title = clean([
      vehicle?.year,
      vehicle?.make,
      vehicle?.model,
      vehicle?.trim || vehicle?.specs?.trim
    ].filter(Boolean).join(" "));

    const description = buildDescription(vehicle, p);
    const caption = buildCaption(vehicle, p);
    const compliance_signature = p.compliance_signature || buildComplianceSignature(p);

    const payload = {
      vehicle_key: buildVehicleKey(vehicle),
      title,
      price: vehicle?.price || "",
      description,
      caption,
      compliance_signature,
      province: p.province,
      compliance: { valid: true }
    };

    if (!opts.skipValidation) {
      payload.compliance = validateVehicleCompliance(vehicle, p);
    }

    return payload;
  }

  window.ElevateComplianceEngine = {
    normalizeProvince,
    normalizeProfile,
    buildComplianceSignature,
    validateComplianceProfile,
    validateVehicleCompliance,
    sanitizeTextForCompliance,
    buildDescription,
    buildCaption,
    buildListing
  };
})();
