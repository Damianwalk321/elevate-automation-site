// vehicle-schema.js
// Elevate Automation Vehicle Schema V1

function createVehicle(){

return {

vehicle_type: "",
location: "",

year: "",
make: "",
model: "",
trim: "",

km: "",
price: "",

body_style: "",
fuel_type: "",
exterior_color: "",

vin: "",
stock: "",

photos: [],
source_url: "",

dealer_id: "",
dealer_name: "",

scan_timestamp: Date.now(),

confidence:{
body:0,
fuel:0,
color:0
}

}

}

window.ElevateVehicleSchema = {
createVehicle
}