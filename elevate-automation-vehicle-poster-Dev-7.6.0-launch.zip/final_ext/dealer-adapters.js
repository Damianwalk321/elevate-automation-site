

// dealer-adapters.js
// Elevate Automation Dealer Adapter Layer V4
// Hardened global adapter registry, platform heuristics, multi-dealer image extraction.

(function () {
  const LOG_PREFIX = "[Elevate Dealer Adapters V3]";
  const BaseDealerAdapter = window.ElevateAdapterBase?.BaseDealerAdapter;
  const Registry = window.ElevateAdapterRegistry;
  const Intelligence = window.ElevateAdapterIntelligence;
  const Telemetry = window.ElevateAdapterTelemetry;

  function log(...args) { console.log(LOG_PREFIX, ...args); }

  function record(type, payload) {
    try { Telemetry?.record?.(type, payload || {}); } catch {}
    try { Intelligence?.record?.({ type, ...(payload || {}) }); } catch {}
  }

  function warn(...args) { console.warn(LOG_PREFIX, ...args); }
  function clean(v) { return String(v || "").trim(); }
  function lower(v) { return clean(v).toLowerCase(); }

  function dedupe(list) {
    const seen = new Set();
    return (Array.isArray(list) ? list : []).filter((url) => {
      const value = clean(url);
      const key = value.split("?")[0];
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function getDomain(url) {
    try { return new URL(url).hostname.toLowerCase(); }
    catch { return ""; }
  }

  function getScannerKey(vehicle = {}, profile = {}) {
    return lower(vehicle.scanner_type || profile.scanner_type || "");
  }

  function toArray(value) {
    if (Array.isArray(value)) return value.filter(Boolean);
    if (typeof value === "string" && value.trim()) return [value.trim()];
    return [];
  }

  function collectImgUrls(root) {
    const urls = [];
    if (!root?.querySelectorAll) return urls;

    root.querySelectorAll("img").forEach((img) => {
      const alt = lower(img.getAttribute("alt") || "");
      const cls = lower(img.className || "");
      if (alt.includes("logo") || cls.includes("logo") || cls.includes("icon")) return;

      const attrs = [
        img.currentSrc,
        img.src,
        img.getAttribute("data-src"),
        img.getAttribute("data-lazy-src"),
        img.getAttribute("data-original"),
        img.getAttribute("data-image"),
        img.getAttribute("data-full"),
        img.getAttribute("data-zoom-image"),
        img.getAttribute("data-large"),
        img.getAttribute("data-large_image"),
        img.getAttribute("data-large-image")
      ];

      attrs.forEach((src) => {
        const value = clean(src || "");
        if (value) urls.push(value);
      });

      const srcset = clean(img.getAttribute("srcset") || "");
      if (srcset) {
        srcset.split(",").forEach((part) => {
          const candidate = clean(part.split(" ")[0]);
          if (candidate) urls.push(candidate);
        });
      }

      const dataSrcset = clean(img.getAttribute("data-srcset") || "");
      if (dataSrcset) {
        dataSrcset.split(",").forEach((part) => {
          const candidate = clean(part.split(" ")[0]);
          if (candidate) urls.push(candidate);
        });
      }
    });

    return dedupe(urls);
  }

  function collectBackgroundUrls(root) {
    const urls = [];
    if (!root?.querySelectorAll) return urls;

    root.querySelectorAll("[style]").forEach((el) => {
      const style = String(el.getAttribute("style") || "");
      const match = style.match(/url\(["']?([^"')]+)["']?\)/i);
      if (match?.[1]) urls.push(clean(match[1]));
    });

    return dedupe(urls);
  }

  function collectDataGalleryUrls(root) {
    const urls = [];
    if (!root?.querySelectorAll) return urls;

    root.querySelectorAll("[data-image], [data-full], [data-zoom-image], [data-large], [data-large_image], [data-large-image], [data-src]").forEach((el) => {
      [
        "data-image",
        "data-full",
        "data-zoom-image",
        "data-large",
        "data-large_image",
        "data-large-image",
        "data-src"
      ].forEach((attr) => {
        const val = clean(el.getAttribute(attr) || "");
        if (val) urls.push(val);
      });
    });

    return dedupe(urls);
  }

  function collectHrefImageUrls(root) {
    const urls = [];
    if (!root?.querySelectorAll) return urls;

    root.querySelectorAll("a[href]").forEach((a) => {
      const href = clean(a.getAttribute("href") || "");
      if (/\.(jpg|jpeg|png|webp)(\?|$)/i.test(href)) urls.push(href);
    });

    return dedupe(urls);
  }

  function findGalleryContainer(sourceNode, selectors) {
    const roots = [
      sourceNode,
      sourceNode?.closest?.(".vehicle-card, .inventory-card, .car-card, article, li, .result-item, .inventoryListItem"),
      document
    ].filter(Boolean);

    for (const root of roots) {
      for (const sel of toArray(selectors)) {
        const found = root?.querySelector?.(sel);
        if (found) return found;
      }
    }

    return null;
  }

  function collectFromRoots(roots = []) {
    const urls = [];
    roots.filter(Boolean).forEach((root) => {
      urls.push(...collectImgUrls(root));
      urls.push(...collectBackgroundUrls(root));
      urls.push(...collectDataGalleryUrls(root));
      urls.push(...collectHrefImageUrls(root));
    });
    return dedupe(urls);
  }

  function genericGallery(sourceNode) {
    const roots = [
      sourceNode,
      sourceNode?.parentElement,
      sourceNode?.closest?.(".vehicle-card, .inventory-card, .car-card, article, li, .result-item, .inventoryListItem"),
      document
    ];
    return collectFromRoots(roots);
  }

  function sargentToyotaAdapter(sourceNode) {
    const urls = [];
    const gallery = findGalleryContainer(sourceNode, [
      ".vehicle-gallery",
      ".inventory-gallery",
      ".swiper",
      ".slick-slider",
      "[class*='gallery']",
      "[class*='carousel']",
      "[class*='slider']"
    ]);

    if (gallery) {
      urls.push(...collectFromRoots([gallery]));
    }

    const card = sourceNode?.closest?.(".inventoryListItem, .vehicle-card, article, li") || sourceNode;
    if (card) urls.push(...collectFromRoots([card]));

    return dedupe(urls);
  }

  function dealerOnAdapter(sourceNode) {
    const roots = [
      document.querySelector(".vdp-gallery"),
      document.querySelector(".vehicle-photos"),
      document.querySelector(".image-gallery"),
      document.querySelector(".swiper-wrapper"),
      sourceNode,
      sourceNode?.closest?.(".vehicle-card, .inventory-card, article, li"),
      document
    ];
    return collectFromRoots(roots);
  }

  function dealerInspireAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".gallery-container",
      ".vehicle-gallery",
      ".inventory-gallery",
      ".slick-slider",
      ".swiper",
      ".slides",
      "[class*='gallery']",
      "[class*='carousel']"
    ]);

    return collectFromRoots([
      gallery,
      sourceNode,
      sourceNode?.closest?.(".vehicle-card, .inventory-card, article, li"),
      document
    ]);
  }

  function bmwKelownaAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".inventory-item-gallery",
      ".vehicle-gallery",
      ".swiper",
      ".slick-slider",
      ".listing-gallery",
      "[class*='gallery']"
    ]);

    return collectFromRoots([
      gallery,
      sourceNode,
      sourceNode?.closest?.(".inventory-item, .vehicle-card, article, li"),
      document
    ]);
  }

  function houseOfCarsAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".vehicle-card__gallery",
      ".inventory-gallery",
      ".listing-gallery",
      ".swiper",
      ".slick-slider",
      "[class*='gallery']"
    ]);

    return collectFromRoots([
      gallery,
      sourceNode,
      sourceNode?.closest?.(".vehicle-card, .inventory-item, article, li"),
      document
    ]);
  }

  function hasMarker(selectors = []) {
    return toArray(selectors).some((selector) => {
      try { return !!document.querySelector(selector); } catch { return false; }
    });
  }

  function currentDomain(ctx = {}) {
    return getDomain(
      ctx.vehicle?.source_url ||
      ctx.vehicle?.sourceUrl ||
      ctx.profile?.inventory_url ||
      ctx.profile?.dealer_website ||
      location.href
    );
  }

  function currentRouteId(ctx = {}) {
    return lower(ctx.routeId || "");
  }

  function domainIncludes(ctx = {}, parts = []) {
    const domain = currentDomain(ctx);
    return toArray(parts).some((part) => part && domain.includes(lower(part)));
  }

  function routeMatches(ctx = {}, ids = []) {
    const routeId = currentRouteId(ctx);
    return toArray(ids).some((id) => routeId === lower(id));
  }

  function profileScannerIncludes(ctx = {}, parts = []) {
    const scannerKey = getScannerKey(ctx.vehicle, ctx.profile);
    return toArray(parts).some((part) => scannerKey.includes(lower(part)));
  }

  function confidence(ok, strong = 0.9, weak = 0) {
    return ok ? strong : weak;
  }

  function isLikelyDealerCom(ctx = {}) {
    return domainIncludes(ctx, ["dealer.com", "drivedealerwebsites.com"]) ||
      hasMarker(["script[src*='dealer.com']", "link[href*='dealer.com']", "[data-ddc-name]", "[class*='ddc']"]);
  }

  function isLikelyDealerInspire(ctx = {}) {
    return domainIncludes(ctx, ["dealerinspire.com"]) ||
      hasMarker(["script[src*='dealerinspire']", "link[href*='dealerinspire']", "[class*='dealer-inspire']"]);
  }

  function isLikelyDealerOn(ctx = {}) {
    return domainIncludes(ctx, ["dealeron.com"]) ||
      hasMarker(["script[src*='dealeron']", "link[href*='dealeron']", "body[class*='dealeron']"]);
  }

  function isLikelyAutoJini(ctx = {}) {
    return domainIncludes(ctx, ["autojini.com"]) ||
      hasMarker(["script[src*='autojini']", "link[href*='autojini']", "body[class*='autojini']"]);
  }

  function isLikelyWordpressInventory() {
    return hasMarker(["meta[name='generator'][content*='WordPress']", "body[class*='wordpress']", "#wpadminbar"]) ||
      !!document.querySelector("link[href*='wp-content'], script[src*='wp-content']");
  }

  function dealerComAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".ddc-media-gallery",
      ".ddc-vehicle-image-wrapper",
      ".vehicle-image",
      ".inventory-gallery",
      ".swiper",
      ".slick-slider",
      "[class*='ddc'] [class*='gallery']"
    ]);
    return collectFromRoots([gallery, sourceNode, sourceNode?.closest?.(".vehicle-card, .inventory-card, .inventoryListItem, article, li"), document]);
  }

  function autoJiniAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".aj-gallery",
      ".aj-vehicle-gallery",
      ".vehicle-gallery",
      ".inventory-gallery",
      ".swiper",
      ".slick-slider",
      "[class*='autojini'] [class*='gallery']"
    ]);
    return collectFromRoots([gallery, sourceNode, sourceNode?.closest?.(".vehicle-card, .inventory-card, .inventory-item, article, li"), document]);
  }

  function wordpressInventoryAdapter(sourceNode) {
    const gallery = findGalleryContainer(sourceNode, [
      ".inventory-gallery",
      ".listing-gallery",
      ".vehicle-gallery",
      ".gallery",
      ".swiper",
      ".slick-slider",
      "[class*='inventory'] [class*='gallery']"
    ]);
    return collectFromRoots([gallery, sourceNode, sourceNode?.closest?.(".vehicle-card, .inventory-card, .inventory-item, article, li"), document]);
  }

  class GenericAdapter extends BaseDealerAdapter {
    static id = "generic";
    static priority = 1;
    static canHandle() { return { ok: true, confidence: 0.2 }; }
    resolveCandidates(vehicle = {}, sourceNode = null) { return genericGallery(sourceNode); }
  }

  class SargentToyotaAdapter extends BaseDealerAdapter {
    static id = "sargenttoyota";
    static priority = 100;
    static canHandle(ctx = {}) {
      const scannerKey = getScannerKey(ctx.vehicle, ctx.profile);
      const domain = getDomain(ctx.vehicle?.source_url || ctx.vehicle?.sourceUrl || ctx.profile?.inventory_url || ctx.profile?.dealer_website || location.href);
      const routeId = lower(ctx.routeId || "");
      const ok = scannerKey.includes("sargenttoyota") || fallbackDomain.includes("sargenttoyota") || routeId === "sargenttoyota";
      return { ok, confidence: ok ? 0.98 : 0 };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return sargentToyotaAdapter(sourceNode); }
  }

  class DealerOnAdapter extends BaseDealerAdapter {
    static id = "dealeron";
    static priority = 80;
    static canHandle(ctx = {}) {
      const ok = routeMatches(ctx, ["dealeron"]) || isLikelyDealerOn(ctx);
      return { ok, confidence: confidence(ok, 0.92) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return dealerOnAdapter(sourceNode); }
  }

  class DealerInspireAdapterClass extends BaseDealerAdapter {
    static id = "dealerinspire";
    static priority = 80;
    static canHandle(ctx = {}) {
      const ok = routeMatches(ctx, ["dealerinspire"]) || isLikelyDealerInspire(ctx);
      return { ok, confidence: confidence(ok, 0.92) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return dealerInspireAdapter(sourceNode); }
  }

  class BmwKelownaAdapterClass extends BaseDealerAdapter {
    static id = "bmw-kelowna";
    static priority = 75;
    static canHandle(ctx = {}) {
      const ok = domainIncludes(ctx, ["bmwkelowna", "bmw-kelowna"]) || routeMatches(ctx, ["bmw-kelowna"]);
      return { ok, confidence: confidence(ok, 0.9) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return bmwKelownaAdapter(sourceNode); }
  }

  class HouseOfCarsAdapterClass extends BaseDealerAdapter {
    static id = "houseofcars";
    static priority = 75;
    static canHandle(ctx = {}) {
      const ok = domainIncludes(ctx, ["houseofcars"]) || routeMatches(ctx, ["houseofcars"]);
      return { ok, confidence: confidence(ok, 0.9) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return houseOfCarsAdapter(sourceNode); }
  }

  class DealerComAdapterClass extends BaseDealerAdapter {
    static id = "dealercom";
    static priority = 78;
    static canHandle(ctx = {}) {
      const ok = routeMatches(ctx, ["dealercom"]) || isLikelyDealerCom(ctx);
      return { ok, confidence: confidence(ok, 0.88) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return dealerComAdapter(sourceNode); }
  }

  class AutoJiniAdapterClass extends BaseDealerAdapter {
    static id = "autojini";
    static priority = 76;
    static canHandle(ctx = {}) {
      const ok = routeMatches(ctx, ["autojini"]) || isLikelyAutoJini(ctx);
      return { ok, confidence: confidence(ok, 0.87) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return autoJiniAdapter(sourceNode); }
  }

  class WordpressInventoryAdapterClass extends BaseDealerAdapter {
    static id = "wordpress-inventory";
    static priority = 55;
    static canHandle(ctx = {}) {
      const ok = routeMatches(ctx, ["wordpress-inventory"]) || (isLikelyWordpressInventory() && !isLikelyDealerInspire(ctx) && !isLikelyDealerOn(ctx) && !isLikelyDealerCom(ctx));
      return { ok, confidence: confidence(ok, 0.74) };
    }
    resolveCandidates(vehicle = {}, sourceNode = null) { return wordpressInventoryAdapter(sourceNode); }
  }

  function registerBuiltIns() {
    if (!Registry?.register || !BaseDealerAdapter) {
      warn("Adapter base/registry missing. Falling back to static adapter map.");
      return;
    }
    [
      GenericAdapter,
      SargentToyotaAdapter,
      DealerOnAdapter,
      DealerInspireAdapterClass,
      DealerComAdapterClass,
      AutoJiniAdapterClass,
      WordpressInventoryAdapterClass,
      BmwKelownaAdapterClass,
      HouseOfCarsAdapterClass
    ].forEach((Adapter) => Registry.register(new Adapter()));
  }

  registerBuiltIns();

  const STATIC_ADAPTERS = {
    generic: { id: "generic", priority: 1, resolveCandidates: (vehicle = {}, sourceNode = null) => genericGallery(sourceNode) },
    sargenttoyota: { id: "sargenttoyota", priority: 100, resolveCandidates: (vehicle = {}, sourceNode = null) => sargentToyotaAdapter(sourceNode) },
    dealeron: { id: "dealeron", priority: 80, resolveCandidates: (vehicle = {}, sourceNode = null) => dealerOnAdapter(sourceNode) },
    dealerinspire: { id: "dealerinspire", priority: 80, resolveCandidates: (vehicle = {}, sourceNode = null) => dealerInspireAdapter(sourceNode) },
    dealercom: { id: "dealercom", priority: 78, resolveCandidates: (vehicle = {}, sourceNode = null) => dealerComAdapter(sourceNode) },
    autojini: { id: "autojini", priority: 76, resolveCandidates: (vehicle = {}, sourceNode = null) => autoJiniAdapter(sourceNode) },
    "wordpress-inventory": { id: "wordpress-inventory", priority: 55, resolveCandidates: (vehicle = {}, sourceNode = null) => wordpressInventoryAdapter(sourceNode) },
    "bmw-kelowna": { id: "bmw-kelowna", priority: 75, resolveCandidates: (vehicle = {}, sourceNode = null) => bmwKelownaAdapter(sourceNode) },
    houseofcars: { id: "houseofcars", priority: 75, resolveCandidates: (vehicle = {}, sourceNode = null) => houseOfCarsAdapter(sourceNode) }
  };

  function getStaticAdapterById(id = "generic") {
    return STATIC_ADAPTERS[lower(id)] || STATIC_ADAPTERS.generic;
  }

  function resolveAdapter(vehicle = {}, profile = {}, routeId = "") {
    const forcedRoute = lower(routeId || "");
    const domain = currentDomain({ vehicle, profile });
    const preferred = lower(Intelligence?.getPreferredAdapter?.(domain) || '');
    if (forcedRoute && STATIC_ADAPTERS[forcedRoute]) return STATIC_ADAPTERS[forcedRoute];
    if (preferred && STATIC_ADAPTERS[preferred]) return STATIC_ADAPTERS[preferred];

    if (Registry?.resolve) {
      const ranked = Registry.resolve({ vehicle, profile, routeId: forcedRoute, domain });
      if (ranked.length) return ranked[0].adapter;
    }

    const scannerKey = getScannerKey(vehicle, profile);
    const fallbackDomain = getDomain(vehicle.source_url || vehicle.sourceUrl || profile.inventory_url || profile.dealer_website || "");

    if (scannerKey.includes("sargenttoyota") || fallbackDomain.includes("sargenttoyota")) return STATIC_ADAPTERS.sargenttoyota;
    if (isLikelyDealerOn({ vehicle, profile, routeId: forcedRoute }) || fallbackDomain.includes("dealeron")) return STATIC_ADAPTERS.dealeron;
    if (isLikelyDealerInspire({ vehicle, profile, routeId: forcedRoute }) || fallbackDomain.includes("dealerinspire")) return STATIC_ADAPTERS.dealerinspire;
    if (isLikelyDealerCom({ vehicle, profile, routeId: forcedRoute })) return STATIC_ADAPTERS.dealercom;
    if (isLikelyAutoJini({ vehicle, profile, routeId: forcedRoute })) return STATIC_ADAPTERS.autojini;
    if (fallbackDomain.includes("bmwkelowna")) return STATIC_ADAPTERS["bmw-kelowna"];
    if (fallbackDomain.includes("houseofcars")) return STATIC_ADAPTERS.houseofcars;
    if (isLikelyWordpressInventory()) return STATIC_ADAPTERS["wordpress-inventory"];

    return STATIC_ADAPTERS.generic;
  }

  function listAdapters() {
    if (Registry?.list) {
      return Registry.list().map((item) => item.id);
    }
    return Object.keys(STATIC_ADAPTERS);
  }

  window.ElevateDealerAdapters = {
    getAdapterById(id = "generic") {
      if (Registry?.getById) return Registry.getById(id) || getStaticAdapterById(id);
      return getStaticAdapterById(id);
    },
    resolveAdapter,
    listAdapters,
    async resolveCandidates(vehicle = {}, sourceNode = null, profile = {}, routeId = "") {
      const adapter = resolveAdapter(vehicle, profile, routeId);
      const domain = currentDomain({ vehicle, profile }) || location.hostname;
      const startedAt = Date.now();
      try {
        const urls = adapter?.resolveCandidates?.(vehicle, sourceNode, profile, routeId) || [];
        const deduped = dedupe(urls);
        log("adapter", adapter?.id || "unknown", "candidates", deduped.length);
        record('candidate_resolution', {
          domain,
          adapter: adapter?.id || 'unknown',
          routeId,
          count: deduped.length,
          durationMs: Date.now() - startedAt,
          success: deduped.length > 0,
          confidence: deduped.length ? 0.8 : 0.2,
          meta: { sourceUrl: vehicle?.source_url || vehicle?.sourceUrl || '' }
        });
        return deduped;
      } catch (error) {
        warn("adapter resolveCandidates failed", adapter?.id || "unknown", error);
        record('scan_failure', {
          domain,
          adapter: adapter?.id || 'unknown',
          routeId,
          reason: error?.message || 'candidate_resolution_failed',
          durationMs: Date.now() - startedAt
        });
        const fallback = STATIC_ADAPTERS.generic.resolveCandidates(vehicle, sourceNode, profile, routeId);
        const dedupedFallback = dedupe(fallback);
        record('candidate_resolution', {
          domain,
          adapter: 'generic',
          routeId,
          count: dedupedFallback.length,
          durationMs: Date.now() - startedAt,
          success: dedupedFallback.length > 0,
          confidence: dedupedFallback.length ? 0.45 : 0.1,
          reason: 'generic_fallback'
        });
        return dedupedFallback;
      }
    }
  };
})();
