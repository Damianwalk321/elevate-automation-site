// marketplace-controller.js
// Elevate Automation Marketplace Controller V2
// Prepared payload loading + lifecycle tracking + repost-safe post registration

(function () {
  const PAYLOAD_KEY = "ea_prepared_vehicle";
  const QUEUE_KEY = "ea_inventory_queue_v12";
  const POSTED_KEY = "ea_inventory_posted_v12";

  function log(...args) {
    console.log("[Elevate Marketplace Controller]", ...args);
  }

  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function read(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }

  function remove(key) {
    try {
      localStorage.removeItem(key);
    } catch {}
  }

  function vehicleKey(v) {
    if (v?.vin) return `vin:${clean(v.vin).toUpperCase()}`;
    if (v?.stock) return `stock:${clean(v.stock).toUpperCase()}`;
    return [v?.year, v?.make, v?.model, v?.trim, v?.price].map(clean).join("|");
  }

  function getPreparedVehicle() {
    return read(PAYLOAD_KEY, null);
  }

  function setPreparedVehicle(vehicle) {
    write(PAYLOAD_KEY, vehicle);
  }

  function clearPreparedVehicle() {
    remove(PAYLOAD_KEY);
  }

  function getQueue() {
    return read(QUEUE_KEY, []);
  }

  function setQueue(q) {
    write(QUEUE_KEY, Array.isArray(q) ? q : []);
  }

  function getPosted() {
    return read(POSTED_KEY, []);
  }

  function setPosted(list) {
    write(POSTED_KEY, Array.isArray(list) ? list : []);
  }

  function isPosted(vehicle) {
    const key = vehicleKey(vehicle);
    return getPosted().some((item) => vehicleKey(item) === key);
  }

  function getNextQueuedVehicle() {
    const queue = getQueue();
    if (!queue.length) return null;

    while (queue.length) {
      const candidate = queue.shift();
      if (!isPosted(candidate)) {
        setQueue(queue);
        return candidate;
      }
    }

    setQueue(queue);
    return null;
  }

  function registerPost(vehicle) {
    if (!vehicle) return;

    const posted = getPosted();
    const key = vehicleKey(vehicle);

    if (!posted.some((item) => vehicleKey(item) === key)) {
      posted.push({
        ...vehicle,
        posted_at: Date.now()
      });
      setPosted(posted);
    }

    const queue = getQueue().filter((item) => vehicleKey(item) !== key);
    setQueue(queue);
  }

  function recordLifecycle(event, data = {}) {
    const record = {
      time: Date.now(),
      event,
      ...data
    };

    try {
      let history = read("ea_post_history", []);
      history.push(record);
      if (history.length > 300) history = history.slice(-300);
      write("ea_post_history", history);
    } catch {}
  }

  function loadPreparedVehicle() {
    const v = getPreparedVehicle();

    if (!v) {
      log("No prepared vehicle payload");
      return null;
    }

    if (isPosted(v)) {
      recordLifecycle("prepared_vehicle_blocked_already_posted", {
        vin: v.vin,
        stock: v.stock
      });
      clearPreparedVehicle();
      window.__EA_CURRENT_MARKETPLACE_VEHICLE = null;
      return null;
    }

    window.__EA_CURRENT_MARKETPLACE_VEHICLE = v;

    recordLifecycle("vehicle_loaded", {
      vin: v.vin,
      stock: v.stock
    });

    return v;
  }

  function loadNextQueuedVehicle() {
    const next = getNextQueuedVehicle();

    if (!next) {
      log("Queue empty or all remaining vehicles already posted");
      return null;
    }

    setPreparedVehicle(next);
    window.__EA_CURRENT_MARKETPLACE_VEHICLE = next;

    recordLifecycle("queue_vehicle_loaded", {
      vin: next.vin,
      stock: next.stock
    });

    return next;
  }

  function markPosted() {
    const v = window.__EA_CURRENT_MARKETPLACE_VEHICLE || getPreparedVehicle();
    if (!v) return;

    registerPost(v);

    recordLifecycle("vehicle_posted", {
      vin: v.vin,
      stock: v.stock
    });

    clearPreparedVehicle();
    window.__EA_CURRENT_MARKETPLACE_VEHICLE = null;
  }

  function getCurrentVehicle() {
    return window.__EA_CURRENT_MARKETPLACE_VEHICLE || getPreparedVehicle();
  }

  function expose() {
    window.ElevateMarketplaceController = {
      getCurrentVehicle,
      loadPreparedVehicle,
      loadNextQueuedVehicle,
      markPosted,
      recordLifecycle,
      isPosted
    };
  }

  function boot() {
    if (!location.href.includes("facebook.com/marketplace")) return;

    log("Controller boot");
    expose();
    loadPreparedVehicle();
  }

  boot();
})();