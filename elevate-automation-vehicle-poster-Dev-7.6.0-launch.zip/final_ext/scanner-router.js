// scanner-router.js
// Elevate Automation Scanner Router V8
// Self-learning multi-dealer detection engine

(function () {
  const LOG_PREFIX = "[Elevate Scanner Router V8]";
  const MAX_CANDIDATES = 500;

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function clean(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function digits(value) {
    return String(value || "").replace(/[^\d]/g, "");
  }

  function lower(value) {
    return clean(value).toLowerCase();
  }

  function asArray(value) {
    if (Array.isArray(value)) return value.filter(Boolean);
    if (typeof value === "string" && value.trim()) return [value.trim()];
    return [];
  }

  function safeText(node) {
    return clean(node?.innerText || node?.textContent || "");
  }

  function safeAttr(node, name) {
    return clean(node?.getAttribute?.(name) || "");
  }

  function safeHostname(input) {
    try {
      return new URL(input).hostname.replace(/^www\./, "").toLowerCase();
    } catch {
      return clean(input)
        .replace(/^https?:\/\//i, "")
        .replace(/^www\./i, "")
        .split("/")[0]
        .toLowerCase();
    }
  }

  function safePath(input) {
    try {
      return new URL(input).pathname.toLowerCase();
    } catch {
      return String(window.location.pathname || "").toLowerCase();
    }
  }

  function safeQueryAll(root, selector) {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch {
      return [];
    }
  }

  function firstNode(root, selectors) {
    for (const selector of asArray(selectors)) {
      const found = safeQueryAll(root, selector);
      if (found.length) return found[0];
    }
    return null;
  }

  function normalizeRawText(text) {
    return clean(
      String(text || "")
        .replace(/\bfinance it!?/gi, " ")
        .replace(/\bnew arrivals?\b/gi, " ")
        .replace(/\bgreat value\b/gi, " ")
        .replace(/\bpromotions?\b/gi, " ")
        .replace(/\bcertified\b/gi, " ")
        .replace(/\bcarfax\b/gi, " ")
        .replace(/\+\s*taxes?\s*&?\s*licenses?/gi, " ")
        .replace(/\bwas\s+\$?[\d,]+/gi, " ")
        .replace(/\s+/g, " ")
    );
  }

  function hasYear(text) {
    return /\b(19|20)\d{2}\b/.test(text || "");
  }

  function extractVIN(text) {
    const match = clean(text).match(/\b([A-HJ-NPR-Z0-9]{17})\b/i);
    return match ? match[1].toUpperCase() : "";
  }

  function extractStock(text) {
    const match =
      clean(text).match(/stock\s*#?\s*[:\-]?\s*([A-Za-z0-9\-]+)/i) ||
      clean(text).match(/stk\s*#?\s*[:\-]?\s*([A-Za-z0-9\-]+)/i) ||
      clean(text).match(/stock number\s*[:\-]?\s*([A-Za-z0-9\-]+)/i);
    return match ? clean(match[1]) : "";
  }

  function extractPrice(text) {
    const raw = clean(text);
    const matches = raw.match(/\$[\d,]+/g) || [];
    const nums = matches
      .map((m) => Number(digits(m)))
      .filter((n) => Number.isFinite(n) && n >= 1000 && n <= 250000);

    if (nums.length) return nums[0];

    const loose = [...raw.matchAll(/\b(\d{1,3}(?:,\d{3}){1,2})\b/g)]
      .map((m) => Number(digits(m[1])))
      .filter((n) => Number.isFinite(n) && n >= 1000 && n <= 250000);

    return loose.length ? loose[0] : null;
  }

  function extractKm(text) {
    const matches = [...clean(text).matchAll(/([\d,]{1,7})\s*(km|kms|kilometres|kilometers|miles)\b/gi)];
    const nums = matches
      .map((m) => Number(digits(m[1])))
      .filter((n) => Number.isFinite(n) && n >= 0 && n <= 500000);

    return nums.length ? nums[0] : null;
  }

  function extractTitle(text) {
    const raw = normalizeRawText(text);
    const lines = raw.split(/\n+/).map(clean).filter(Boolean);

    for (const line of lines) {
      if (hasYear(line) && line.length >= 8 && line.length <= 110) {
        return clean(
          line
            .replace(/\bin\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?$/i, "")
            .replace(/\bstock\s*[:#-].*$/i, "")
            .replace(/\bvin\s*[:#-].*$/i, "")
            .replace(/\+\s*taxes?\s*&?\s*licenses?/gi, "")
        );
      }
    }

    const match = raw.match(/\b((?:19|20)\d{2}\s+[A-Za-z0-9&.\-]+\s+[A-Za-z0-9&.\- ]{1,70})\b/i);
    return match ? clean(match[1]) : "";
  }

  function getSession() {
    return window.__EA_EXTENSION_SESSION || null;
  }

  function getScannerConfig() {
    return getSession()?.scanner_config || {};
  }

  function getScannerType() {
    const session = getSession();
    return clean(
      session?.scanner_config?.scanner_type ||
      session?.dealership?.scanner_type ||
      "generic"
    ).toLowerCase();
  }

  function buildContext() {
    const session = getSession();
    return {
      host: safeHostname(window.location.href),
      path: safePath(window.location.href),
      scannerType: getScannerType(),
      hasConfiguredSelectors: asArray(session?.scanner_config?.card_selectors).length > 0,
      dealershipName: clean(session?.dealership?.name || "")
    };
  }

  const ROUTE_ALIASES = {
    sargenttoyota: "sargenttoyota",
    seansargenttoyota: "sargenttoyota",
    bmwkelowna: "bmw-kelowna",
    houseofcars: "houseofcars",
    dealeron: "dealeron",
    dealerinspire: "dealerinspire",
    generic: "generic"
  };

  const ROUTES = [
    {
      id: "sargenttoyota",
      adapterId: "sargenttoyota",
      scannerType: "sargenttoyota",
      match: (ctx) => ctx.host.includes("sargenttoyota.ca"),
      cardSelectors: [
        ".inventoryListItem",
        ".inventory-item",
        ".result-item",
        ".vehicle",
        ".item",
        ".grid-item",
        ".col",
        "article",
        "li"
      ]
    },
    {
      id: "bmw-kelowna",
      adapterId: "bmw-kelowna",
      scannerType: "bmwkelowna",
      match: (ctx) =>
        ctx.host.includes("bmwkelowna") ||
        (ctx.host.includes("bmw") && ctx.host.includes("kelowna")),
      cardSelectors: [
        ".inventory-item",
        ".vehicle-card",
        ".result-item",
        ".listing-item",
        ".grid-item",
        "article",
        "li"
      ]
    },
    {
      id: "houseofcars",
      adapterId: "houseofcars",
      scannerType: "houseofcars",
      match: (ctx) => ctx.host.includes("houseofcars"),
      cardSelectors: [
        ".vehicle-card",
        ".inventory-item",
        ".listing-item",
        ".result-item",
        ".car-item",
        ".grid-item",
        "article",
        "li"
      ]
    },
    {
      id: "generic",
      adapterId: "generic",
      scannerType: "generic",
      match: () => true,
      cardSelectors: [
        ".vehicle-card",
        ".inventory-card",
        ".inventory-item",
        ".vehicle-item",
        ".result-item",
        ".listing-item",
        ".grid-item",
        "[data-vehicle-id]",
        "article",
        "li",
        "div"
      ]
    }
  ];

  function resolveRoute() {
    const ctx = buildContext();
    const forcedScannerType = clean(ROUTE_ALIASES[ctx.scannerType] || ctx.scannerType || "generic");

    const forced = ROUTES.find(
      (route) => clean(route.id) === forcedScannerType && forcedScannerType !== "generic"
    );
    if (forced) return forced;

    return ROUTES.find((route) => route.match(ctx)) || ROUTES[ROUTES.length - 1];
  }
  function getActiveRouteId() {
  return resolveRoute()?.id || "generic";
}

function getActiveAdapterId() {
  const route = resolveRoute();
  return clean(route?.adapterId || route?.id || "generic").toLowerCase();
}

  function dedupeElements(elements) {
    const seen = new Set();
    const out = [];

    for (const el of elements || []) {
      const key = normalizeRawText(safeText(el)).slice(0, 320);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(el);
    }

    return out;
  }

  function removeNested(elements) {
    return (elements || []).filter((el, idx) => {
      return !elements.some((other, jdx) => idx !== jdx && other.contains(el));
    });
  }

  function scoreNode(el) {
    const text = normalizeRawText(safeText(el));
    if (!text) return 0;

    let score = 0;
    if (hasYear(text)) score += 2;
    if (extractPrice(text)) score += 2;
    if (extractKm(text)) score += 2;
    if (extractVIN(text)) score += 1;
    if (extractStock(text)) score += 1;
    if (el.querySelector("img")) score += 1;
    if (el.querySelector("a[href]")) score += 1;

    const rect = el.getBoundingClientRect();
    if (rect.width > 140) score += 1;
    if (rect.height > 120) score += 1;

    return score;
  }


  function collectCardPhotoUrls(card) {
    const urls = [];
    card.querySelectorAll("img").forEach((img) => {
      const alt = lower(img.getAttribute("alt") || "");
      const cls = lower(img.className || "");
      if (alt.includes("logo") || cls.includes("logo") || cls.includes("icon")) return;

      const attrs = [
        img.currentSrc,
        img.src,
        img.getAttribute("data-src"),
        img.getAttribute("data-lazy-src"),
        img.getAttribute("data-original"),
        img.getAttribute("data-zoom-image"),
        img.getAttribute("data-full"),
        img.getAttribute("data-image")
      ];

      attrs.forEach((src) => {
        const value = clean(src || "");
        if (!value) return;
        urls.push(value);
      });

      const srcset = clean(img.getAttribute("srcset") || "");
      if (srcset) {
        srcset.split(",").forEach((part) => {
          const candidate = clean(part.split(" ")[0]);
          if (candidate) urls.push(candidate);
        });
      }
    });

    const seen = new Set();
    return urls.filter((url) => {
      const key = clean(url).split("?")[0];
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function buildShellFromCard(card, opts = {}) {
    const rawText = normalizeRawText(safeText(card));
    const title = extractTitle(rawText);
    const price = extractPrice(rawText);
    const km = extractKm(rawText);
    const stock = extractStock(rawText);
    const vin = extractVIN(rawText);

    const img =
      firstNode(card, opts.imageSelectors || []) ||
      card.querySelector("img");
    const photoUrls = collectCardPhotoUrls(card);

    const link =
      firstNode(card, opts.linkSelectors || []) ||
      card.querySelector("a[href]");

    if (!title && !vin && !price && !km) return null;

    const shell = document.createElement("div");
    shell.setAttribute("data-ea-card-shell", "true");
    shell.setAttribute("data-ea-title", title || "");
    shell.setAttribute("data-ea-price", price ? String(price) : "");
    shell.setAttribute("data-ea-km", km ? String(km) : "");
    shell.setAttribute("data-ea-stock", stock || "");
    shell.setAttribute("data-ea-vin", vin || "");
    shell.setAttribute("data-ea-source-url", clean(link?.href || ""));
    shell.setAttribute("data-ea-image-url", clean(photoUrls[0] || img?.currentSrc || img?.src || ""));
    shell.setAttribute("data-ea-photo-urls", JSON.stringify(photoUrls.slice(0, 12)));
    shell.setAttribute("data-ea-source-text", rawText);

    shell.__eaSourceNode = card;
    shell.__eaScore = scoreNode(card);

    return shell;
  }

  function getConfiguredCandidates(root) {
    const config = getScannerConfig();
    const selectors = asArray(config.card_selectors);
    if (!selectors.length) return [];

    const out = [];
    for (const selector of selectors) {
      safeQueryAll(root, selector).forEach((el) => {
        const text = normalizeRawText(safeText(el));
        if (!text || text.length < 20) return;
        out.push(el);
      });
    }

    return dedupeElements(removeNested(out)).slice(0, MAX_CANDIDATES);
  }

  function getRouteCandidates(root, route) {
    const out = [];

    for (const selector of asArray(route.cardSelectors)) {
      safeQueryAll(root, selector).forEach((el) => {
        const text = normalizeRawText(safeText(el));
        if (!text) return;
        if (text.length < 45) return;

        const score = scoreNode(el);
        if (score >= 4) out.push(el);
      });
    }

    return dedupeElements(removeNested(out)).slice(0, MAX_CANDIDATES);
  }

  function learnGenericCandidates(root) {
    const broadNodes = safeQueryAll(root, "article, li, div, section");
    const candidates = [];

    for (const el of broadNodes) {
      const text = normalizeRawText(safeText(el));
      if (!text || text.length < 60) continue;

      const score = scoreNode(el);
      if (score >= 5) {
        candidates.push(el);
      }
    }

    return dedupeElements(removeNested(candidates)).slice(0, MAX_CANDIDATES);
  }

  function rankShells(shells) {
    return [...shells].sort((a, b) => {
      const aScore = Number(a.__eaScore || 0);
      const bScore = Number(b.__eaScore || 0);
      return bScore - aScore;
    });
  }

  function findVehicleCards(root = document) {
    const ctx = buildContext();
    const route = resolveRoute();
    const config = getScannerConfig();

    log("Resolved route:", {
      route: route.id,
      adapterId: route.adapterId || route.id,
      host: ctx.host,
      scannerType: ctx.scannerType,
      configured: ctx.hasConfiguredSelectors
    });

    if (ctx.hasConfiguredSelectors) {
      const configuredCandidates = getConfiguredCandidates(root);
      const configuredShells = configuredCandidates
        .map((card) =>
          buildShellFromCard(card, {
            imageSelectors: config.image_selectors,
            linkSelectors: config.link_selectors
          })
        )
        .filter(Boolean);

      if (configuredShells.length) {
        log("Configured selector scan succeeded:", configuredShells.length);
        return rankShells(configuredShells);
      }
    }

    const routeCandidates = getRouteCandidates(root, route);
    const routeShells = routeCandidates
      .map((card) => buildShellFromCard(card))
      .filter(Boolean);

    if (routeShells.length) {
      log("Route-family scan succeeded:", {
        route: route.id,
        count: routeShells.length
      });
      return rankShells(routeShells);
    }

    const learnedCandidates = learnGenericCandidates(root);
    const learnedShells = learnedCandidates
      .map((card) => buildShellFromCard(card))
      .filter(Boolean);

    log("Self-learning fallback result:", learnedShells.length);
    return rankShells(learnedShells);
  }

  window.ElevateScannerRouter = {
  findVehicleCards,
  resolveRoute,
  buildContext,
  getScannerConfig,
  getScannerType,
  getActiveRouteId,
  getActiveAdapterId
};
})();
