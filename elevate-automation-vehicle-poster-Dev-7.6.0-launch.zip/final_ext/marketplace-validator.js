// marketplace-validator.js
// Elevate Automation Marketplace Validator V2 (Hardened + Compliance Auto-Fix)
// Final pre-publish validation layer

(function () {

  function clean(v) {
    return String(v || "").replace(/\s+/g, " ").trim();
  }

  function digitsOnly(v) {
    return String(v || "").replace(/[^\d]/g, "");
  }

  function hasPhotos(v) {
    if (Array.isArray(v.photoUrls) && v.photoUrls.length >= 3) return true;
    if (v.coverPhotoUrl) return true;
    return false;
  }

  function isValidLocation(v) {
    const loc = clean(v.location || v.listing_location || "");
    return loc.length >= 3;
  }

  function buildVehicleKey(v) {
    if (!v) return "";

    const vin = clean(v.vin || "").toUpperCase();
    if (vin) return `VIN:${vin}`;

    const stock = clean(v.stock || v.stock_number || "");
    if (stock) return `STOCK:${stock}`;

    return [
      clean(v.year || ""),
      clean(v.make || ""),
      clean(v.model || ""),
      digitsOnly(v.price || ""),
      digitsOnly(v.km || v.kilometers || "")
    ].join("|");
  }

  async function checkDuplicate(v) {
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "IS_VEHICLE_POSTED", vehicle: v },
          resolve
        );
      });

      return result?.posted === true;
    } catch {
      return false;
    }
  }

  async function checkPostingAllowed(v) {
    try {
      const res = await window.ElevateExtensionSession.canUserPostNow(
        buildVehicleKey(v)
      );
      return res;
    } catch {
      return { allowed: true };
    }
  }

  function basicFieldCheck(v) {
    if (!clean(v.year)) return "Missing year";
    if (!clean(v.make)) return "Missing make";
    if (!clean(v.model)) return "Missing model";
    if (!digitsOnly(v.price)) return "Missing price";
    if (!digitsOnly(v.km || v.kilometers)) return "Missing mileage";
    return null;
  }

  function complianceCheck(v) {
    const profile = window.__EA_PROFILE || {};

    if (!clean(profile.full_name)) return "Missing salesperson";
    if (!clean(profile.dealer_name)) return "Missing dealership";
    if (!clean(profile.phone) && !clean(profile.dealer_phone) && !clean(profile.email) && !clean(profile.dealer_email)) {
      return "Missing contact info";
    }

    return null;
  }

  function autoFixCompliance(v) {
    try {
      if (!window.ElevateComplianceEngine) return v;

      const profile = window.__EA_PROFILE || {};
      const fixed = { ...(v || {}) };

      if (fixed.description) {
        fixed.description = window.ElevateComplianceEngine.sanitizeTextForCompliance(
          fixed.description,
          profile
        );
      }

      const built = window.ElevateComplianceEngine.buildListing(fixed, profile);

      if (built?.description) {
        fixed.description = built.description;
      }

      if (built?.caption) {
        fixed.caption = built.caption;
      }

      if (built?.title && !clean(fixed.title)) {
        fixed.title = built.title;
      }

      if (built?.compliance_signature) {
        fixed.compliance_signature = built.compliance_signature;
      }

      return fixed;
    } catch (err) {
      console.warn("Compliance auto-fix error:", err);
      return v;
    }
  }

  function advancedComplianceCheck(v) {
    try {
      if (!window.ElevateComplianceEngine) {
        return null;
      }

      const profile = window.__EA_PROFILE || {};
      const result = window.ElevateComplianceEngine.validateVehicleCompliance(v, profile);

      if (!result.valid) {
        return {
          reason: result.reason || "Compliance validation failed",
          code: result.code || "compliance_engine_fail"
        };
      }

      return null;
    } catch (err) {
      console.warn("Compliance engine error:", err);
      return null;
    }
  }

  async function validateVehicle(v) {
    if (!v) {
      return { valid: false, reason: "No vehicle provided", code: "no_vehicle" };
    }

    // BASIC FIELDS
    const basic = basicFieldCheck(v);
    if (basic) {
      return { valid: false, reason: basic, code: "missing_field" };
    }

    // LOCATION
    if (!isValidLocation(v)) {
      return { valid: false, reason: "Invalid location", code: "bad_location" };
    }

    // PHOTOS
    if (!hasPhotos(v)) {
      return { valid: false, reason: "Missing photos", code: "no_photos" };
    }

    // DUPLICATE CHECK
    const isDup = await checkDuplicate(v);
    if (isDup) {
      return { valid: false, reason: "Vehicle already posted", code: "duplicate" };
    }

    // POSTING LIMIT / INFLOW CHECK
    const gate = await checkPostingAllowed(v);
    if (!gate.allowed) {
      return {
        valid: false,
        reason: gate.reason || "Posting not allowed",
        code: "posting_blocked"
      };
    }

    // BASIC PROFILE COMPLIANCE
    const compliance = complianceCheck(v);
    if (compliance) {
      return {
        valid: false,
        reason: compliance,
        code: "compliance_fail"
      };
    }

    // AUTO-FIX COMPLIANCE FIRST
    const fixedVehicle = autoFixCompliance(v);

    // ADVANCED COMPLIANCE ENGINE CHECK
    const advancedCompliance = advancedComplianceCheck(fixedVehicle);
    if (advancedCompliance) {
      return {
        valid: false,
        reason: advancedCompliance.reason,
        code: advancedCompliance.code || "compliance_engine_fail"
      };
    }

    return {
      valid: true,
      vehicle: fixedVehicle
    };
  }

  window.ElevateMarketplaceValidator = {
    validateVehicle
  };

})();
