// adapter-router.js
// Optional global router for adapter-based scanning

(function () {
  const MIN_CONFIDENCE = 0.7;

  function record(type, payload) {
    try { window.ElevateAdapterTelemetry?.record?.(type, payload || {}); } catch {}
    try { window.ElevateAdapterIntelligence?.record?.({ type, ...(payload || {}) }); } catch {}
  }

  async function runAdapterScan(ctx = {}) {
    const registry = window.ElevateAdapterRegistry;
    const ranked = registry?.resolve ? registry.resolve(ctx) : [];
    const domain = String(ctx?.domain || ctx?.host || location.hostname || '').toLowerCase();

    if (!ranked.length) {
      console.warn("[ROUTER] No adapter candidates found");
      record('scan_failure', { domain, adapter: 'none', reason: 'no_adapter' });
      return fallbackResult("no_adapter");
    }

    for (const item of ranked) {
      const adapter = item.adapter;
      const startedAt = Date.now();
      record('scan_attempt', {
        domain,
        adapter: adapter?.id || 'unknown',
        confidence: Number(item.confidence || 0),
        meta: { priority: Number(item.priority || 0), intelligenceBoost: Number(item.intelligenceBoost || 0) }
      });
      try {
        const result = await adapter.scanInventory(ctx);
        const durationMs = Date.now() - startedAt;
        const vehicleCount = Array.isArray(result?.vehicles) ? result.vehicles.length : 0;
        const confidence = Number(result?.confidence || 0);

        if (result && Array.isArray(result.vehicles) && vehicleCount && confidence >= MIN_CONFIDENCE) {
          console.log(`[ROUTER] Adapter success: ${adapter.id} (${confidence.toFixed(2)})`);
          record('scan_success', { domain, adapter: adapter.id, confidence, count: vehicleCount, durationMs });
          return result;
        }
        console.warn(`[ROUTER] Weak result from ${adapter?.id || "unknown"}`, result?.confidence);
        record('scan_weak', { domain, adapter: adapter?.id || 'unknown', confidence, count: vehicleCount, durationMs, reason: 'below_threshold_or_empty' });
      } catch (error) {
        console.error(`[ROUTER] Adapter failed: ${adapter?.id || "unknown"}`, error);
        record('scan_failure', { domain, adapter: adapter?.id || 'unknown', reason: error?.message || 'scan_error', durationMs: Date.now() - startedAt });
      }
    }

    console.warn("[ROUTER] Falling back to empty result");
    record('scan_failure', { domain, adapter: 'fallback', reason: 'fallback_triggered' });
    return fallbackResult("fallback_triggered");
  }

  function fallbackResult(reason) {
    return {
      vehicles: [],
      confidence: 0,
      diagnostics: {
        adapter: "fallback",
        reason
      }
    };
  }

  window.ElevateAdapterRouter = { runAdapterScan };
})();
